<?php
	include ( 'pdf2text.php' ) ;

	function  output ( $message )
	   {
		if  ( php_sapi_name ( )  ==  'cli' )
			echo ( $message ) ;
		else
			echo ( nl2br ( $message ) ) ;
	    }

	$pdf	=  new PDF2Text ( "d:/temp/1.pdf" ) ;
	$pdf->setFilename( "d:/temp/1.pdf" ) ;
	
	$pdf->decodePDF();

	
	output($pdf->decodedtext) ;
?>