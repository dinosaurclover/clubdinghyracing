const SYSTEMNAME = "NSC System 2"
const VERSION = 8.1



///////////////////////////////////////////////////////////
//
// I have no idea how this works.
//
function commonGetParameterByName(name, url)
{
	if (!url) url = window.location.href;
	name = name.replace(/[\[\]]/g, '\\$&');
	var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
	results = regex.exec(url);
	if (!results) return null;
	if (!results[2]) return '';
	return decodeURIComponent(results[2].replace(/\+/g, ' '));
}
//
//////////////////////////////////////////////////////////////////

///////////////////////////////////////
//
function commonSecondsAfterMidnightToTime(t)
{
	let second = t % 60;
	t -= second;
	t /= 60;
	let minute = t % 60;
	t -= minute;
	t /= 60;
	let hour = t % 24;

	let s = "";

	if (hour < 10) s += "0";
	s += hour;
	s += ":";
	if (minute < 10) s += "0";
	s += minute;
	if (second)
	{
		if (second < 10) s += "0";
		s += second;
	}
	return(s);
}
//
//////////////////////////////////////////////////////////////////

///////////////////////////////////////
//
function commonTimeToSecondsAfterMidnight(s)
{
	let bits = s.split(":");
	if (bits.length < 2) return(false);
	let t = 0;
	if (bits[0]) t += parseInt(bits[0], 10);
	t *= 60;
	if (bits[1]) t += parseInt(bits[1], 10);
	t *= 60;
	if (bits[2]) t += parseInt(bits[2], 10);
	return(t);
}
//
//////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////
//
function commonDefaultFailFunction(xmlhttp)
{
	if ((xmlhttp) && (xmlhttp.object) && (xmlhttp.object.errorMessage))
	{
		alert(xmlhttp.object.errorMessage);
	}
	else
	{
		alert("Communication with server failed");
	}
}
//
//////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////
//
function commonAuthenticateCallback(xmlhttp)
{
	if (xmlhttp.value === null)
	{
		location.reload();
		return;
	}
	let sha256 = new jsSHA('SHA-256', 'TEXT');
	sha256.update(mAPP.appName + xmlhttp.value + location.hostname + xmlhttp.value + mAPP.appName);
	var passworddigest = sha256.getHash("HEX");

	sha256 = new jsSHA('SHA-256', 'TEXT');
	sha256.update(xmlhttp.challenge + passworddigest);
	var passworddigest = sha256.getHash("HEX");

	// WE CAN RECYCLE THE XMLHTTP OBJECT BY OPENING IT AGAIN
	xmlhttp.open("POST", "index.php", true);

	xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xmlhttp.setRequestHeader("digest", passworddigest);
	xmlhttp.setRequestHeader("challenge", xmlhttp.challenge);
	if (typeof(mTestDate) !== 'undefined') xmlhttp.setRequestHeader("testdate", mTestDate);

	xmlhttp.send(xmlhttp.data);
}
//
//////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////
//
// This authentication is for anonymous connections.
// You just need to know the password.
// Web page does not need your name.
//
function commonAuthenticate(xmlhttp)
{
	if (!xmlhttp.logonMessage)
	{
		if (mAPP.appName == "raceofficer")
		{
			xmlhttp.logonMessage = "This site requires a password." +
						"\nAll Race Officers should know the password." +
						"\nPlease enter the race officer's password.";
		}
		else
		{
			xmlhttp.logonMessage = "This site requires a password." +
						"\nAll members should know the password." +
						"\nIt's usually the same as the gate lock code." +
						"\nPlease enter the password.";
		}
	}

	if (mAPP.raspberryPi)
	{
		// force prompt (in prompt.js) to work like the real prompt
		let evt = {}
		evt.target = promptCreateInput();
		evt.target.context = xmlhttp;
		evt.target.title = xmlhttp.logonMessage;
		evt.target.callback = commonAuthenticateCallback;
		promptPrompt(evt);
		// SEE CALLBACK ABOVE
		return;
	}

	xmlhttp.value = prompt(xmlhttp.logonMessage, "");

	if (xmlhttp.value === null)
	{
		location.reload();
		return;
	}
	let sha256 = new jsSHA('SHA-256', 'TEXT');
	sha256.update(mAPP.appName + xmlhttp.value + location.hostname + xmlhttp.value + mAPP.appName);
	var passworddigest = sha256.getHash("HEX");

	sha256 = new jsSHA('SHA-256', 'TEXT');
	sha256.update(xmlhttp.challenge + passworddigest);
	var passworddigest = sha256.getHash("HEX");

	// WE CAN RECYCLE THE XMLHTTP OBJECT BY OPENING IT AGAIN
	xmlhttp.open("POST", "index.php", true);

	xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	xmlhttp.setRequestHeader("digest", passworddigest);
	xmlhttp.setRequestHeader("challenge", xmlhttp.challenge);
	if (typeof(mTestDate) !== 'undefined') xmlhttp.setRequestHeader("testdate", mTestDate);

	xmlhttp.send(xmlhttp.data);
}
//
///////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////
//
function commonOnReadyStateChange(evt)
{
	var xmlhttp = evt.target;

	switch(xmlhttp.readyState)
	{
		case 0: break;
		case 1: break;
		case 2: break;
		case 3: break;
		case 4:
		{
			// CALLER MIGHT HIDE BODY IF SHE/HE THINKS CALL MIGHT
			document.body.style.display = "";

			if (xmlhttp.status == 0)
			{
				// COULD NOT CONNECT TO SERVER
				document.body.style.backgroundColor = "pink";
				return;
			}
			if (xmlhttp.status == 401)
			{
				// SERVER WILL HAVE RETURNED A CHALLENGE
				document.body.style.backgroundColor = "";
				let text = xmlhttp.statusText;
				if (!text) text = xmlhttp.responseText;
				xmlhttp.challenge = text.split("|")[1].trim();
				// RESEND THE DATA TOGETHER WITH PASSWORD DIGEST
				commonAuthenticate(xmlhttp);
				return;
			}
			if (xmlhttp.status != 200)
			{
				if (xmlhttp.failureFunction) xmlhttp.failureFunction(xmlhttp);
				else alert(xmlhttp.statusText);
				return;
			}
			else
			{
				document.body.style.backgroundColor = "";
				try
				{
					xmlhttp.object = JSON.parse(xmlhttp.responseText);
				}
				catch(error)
				{
					if (xmlhttp.failureFunction)
					{
						xmlhttp.failureFunction(xmlhttp);
						return;
					}
					// PROBABLY PHP FORMATTED SOME HTML TO EXPLAIN THE PROBLEM
					var div = document.createElement("div");
					div.style.position = "fixed";
					div.style.left = 0;
					div.style.top = 0;
					div.innerHTML = xmlhttp.responseText;
					div.id = "fearsome";
					document.body.appendChild(div);
					return;
				}
				if (xmlhttp.object)
				{
					if (xmlhttp.object.token)
					{
						// SUCCESSFUL LOGIN HAS JUST OCCURRED
						// THE SERVER WILL HAVE EXECUTED THE COMMAND BECAUSE IT LIKED THE PASSWORD
						mAPP.token = xmlhttp.object.token;
						localStorage.setItem(mAPP.appName + "Token", mAPP.token);
					}

					if (xmlhttp.object.errorMessage)
					{
						if (xmlhttp.failureFunction) xmlhttp.failureFunction(xmlhttp);
						else alert(xmlhttp.object.errorMessage);
						return;
					}

					if (xmlhttp.object.infoMessage)
					{
						alert(xmlhttp.object.infoMessage);
					}
					if (xmlhttp.object.warningMessage)
					{
						alert(xmlhttp.object.warningMessage);
					}
					if (xmlhttp.successFunction) xmlhttp.successFunction(xmlhttp);
					else alert("Programming error. Don't know what to do with this server response.");
				}
				else
				{
					if (xmlhttp.failureFunction) xmlhttp.failureFunction(xmlhttp);
					else alert(xmlhttp.responseText);
				}
			}
			break;
		}
		default:break;
	}
}
//
//////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////
//
function commonCreateXMLHTTP()
{
	let xmlhttp = new XMLHttpRequest();

	xmlhttp.onreadystatechange = commonOnReadyStateChange;
	xmlhttp.open("POST", "index.php", true);
	if (mAPP.token) xmlhttp.setRequestHeader("token", mAPP.token);
	if (typeof(mTestDate) !== 'undefined') xmlhttp.setRequestHeader("testdate", mTestDate);
	xmlhttp.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	return(xmlhttp);
}
//
///////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//
// JAVASCRIPT CAN DO THIS WHICH CAN BE VERY HELPFUL
//
function commonExtendArrays()
{
	var seasons;
	var defaultduties;
	var fleets;
	var cups;

	if ((fleets = mAPP.clubConfig.fleets))
	{
		for (var j = 0; j < fleets.length; j ++)
		{
			fleets[fleets[j].flag.toLowerCase()] = fleets[j];
		}
	}

	if ((duties = mAPP.clubConfig.duties))
	{
		for (var j = 0; j < duties.length; j ++)
		{
			duties[duties[j].code.toLowerCase()] = duties[j];
		}
	}


	let needed = [
"di1",
"di2",
"di3",
"di4",
"di5",
"di6",
"day bar1",
"day gal1",
"day gh",
"day lood",
"day ooda",
"day pb1a",
"day pb1d",
"day pb2a",
"day pb2d",
"day pb3a",
"day pb3d",
"day pb4a",
"day pb4d",
"day rec1",
"day rec2",
"day ro",
"day roa",
"day sb1a",
"day sb1d",
"day so",
"day sood",
"eve bar1",
"eve bar2",
"eve bbq1",
"eve gal1",
"eve ood",
"eve pb1a",
"eve pb1d",
"eve ro",
"eve roa",
"fc1",
"fc2",
"pbi1",
"pbi2",
"sal",
"sbi",
"sh1",
"sh2",
"si",
"wi1",
"wi2",
"wsi",
"yrc1",
"yrc2"]
	let missing = [];
	for (let i = 0; i < needed.length; i ++)
	{
		let code = needed[i];
		if (!duties[code])
		{
			missing.push(code);
		}
	}
//	if (missing.length)
//	{
//		alert(missing.join(","));
//	}


	if ((defaultduties = mAPP.clubConfig.defaultDuties))
	{
		for (var j = 0; j < defaultduties.length; j ++)
		{
			defaultduties[defaultduties[j].code.toLowerCase()] = defaultduties[j];
		}
	}

	if ((cups = mAPP.clubConfig.cups))
	{
		for (var i = 0; i < cups.length; i ++)
		{
			var cup = cups[i];
			cups[cup.name.toLowerCase()] = cup;

			if ((defaultduties = cup.defaultDuties))
			{
				for (var j = 0; j < defaultduties.length; j ++)
				{
					defaultduties[defaultduties[j].code.toLowerCase()] = defaultduties[j];
				}
			}

			if (cup.fleets)
			{
				// IT'S JUST A STRING WITH THE CODES IN START ORDER
				let flags = cup.fleets.split("");
				cup.fleets = [];
				for (var j = 0; j < flags.length; j ++)
				{
					cup.fleets[j] = fleets[flags[j].toLowerCase()];
				}
			}

			if ((seasons = cups[i].seasons))
			{
				for (var j = 0; j < seasons.length; j ++)
				{
					var season = seasons[j];
					seasons["season" + season.name.toLowerCase()] = season;
					if ((defaultduties = season.defaultDuties))
					{
						for (var j = 0; j < defaultduties.length; j ++)
						{
							defaultduties[defaultduties[j].code.toLowerCase()] = defaultduties[j];
						}
					}
					if ((fleets = cup.fleets))
					{
						for (var j = 0; j < fleets.length; j ++)
						{
							fleets[fleets[j].flag.toLowerCase()] = fleets[j];
						}
					}
				}
			}
		}
	}

	if (mAPP.clubConfig.yearplannerColumns)
	{
		let columns = mAPP.clubConfig.yearplannerColumns;
		for (var j = 0; j < columns.length; j ++)
		{
			columns[columns[j].name.toLowerCase()] = columns[j];
			columns[j].cellIndex = j + 1;
		}
	}
}
//
/////////////////////////////////////////////////////////////

