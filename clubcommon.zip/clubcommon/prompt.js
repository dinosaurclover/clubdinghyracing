const mPromptBackgroundColor = "beige";

////////////////////////////////////////////////////////////////////////////
//
function promptTouchHandler(event)
{
	if (event.touches.length > 1)
	{
		event.preventDefault()
	}
}
//
////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
function promptOnResize()
{
	let prompt = document.getElementById("prompt");
	if (prompt)
	{
		let guard = prompt.guard;
		guard.style.width = "" + window.innerWidth + "px";
		guard.style.height = "" + window.innerHeight + "px";
		prompt.style.left = "0.5em";

		prompt.localInput.style.width = "" + prompt.keyboardTable.offsetWidth + "px";
		prompt.messageDiv.style.width = "" + prompt.keyboardTable.offsetWidth + "px";

		let y = innerHeight - prompt.offsetHeight - 5;
		prompt.style.top = "" + y + "px";
	}
}
//
////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
function promptPreventDefault(evt)
{
	evt.preventDefault()
}
//
/////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
function promptKeyboardSound(duration, frequency, volume, type, callback)
{
	const ctx = new window.AudioContext;
    var oscillator = ctx.createOscillator();
    var gainNode = ctx.createGain();

//    oscillator.connect(gainNode);
  //  gainNode.connect(ctx.destination);

	oscillator.connect(ctx.destination);


    if (volume){gainNode.gain.value = volume;}
    if (frequency){oscillator.frequency.value = frequency;}
    if (type){oscillator.type = type;}
    if (callback){oscillator.onended = callback;}

    oscillator.start(ctx.currentTime);
    oscillator.stop(ctx.currentTime + ((duration || 100) / 1000));
};
//
/////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
function promptKeyboardClick(evt)
{
	evt.preventDefault();
	promptKeyboardSound();
	mAPP.prompt.localInput.value += evt.target.innerHTML;
	mAPP.prompt.input.value = mAPP.prompt.localInput.value;
}
//
/////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
function promptKeyboardBackspace(evt)
{
	if (evt) evt.preventDefault();
	promptKeyboardSound();
	let l = mAPP.prompt.localInput.value.length;
	mAPP.prompt.localInput.value = mAPP.prompt.localInput.value.substring(0, l - 1);
	mAPP.prompt.input.value = mAPP.prompt.localInput.value;
}
//
/////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
function promptKeyboardConfirm(evt)
{
	if (evt) evt.preventDefault();
	document.removeEventListener("keyup", promptOnKeyUp);
	promptKeyboardSound();
	document.body.removeChild(mAPP.prompt.guard);
	document.body.removeChild(mAPP.prompt);
	let input = mAPP.prompt.input;
	if (input.context) input.context.value = input.value;
	if (mAPP.prompt.input.callback) mAPP.prompt.input.callback(input.context);
}
//
/////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
function promptKeyboardCancel(evt)
{
	if (evt) evt.preventDefault();
	document.removeEventListener("keyup", promptOnKeyUp);
	promptKeyboardSound();
	document.body.removeChild(mAPP.prompt.guard);
	document.body.removeChild(mAPP.prompt);
	let input = mAPP.prompt.input;
	input.value = mAPP.prompt.orgValue;
	if (input.context) input.context.value = null;
	if (mAPP.prompt.input.callback) mAPP.prompt.input.callback(input.context);
}
//
/////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
function promptOnKeyUp(evt)
{
	evt.preventDefault();
	let key = evt.key.toUpperCase();
	if ((key.length == 1) && (((key >= "A") && (key <= "Z")) || ((key >= "0") && (key <= "9"))))
	{
		promptKeyboardSound();
		mAPP.prompt.localInput.value += key;
		mAPP.prompt.input.value = mAPP.prompt.localInput.value;
		return;
	}
	switch(key)
	{
		case "ESCAPE": promptKeyboardCancel(); break;
		case "ENTER": promptKeyboardConfirm(); break;
		case "BACKSPACE": promptKeyboardBackspace(); break;
	}
}
//
/////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
function promptPrompt(evt)
{
	input = evt.target;

	if (!mAPP.prompt)
	{
		var style = document.createElement("style");
		// Add a media (and/or media query) here if you'd like!
		// style.setAttribute("media", "screen")
		// style.setAttribute("media", "only screen and (max-width : 1024px)")

		// WebKit hack :(
		style.appendChild(document.createTextNode(""));

		// Add the <style> element to the page
		document.head.appendChild(style);

		style.sheet.insertRule("table.keyboard td{width:1.7em; margin:0.1em; text-align:center;	color:white; background-color:black; border-radius:0.2em;}");

		let guard = document.createElement('div');
		guard.style.position = "fixed";
		guard.style.left = 0;
		guard.style.top = 0;
		guard.style.width = "" + window.innerWidth + "px";
		guard.style.height = "" + window.innerHeight + "px";
		guard.style.background = "rgba(0, 0, 0, 0.2)";

		guard.addEventListener("mousedown", promptPreventDefault, true);
		guard.addEventListener("click", promptPreventDefault, true);

		mAPP.prompt = document.createElement('div');
		mAPP.prompt.id = "prompt";
		mAPP.prompt.style.position = "fixed";
		mAPP.prompt.style.borderStyle = "solid";
		mAPP.prompt.style.borderWidth = "1px";
		mAPP.prompt.style.borderColor = "black";
		mAPP.prompt.style.borderRadius = "0.5em";
		mAPP.prompt.style.padding = "0.3em";
		mAPP.prompt.style.background = "linear-gradient(" + mPromptBackgroundColor + ", white)";
		mAPP.prompt.guard = guard;

		let div = document.createElement('div');
		mAPP.prompt.appendChild(div);
		mAPP.prompt.messageDiv = div;

		let input = document.createElement('input');
		input.setAttribute("readonly", true);
		mAPP.prompt.appendChild(input);
		input.style.border = "black 1px solid";
		input.style.backgroundColor = "white";
//		input.style.minHeight = "1.15em";
		mAPP.prompt.localInput = input;

		let english =
		[
			"1234567890",
			"QWERTYUIOP",
			"ASDFGHJKL",
			"ZXCVBNM"
		];
		for (let i = 0; i < english.length; i ++)
		{
			let keys = english[i];
			english[i] = keys.split("");
		}
		let table = document.createElement("table");
		mAPP.prompt.keyboardTable = table;
		mAPP.prompt.appendChild(table);
		table.setAttribute("class", "keyboard");
		let cell = false;
		for (let i = 0; i < english.length; i ++)
		{
			let row = table.insertRow(-1);
			let keys = english[i];
			for (let j = 0; j < keys.length; j ++)
			{
				cell = row.insertCell(-1);
				cell.style.borderStyle = "none";
				cell.style.boxSizing = "border-box";
				cell.padding = "0.2em";
				cell.innerHTML = keys[j];
				cell.addEventListener("click", promptKeyboardClick);
			}
			if (i == 2)
			{
				cell = row.insertCell(-1);
				cell.style.borderStyle = "none";
				cell.style.boxSizing = "border-box";
				cell.padding = "0.2em";
				cell.innerHTML = "&#x232B;";
				cell.addEventListener("click", promptKeyboardBackspace);
			}
			if (i == 3)
			{
				cell = row.insertCell(-1);
				cell.style.borderStyle = "none";
				cell.style.boxSizing = "border-box";
				cell.padding = "0.2em";
				cell.innerHTML = "OK";
				cell.setAttribute("colspan", "2");
				cell.addEventListener("click", promptKeyboardConfirm);
				cell = row.insertCell(-1);
				cell.style.borderStyle = "none";
				cell.style.boxSizing = "border-box";
				cell.padding = "0.2em";
				cell.innerHTML = "X";
				cell.style.color = "red";
				cell.addEventListener("click", promptKeyboardCancel);
			}
		}

		// THERE IS SOME CONFUSION BUT IF YOU HAVE THIS
		// <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no" />
		// IN THE HEADER, SCREEN WIDTH AND SCREEN HEIGHT ARE MEANINGFUL
		let x = screen.width;
		if (screen.height < x) x = screen.height;
		x /= 20;
		mAPP.prompt.style.fontSize = "" + x + "px";

		addEventListener("resize", promptOnResize);
	}
	mAPP.prompt.input = input;
	mAPP.prompt.localInput.value = input.value;
	if (input.title) mAPP.prompt.messageDiv.innerHTML = input.title;
	else mAPP.prompt.messageDiv.innerHTML = "Please edit this value here.";
	document.body.appendChild(mAPP.prompt.guard);
	document.body.appendChild(mAPP.prompt);
	promptOnResize();
	document.addEventListener("keyup", promptOnKeyUp);
}
//
////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
function promptCreateInput()
{
	let input = document.createElement("input");
	input.setAttribute("readonly", true);
	input.type = "text";
	input.className = "keyboard";
	input.addEventListener("click", prompt);
	return(input);
}
//
////////////////////////////////////////////////////////////////////////////
