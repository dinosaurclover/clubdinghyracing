/*
 * For the Raspberry Pi with the touch screen we need to control the dropdown
 * For two reasons.
 * Neither of the Linux Browsers offer full support for touch screens.
 * The click event seems reliable.
 * List boxes (HTML select element) do not work well and there is no keyboard
 * for speedy jumps to the region you need.
 * Furthermore there is a bug (same bug in both browsers). When you click a
 * button while a select control has the focus, the button click is not
 * detected. You have to click it again.
 * Can't find any compalints about this in the forums.
 * to a spot in the list by pressing a key. We put up some buttons for
 * this.
 * This module creates an input element if raspberry pi is detected and
 * creates some popup divs to let you set pick the vulue you need.
 *
 * For all platforms we frequently need to put a few user specific (custom)
 * options at the top of the list so the following calls should always be used.
 *
 * dropdownCreateSelect()
 * dropdown.setMainOptions(stringarray)
 * dropdown.setCustomOptions(stringarray)
 * dropdown.setValue(string)
 *
 * For the raspberry pi, setEventListener has been subclassed and, for the
 * "change" event in particular, should work for you normally.
 */
////////////////////////////////////////////////////////////////////////////
//
function dropdownOnBlur(evt)
{
	console.log("dropdown blur");
	for (let j = 0; j < 2; j ++)
	{
		let div = document.getElementById("buttons" + j);
		if (div) div.parentElement.removeChild(div);
	}

	let select = evt.target;
	select.removeEventListener("blur", dropdownOnBlur);

	let button = evt.relatedTarget;

	if ((!button) || (button.className != "alnum"))
	{
		select.loaded = false;
		return;
	}
	button.option.selected = true;
}
//
////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
function dropdownOnFocusOut(evt)
{
	console.log("dropdown focus out");
	let select = evt.target;
	for (let j = 0; j < 2; j ++)
	{
		let div = document.getElementById("buttons" + j);
		if (div) div.parentElement.removeChild(div);
		select.loaded = false;
	}

	select.removeEventListener("focusout", dropdownOnFocusOut);

	let button = evt.relatedTarget;

	if ((!button) || (button.className != "alnum"))
	{
		select.loaded = false;
		return;
	}
	button.option.selected = true;
}
//
////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
function dropdownWindowClick(evt)
{
	console.log("window click");
	if (evt.target) console.log("target", evt.target.tagName);
	if (evt.relatedTarget) console.log("relatedTarget", evt.relatedTarget.tagName);

}
//
////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
function dropdownDocumentClick(evt)
{
	console.log("Document click");
	if (evt.target) console.log("target", evt.target.tagName);
	if (evt.relatedTarget) console.log("relatedTarget", evt.relatedTarget.tagName);

}
//
////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
function dropdownOnMouseDown(evt)
{
	console.log("mousedown");
}
//
////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
function dropdownOnFocusIn(evt)
{
	console.log("dropdown focus in");
	let select = evt.target;
	if (select.loaded) return;

	let keys = [];
	if (select.initials) keys = Object.keys(select.initials);
	if (keys.length > 1)
	{
		let width = innerWidth / keys.length;
		let buttons = [document.createElement("div"), document.createElement("div")];
		for (let j = 0; j < 2; j ++)
		{
			buttons[j].id = "buttons" + j;
			buttons[j].style.position = "absolute";
			buttons[j].style.overflowX = "hidden";
			buttons[j].style.left = 0;
			buttons[j].style.width = "" + window.innerWidth + "px";
		}
		for (i = 0; i < keys.length; i ++)
		{
			for (let j = 0; j < 2; j ++)
			{
				let button = document.createElement("button");
				button.setAttribute("class", "alnum");
				button.style.boxSizing = "border=box";
				button.style.width = "" + width + "px";
				button.innerHTML = keys[i].substr(1);
				buttons[j].appendChild(button);
				button.option = select.initials[keys[i]];
				button.select = select;
			 	button.addEventListener("mousedown", dropdownOnMouseDown);
			}
		}
		document.body.appendChild(buttons[0]);
		document.body.appendChild(buttons[1]);
		buttons[0].style.top = 0;
		buttons[1].style.top = "" + (window.innerHeight - buttons[1].offsetHeight) + "px";
	}
	select.loaded = true;
 	select.addEventListener("focusout", dropdownOnFocusOut);
 	select.addEventListener("change", dropdownOnFocusOut);
}
//
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////
//
function dropdownSetValue(s)
{
	this.value = s;
	if (this.selectedIndex >= 0) return;
	let option = document.createElement("option");
	option.innerHTML = s;
	option.custom = true;
	this.insertBefore(option, this.firstChild);
	option.selected = true;
}
//
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////
//
function dropdownSetMainOptions(strings)
{
	let options = this.options;
	let orgvalue = false;

	let i = options.length;
	while (i > 0)
	{
		i --;
		let option = options[i];
		if (option.selected) orgvalue = option.value;
		if (!option.custom) this.removeChild(option);
	}

	let option = document.createElement("option");
	option.innerHTML = "";
	this.appendChild(option);

	var initials = [];
	for (i = 0; i < strings.length; i ++)
	{
		let option = document.createElement("option");
		option.innerHTML = strings[i];
		this.appendChild(option);
		if (orgvalue)
		{
			if (strings[i] == orgvalue) option.selected = true;
		}
		if (mAPP.raspberryPi)
		{
			if (!initials["_" + strings[i].substr(0, 1).toUpperCase()])
			{
				initials["_" + strings[i].substr(0, 1).toUpperCase()] = option;
			}
		}
	}
	if (!orgvalue) this.selectedIndex = 0;

	if (mAPP.raspberryPi) this.initials = initials;
}
//
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////
//
function dropdownSetCustomOptions(strings)
{
	let options = this.options;
	let orgvalue = false;
	for (let i = 0; i < options.length; i ++)
	{
		let option = options[i];
		if (option.selected) orgvalue = option.value;
		if (option.custom) this.removeChild(option);
	}

	for (i = strings.length; i > 0; i --)
	{
		let option = document.createElement("option");
		option.innerHTML = strings[i - 1];
		this.insertBefore(option, this.firstChild);
		option.custom = true;
		if (orgvalue)
		{
			if (strings[i] == orgvalue) option.selected = true;
		}
	}

	let option = document.createElement("option");
	option.custom = true;
	option.innerHTML = "";
	this.insertBefore(option, this.firstChild);

	if (!orgvalue) this.selectedIndex = 0;

}
//
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////
//
function dropdownPiOnChange(evt)
{
	evt.preventDefault();
	let select = evt.target.select;
	select.value = evt.target.innerText;
	document.body.removeChild(select.dropdownDiv);
	document.body.removeChild(select.guard);
	let div = document.getElementById("quickbuttons");
	if (div) document.body.removeChild(div);
	if (select.onChangeFunction)
	{
		let evt = {};
		evt.target = select;
		select.onChangeFunction(evt);
	}
}
//
/////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////
//
function dropdownPiScrollIntoView(evt)
{
	let p = evt.target.p;
	p.scrollIntoView();
}
//
/////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////
//
function dropdownCancel(evt)
{
	evt.preventDefault();
	let select = evt.target.select;
	document.body.removeChild(select.dropdownDiv);
	document.body.removeChild(select.guard);
	let div = document.getElementById("quickbuttons");
	if (div) document.body.removeChild(div);
}
//
/////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////
//
function dropdownPiOnClick(evt)
{
	let select = evt.target;

	select.guard = document.createElement('div');
	select.guard.style.position = "fixed";
	select.guard.style.left = 0;
	select.guard.style.top = 0;
	select.guard.style.width = "" + window.innerWidth + "px";
	select.guard.style.height = "" + window.innerHeight + "px";
	select.guard.style.background = "rgba(0, 0, 0, 0.2)";
//	select.guard.addEventListener("mousedown", promptPreventDefault, true);
//	select.guard.addEventListener("touchstart", promptPreventDefault, true);
	select.guard.addEventListener("click", dropdownCancel);
	select.guard.select = select;
	document.body.appendChild(select.guard);

	if (!select.mainOptionsDiv)
	{
		select.buttonsDiv = false;
		let div = document.createElement('div');
		let strings = select.mainOptionsStrings;
		let initials = [];
		if (strings)
		{
			let p = document.createElement('p');
			p.innerText = "";
			p.style.height = "1.1em";
			div.appendChild(p);
			p.style.cursor = "default";
			p.addEventListener("click", dropdownPiOnChange);
			p.select = select;
			for (let i = 0; i < strings.length; i ++)
			{
				let p = document.createElement('p');
				p.innerText = strings[i];
				div.appendChild(p);
				p.style.cursor = "default";
				p.addEventListener("click", dropdownPiOnChange);
				p.select = select;
				if (!initials["_" + strings[i].substr(0, 1).toUpperCase()])
				{
					initials["_" + strings[i].substr(0, 1).toUpperCase()] = p;
				}
			}
		}
		select.mainOptionsDiv = div;

		div = document.createElement('div');
		let button = document.createElement('button');
		div.appendChild(button);
		div.style.position = "fixed";
		button.innerHTML = "Cancel";
		button.select = select;
		button.addEventListener("click", dropdownCancel);
		let keys = Object.keys(initials);
		for (let i = 0; i < keys.length; i ++)
		{
			let button = document.createElement('button');
			div.appendChild(button);
			button.innerHTML = keys[i].substr(1);
			button.p = initials[keys[i]];
			button.addEventListener("click", dropdownPiScrollIntoView);
		}
		div.id = "quickbuttons";
		select.buttonsDiv = div;
	}

	if (!select.customOptionsDiv)
	{
		let div = document.createElement('div');
		let strings = select.customOptionsStrings;
		if (strings)
		{
			let p = document.createElement('p');
			p.innerText = "";
			p.style.height = "1.1em";
			div.appendChild(p);
			p.style.cursor = "default";
			p.addEventListener("click", dropdownPiOnChange);
			p.select = select;
			for (let i = 0; i < strings.length; i ++)
			{
				let p = document.createElement('p');
				p.innerText = strings[i];
				div.appendChild(p);
				p.style.cursor = "default";
				p.addEventListener("click", dropdownPiOnChange);
				p.select = select;
			}
		}
		select.customOptionsDiv = div;
	}

	let rect = select.getBoundingClientRect();

	let div = document.createElement('div');
	div.appendChild(select.customOptionsDiv);
	div.appendChild(select.mainOptionsDiv);
	div.style.border = "black 1px solid";
	div.style.backgroundColor = "white";
	div.style.position = "fixed";
	div.style.left = "" + rect.left + "px";
	div.style.top = 0;
	div.style.width = "" + select.offsetWidth + "px";
	div.style.overflowX = "hidden";
	document.body.appendChild(div);
	if (div.offsetHeight > innerHeight)
	{
		div.style.top = 0;
		div.style.overflowY = "scroll";
		if (select.buttonsDiv)
		{
			document.body.appendChild(select.buttonsDiv);
			let buttons = select.buttonsDiv.getElementsByTagName("button");
			let width = innerWidth - buttons[0].offsetWidth - 1;
			if (buttons.length > 1) width /= (buttons.length - 1);
			for (let i = 1; i < buttons.length; i ++)
			{
				buttons[i].style.width = "" + width + "px";
			}
			select.buttonsDiv.style.top = "" + innerHeight - select.buttonsDiv.offsetHeight + "px";
			div.style.height = "" + (innerHeight - select.buttonsDiv.offsetHeight) + "px";
		}
		else
		{
			div.style.height = "" + innerHeight + "px";
		}
	}
	else
	{
		let y = rect.top + select.offsetHeight / 2;
		y -= div.offsetHeight / 2;
		if (y < 0)
		{
			y = 0;
		}
		else if ((y + div.offsetHeight) > innerHeight)
		{
			y = innerHeight - div.offsetHeight;
		}
		div.style.top = "" + y + "px";
	}
	select.dropdownDiv = div;
}
//
/////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////
//
function dropdownPiSetMainOptions(strings)
{
	this.mainOptionsDiv = false;
	this.mainOptionsStrings = strings;
}
//
/////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////
//
function dropdownPiSetCustomOptions(strings)
{
	this.customOptionsDiv = false;
	this.customOptionsStrings = strings;
}
//
/////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////
//
function dropdownPiSetValue(value)
{
	this.value = value;
}
//
/////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////
//
function dropdownPiAddEventListener(type, f)
{
	if (type == "change") this.onChangeFunction = f;
}
//
/////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////
//
// You can set the options here or
// You can set them yourself later
//
function dropdownCreateSelect()
{
	if (!mAPP.raspberryPi)
	{
		let select = document.createElement("select");
		select.setAttribute("class", "dropdown");
		select.style.border = "black 1px solid";
		select.style.backgroundColor = "white";
		select.addEventListener("focusin", dropdownOnFocusIn);
		select.setValue = dropdownSetValue;
		select.setMainOptions = dropdownSetMainOptions;
		select.setCustomOptions = dropdownSetCustomOptions;
		return(select);
	}
	else
	{
		let select = document.createElement("input");
		select.type = "text";
		select.setAttribute("readonly", true);
		select.style.cursor = "default";
		select.style.border = "black 1px solid";
		select.style.height = "1.1em";
		select.style.backgroundColor = "white";
		select.addEventListener("click", dropdownPiOnClick);
		select.setValue = dropdownPiSetValue;
		select.setMainOptions = dropdownPiSetMainOptions;
		select.setCustomOptions = dropdownPiSetCustomOptions;
		select.addEventListener = dropdownPiAddEventListener;
		return(select);
	}
}
//
//////////////////////////////////////////////////////////

