// Connects with the auth.php module on the server
// Server accesses the database for a list of autorised email addresses
// If the user has a valid token it is transmitted and checked.
// Must be within date.
// Emails must match.
// Ip addresses must match.
// Server side script names must match.
// hostnames must match.
// If check fails, client must request a challenge.
// Server returns the challenge and also emails a 6 digit key
// User inputs the key and client sends challenge and key back to server
// If all is OK, server returns a token. Client stores the token in local storage.

"use strict"

function auth(callback)
{
	let accountName = localStorage.getItem("adminAccountName");
	if (!accountName) accountName = "";

	do
	{
		accountName = prompt("Please enter your email address.\nWe need it as an ID.", accountName)
	}
	while ((!accountName) || (!accountName.trim()));


	let token = localStorage.getItem("adminToken");

	let xmlhttp = new HttpURLConnection();
	xmlhttp.setRequestHeader("token", token);
	xmlhttp.setSuccessFunction(success)
	xmlhttp.setFailureFunction(getToken)
	xmlhttp.transmit("command=checktoken&email=" + accountName);

	function success(xmlhttp)
	{
		// If the token is acceptable HttpURLConnection will have remembered it for
		// No further action is required
		if (callback) callback()
	}


	function getToken()
	{
		let message = "If " + accountName +
			"\nis on the list of administrators for" +
			"\nthis site an email is on its way." +
			"\nIt contains a 6 digit key." +
			"\nPlease check your email." +
			"\nThen return and enter the key here." +
			"\nClick Cancel for a new email containing new key.";

		let xmlhttp = new HttpURLConnection("write");
		xmlhttp.setSuccessFunction(success)
		xmlhttp.setFailureFunction(failure)
		xmlhttp.transmit("command=requestchallenge&email=" + accountName);
		function failure(xmlhttp)
		{
                    alert(xmlhttp.object.errorMessage)
                    auth()
		}
		function success(xmlhttp)
		{
			let challenge = xmlhttp.object.challenge;
			getPassword()
			function getPassword()
			{
				let pass = prompt(message);
				if (pass === null)
				{
					location.reload();
					return;
				}
				if (pass) pass = pass.trim();
				if (pass)
				{
					xmlhttp = new HttpURLConnection();
					xmlhttp.setRequestHeader("challenge", challenge);
					xmlhttp.setSuccessFunction(gotToken)
					xmlhttp.setFailureFunction(tryAgain)
					xmlhttp.transmit("command=requesttoken&email=" + accountName + "&key=" + pass);
					function tryAgain()
					{
						message = "Incorrect secret code." +
						"\nIt's a 6 figure number." +
						"\nPlease check your email." +
						"\nThen return and enter the key here." +
						"\nClick Cancel for a new email containing new key.";
						getPassword()
					}
					function gotToken(xmlhttp)
					{
						localStorage.setItem("adminAccountName", accountName)
						localStorage.setItem("adminToken", xmlhttp.object.token)
						if (callback) callback()
					}
				}
			}
		}
	}
}

