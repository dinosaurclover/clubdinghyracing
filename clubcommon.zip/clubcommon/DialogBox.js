class DialogBox extends HTMLDivElement
{
	static stack = [];
	
	buttonParagraph = false;
	terrain = false;
	
	
	constructor()
	{
		super(); // always call super() first in the constructor.
		
		this.guard = document.createElement("div");
		document.body.appendChild(this.guard);
		this.guard.style.position = "fixed";
		this.guard.style.background = "rgba(0, 0, 0, 0.2)";
		this.guard.style.left = 0;
		this.guard.style.top = 0;
		this.guard.style.width = "" + window.innerWidth + "px";
		this.guard.style.height = "" + window.innerHeight + "px";
		this.guard.addEventListener("resize", DialogBox.resize);
		this.guard.appendChild(this);
		
		this.guard.addEventListener("pointerdown", DialogBox.reject);
		this.addEventListener("pointerdown", DialogBox.reject)

		this.guard.addEventListener("click", DialogBox.reject);
		this.addEventListener("click", DialogBox.reject)
		
		this.setAttribute("class", "dialogbox");
		this.style.backgroundColor = document.body.style.backgroundColor;
		this.style.position = "absolute";
		this.style.left = "" + (1 + DialogBox.stack.length * 2) + "em";
		this.style.top = "" + (1 + DialogBox.stack.length) + "em";
		this.style.display = "block";
		this.style.cursor = "default";
		
		DialogBox.stack.push(this);
		
		// 'X' button in top right corner
		let button = document.createElement("button");
		this.appendChild(button);
		button.style.position = "absolute";
		button.style.top = "0";
		button.style.right = "0";
		button.style.color = "red";
		button.style.padding = "0.1em";
		button.innerHTML = "X";
		this.closeButton = button;
		button.addEventListener("click", DialogBox.cancelButtonHandler);

		let span = document.createElement("span");
		span.style.marginRight = "1em";
		this.appendChild(span);
		span.innerHTML = document.title
		
		let dlg = this;
		dlg.addEventListener("pointerdown", dialogPointerDown);
		function dialogPointerDown(evt)
		{
			evt.preventDefault();
			// get the pointer cursor position at startup:
			dlg.clientX = evt.clientX;
			dlg.clientY = evt.clientY;

			document.addEventListener("pointerup", dialogPointerUp);
			function dialogPointerUp(evt)
			{
				DialogBox.checkVisibility(dlg);
				document.removeEventListener("pointermove", dialogPointerMove);
				document.removeEventListener("pointerup", dialogPointerUp);
			}

			document.addEventListener("pointermove", dialogPointerMove);
			function dialogPointerMove(evt)
			{
				evt.preventDefault();
				// calculate the new cursor position:
				let deltax = dlg.clientX - evt.clientX;
				let deltay = dlg.clientY - evt.clientY;
				dlg.clientX = evt.clientX;
				dlg.clientY = evt.clientY;
				dlg.style.top = "" + (dlg.offsetTop - deltay) + "px";
				dlg.style.left = "" + (dlg.offsetLeft - deltax) + "px";
			}
		}
	}
	
	static checkVisibility(div)
	{
		if (!div) return;
		let left = parseFloat(div.style.left);
		let width = div.offsetWidth;
		if ((left + width) > window.innerWidth) div.style.left = "" + (window.innerWidth - width) + "px";
		left = parseFloat(div.style.left);
		if (left < 0) div.style.left = 0;
		let top = parseFloat(div.style.top);
		let height = div.offsetHeight;
		if ((top + height) > window.innerHeight) div.style.top = "" + (window.innerHeight - height) + "px";
		top = parseFloat(div.style.top);
		if (top < 0) div.style.top = 0;
	}
	

	
	static reject(evt)
	{
		console.log("reject", evt.target.tagName)
		evt.stopPropagation();
	}
	
	static resize(evt)
	{
		evt.stopPropagation();
		evt.target.style.width = "" + window.innerWidth() + "px";
		evt.target.style.height = "" + window.innerHeight() + "px";
	}
	
	static pop()
	{
		let dlg = DialogBox.stack.pop();
		document.body.removeChild(dlg.guard);
	}
	
	release()
	{
		DialogBox.stack.pop();
		document.body.removeChild(this.parentElement);
	}

	appendButtonParagraph()
	{
		this.buttonParagraph = document.createElement("p")
		this.appendChild(this.buttonParagraph)
	}
	
	appendButton(innerHTML, callback)
	{
		if (!this.buttonParagraph) this.appendButtonParagraph()
		let button = document.createElement("button")
		if (callback) button.privateCallback = callback;
		button.style.marginRight = "0.5em"
		button.innerHTML = innerHTML;
		this.buttonParagraph.appendChild(button)
		button.addEventListener("click", DialogBox.buttonHandler)
		return(button);
	}

	static buttonHandler(evt)
	{
		let element = evt.target;
		if (element.privateCallback)
		{
			element.privateCallback(evt);
		}
		else
		{
			DialogBox.pop();
		}
	}

	createRadioButtonSpan(labelHTML, name, value, checked)
	{
		let span = document.createElement("span");

		span.input = document.createElement("input");
		span.appendChild(span.input);
		span.input.id = "radio" + Math.round(Math.random() * 100000000);
		span.input.type = "radio";
		span.input.name = name;
		span.input.value = value;
		if (checked) span.input.checked = checked;

		span.label = document.createElement("label");
		span.appendChild(span.label);
		span.label.innerHTML = labelHTML;
		span.label.setAttribute("for", span.input.id);
		span.label.style.marginRight = "1em"
		return(span);
	}
	
	getRadioButtonValue(name)
	{
//		let element = evt.target;
//		while ((element) && (element.className.toLowerCase() != "dialogbox")) element = element.parentElement;
//		if (!element) return;
		let inputs = this.getElementsByTagName("input");
		for (let i = 0; i < inputs.length; i ++)
		{
			if (inputs[i].name === name)
			{
				if (inputs[i].checked) return(inputs[i].value);
			}
		}
		return(false);
	}
	
	static cancelButtonHandler(evt)
	{
		let element = evt.target;
		while ((element) && (element.className.toLowerCase() != "dialogbox")) element = element.parentElement;
		if (!element) return;
		let callback = element.cancelButtonCallback;
		DialogBox.stack.pop();
		document.body.removeChild(element.parentElement);
		if (callback) callback(evt);
	}

	// Just like append button but
	// 1. callback also fired by red X top right and
	// 2. dialog box is closed and goes away.
	appendCancelButton(innerHTML, callback)
	{
		if (!this.buttonParagraph) this.appendButtonParagraph()
		let button = document.createElement("button")
		button.style.marginRight = "0.5em"
		button.innerHTML = innerHTML;
		this.buttonParagraph.appendChild(button)
		this.cancelButtonCallback = callback;
		button.addEventListener("click", DialogBox.cancelButtonHandler)
		return(button);
	}

	appendParagraph(html)
	{
		let p = document.createElement("p");
		this.appendChild(p);
		if (html) p.innerHTML = html;
		return(p);
		
	}
	
	appendElement(tagName, html)
	{
		let element = document.createElement(tagName);
		this.appendChild(element);
		if (html) element.innerHTML = html;
		element.addEventListener("pointerdown", DialogBox.reject)

		return(element);
		
	}

	static alert(html)
	{
		let dlg = new DialogBox()
		let p = dlg.appendParagraph()
		p.innerHTML = html
		dlg.appendButton("OK")
	}


}

customElements.define('dialog-box', DialogBox, {extends: 'div'});

