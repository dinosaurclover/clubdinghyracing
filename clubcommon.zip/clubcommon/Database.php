<?php

/*


Fairly early on it turned out that using a numeric key for classes was awkward.



BEGIN;

DROP TABLE IF EXISTS newreg;
CREATE TEMPORARY TABLE newreg(
regKey INTEGER PRIMARY KEY,
regClassKey TEXT,
regSailNumber TEXT,
regSailEssence TEXT,
regHelmKey INTEGER,
regCrewKey INTEGER,
regExtraCrewKey INTEGER,
regHidden INTEGER,
regYYYYMMDD TEXT);

INSERT INTO newreg
SELECT
regKey, 
classEssence,
regSailNumber,
regSailEssence,
regHelmKey,
regCrewKey,
regExtraCrewKey,
regHidden,
regYYYYMMDD
FROM reg LEFT JOIN class ON regClassKey = classKey;

DROP TABLE reg;
CREATE TABLE reg(
regKey INTEGER PRIMARY KEY,
regClassKey TEXT,
regSailNumber TEXT,
regSailEssence TEXT,
regHelmKey INTEGER,
regCrewKey INTEGER,
regExtraCrewKey INTEGER,
regHidden INTEGER,
regYYYYMMDD TEXT);

INSERT INTO reg SELECT * FROM newreg;

DROP TABLE newreg;

DROP TABLE IF EXISTS newclass;
CREATE TEMPORARY TABLE newclass(
classKey TEXT PRIMARY KEY,
className TEXT,
classPortsmouthNumber INTEGER,
classSource TEXT,
classSpinnaker TEXT,
classRig TEXT,
classCrew INTEGER,
classMultiHull TEXT,
classBaseName TEXT,
classAllowance INTEGER,
classHidden TEXT);

INSERT INTO newclass
SELECT 
classEssence,
className,
classPortsmouthNumber,
classSource,
classSpinnaker,
classRig,
classCrew,
classMultiHull,
classBaseName,
classAllowance,
classHidden
FROM class;

DROP TABLE class;

CREATE TABLE class(
classKey TEXT PRIMARY KEY,
className TEXT,
classPortsmouthNumber INTEGER,
classSource TEXT,
classSpinnaker TEXT,
classRig TEXT,
classCrew INTEGER,
classMultiHull TEXT,
classBaseName TEXT,
classAllowance INTEGER,
classHidden TEXT);

INSERT INTO class SELECT * FROM newclass;

DROP TABLE newclass;

COMMIT;




 */


class Database
{
//	const DATA_DIRECTORY_SPEC = "../warsash/clubdata";
//	const DATABASE_FILE_SPEC = "../warsash/clubdata/database.sql3";
//	const DATABASE_LOG_SPEC = "../clubdata/database.log";
//	const CONFIG_SCRIPT_FILE_SPEC = "../warsash/clubdata/configuration.script";

	const DATA_DIRECTORY_SPEC = "../clubdata";
	const DATABASE_FILE_SPEC = "../clubdata/database.sql3";
	const DATABASE_LOG_SPEC = "../clubdata/database.log";
	const CONFIG_SCRIPT_FILE_SPEC = "../clubdata/configuration.script";

	const BUSY_TIMEOUT_SECONDS = 5;

	private $db;

	function __construct()
	{
		if (!($this->db = new SQLite3(Database::DATABASE_FILE_SPEC)))
		{
			$object = new stdClass();
			$object->trace = debug_backtrace();
			$object->errorMessage = "Open database failure (" . Database::DATABASE_FILE_SPEC . ")";
			echo(json_encode($object, JSON_PRETTY_PRINT));
			exit();
		}


		$this->inititialise();

		$unixEpochSecondsFile = filemtime(Database::CONFIG_SCRIPT_FILE_SPEC);
		$unixEpochSecondsStored = $this->querySingle("SELECT unixEpochSecondsModified FROM namedValues  WHERE name='configScript'");
		if (!empty($unixEpochSecondsStored))
		{
			$unixEpochSecondsStored = intval($unixEpochSecondsStored);
		}

		if (empty($unixEpochSecondsStored) || ($unixEpochSecondsFile != $unixEpochSecondsStored))
		{
			if (($s = file_get_contents(Database::CONFIG_SCRIPT_FILE_SPEC)) === false)
			{
				$object = new stdClass();
				$object->error = error_get_last();
				$object->trace = debug_backtrace();
				$object->errorMessage = "Read configuration script file failure (" . Database::CONFIG_SCRIPT_FILE_SPEC . ")";
				echo(json_encode($object, JSON_PRETTY_PRINT));
				exit();
			}

			$this->items = Database::parseConfigScript();

			$statements = array();

			if ($unixEpochSecondsStored > 0)
			{
				$fmt = "UPDATE namedValues SET unixEpochSecondsModified=" . $unixEpochSecondsFile
				. ",value=" . $this->quote($s)
				. ",whoModified='system'"
				. " WHERE name='configScript'";
			}
			else
			{
				$fmt = "INSERT INTO namedValues VALUES('configScript'," 
						. $this->quote($s) . "," 
						. $unixEpochSecondsFile
						. ",'system')";
			}
			array_push($statements, $fmt);

			$names = array();
			$fmt = "SELECT name FROM namedValues";
			if (!empty($result = $this->query($fmt)))
			{
				while ($cells = $result->fetchArray(SQLITE3_NUM))
				{
					$names[$cells[0]] = true;
				}
			}
			$keys = array_keys($this->items);
			foreach($keys as $key)
			{
				$s = json_encode($this->items[$key], JSON_PRETTY_PRINT);
				if ($names[$key])
				{
					$fmt = "UPDATE namedValues SET unixEpochSecondsModified=" . time() 
								. ",value=" . $this->quote($s) 
								. ",whoModified='system'"
								. " WHERE name=" . $this->quote($key);
				}
				else
				{
					$fmt = "INSERT INTO namedValues VALUES(" . $this->quote($key) . ","
						. $this->quote($s) . "," 
						. time()  . ","
						. "'system')";
					
				}
				array_push($statements, $fmt);
			}
			$this->execArray($statements);
		}
	}

	static function getRawSqlite3Object()
	{
		$db = new SQLite3(Database::DATABASE_FILE_SPEC);
		return($db);
	}

	// Ensure that all the required tables are created
	public function inititialise()
	{
		$fmt = "SELECT name,sql FROM sqlite_master WHERE type='table'";
		$result = $this->query($fmt);

		$found = array();
		while ($cells = $result->fetchArray(SQLITE3_NUM))
		{
			if ($cells[0] === "signon")
			{
				if (strpos($cells[1], "signonHelmKey") > 0)
				{
					$found[$cells[0]] = true;
				}
				else
				{
					// Got this wrong to start off with
					$this->exec("DROP TABLE signon");
				}
			}
			else
			{
				$found[$cells[0]] = true;
			}
		}

		if (!$found[$name = "sailor"])
		{
			$spec = ""
				. "sailorKey INTEGER PRIMARY KEY,"
				. "sailorName TEXT,"
				. "sailorEssence TEXT,"
				. "sailorMembershipNumber TEXT,"
				. "sailorMailAddress TEXT,"
				. "sailorTelephone TEXT,"
				. "sailorPB2 INTEGER,"
				. "sailorIceName TEXT,"
				. "sailorIceTelephone TEXT,"
				. "sailorUnixEpochSeconds INTEGER,"			// Non-zero indicates a guest
				. "sailorHidden Text";
			$fmt = "CREATE TABLE IF NOT EXISTS " . $name . "(" . $spec . ")";
			$this->exec($fmt);

			$fmt = "CREATE INDEX IF NOT EXISTS sailorEssence ON sailor(sailorEssence)";
			$this->exec($fmt);
		}

		if (!$found[$name = "class"])
		{
			$spec = ""
				. "classKey TEXT PRIMARY KEY,"
				. "className TEXT,"
				. "classPortsmouthNumber INTEGER,"
				. "classSource TEXT,"
				. "classSpinnaker TEXT,"
				. "classRig TEXT,"
				. "classCrew INTEGER,"
				. "classMultiHull TEXT,"
				. "classHidden TEXT";
			$fmt = "CREATE TABLE IF NOT EXISTS " . $name . "(" . $spec . ")";
			$this->exec($fmt);


		}


		if (!$found[$name = "reg"])
		{
			$spec = ""
				. "regKey INTEGER PRIMARY KEY,"
				. "regClassKey TEXT,"
				. "regSailNumber TEXT,"
				. "regSailEssence TEXT,"
				. "regHelmKey INTEGER,"
				. "regCrewKey INTEGER,"
				. "regExtraCrewKey INTEGER,"
				. "regHidden INTEGER,"
				. "regYYYYMMDD TEXT";
			$fmt = "CREATE TABLE IF NOT EXISTS " . $name . "(" . $spec . ")";
			$this->exec($fmt);
		}

		if (!$found[$name = "signon"])
		{
			$spec = ""
				. "signonKey INTEGER PRIMARY KEY,"
				. "signonHelmKey,"
				. "signonRegKey INTEGER,"
				. "signonType TEXT,"
				. "signonDeclaration TEXT,"
				. "signonUnixEpochSeconds INTEGER";
			$fmt = "CREATE TABLE IF NOT EXISTS " . $name . "(" . $spec . ")";
			$this->exec($fmt);

			$fmt = "CREATE INDEX IF NOT EXISTS signonsUnixEpochSeconds ON signon(signonUnixEpochSeconds)";
			$this->exec($fmt);
		}


		// Note
		// ClassName, sailNumber, helmName, crewName, extraCrewName are stored explicitly
		// They can be queried fron the reg table and the sailor table but
		// storing them explicitly makes this table stand alone if necessary.
		// It will contain all information required to calculate the races and the series.
		if (!$found[$name = "result"])
		{
			$spec = ""
				. "resultRegKey INTEGER,"
				. "resultCupName TEXT,"
				. "resultCupEssence TEXT,"
				. "resultYear INTEGER,"
				. "resultRaceNumber INTEGER,"
				. "resultFleet TEXT,"
				. "resultYYYYMMDD TEXT,"

				. "resultClassName TEXT,"
				. "resultSailNumber TEXT,"
				. "resultHelmName TEXT,"
				. "resultCrewName TEXT,"
				. "resultExtraCrewName TEXT,"
				
				. "resultPortsmouthNumber INTEGER,"
				. "resultStartHHMMSS TEXT,"
				. "resultLaps INTEGER,"
				. "resultFinishHHMMSS TEXT,"
				. "resultFinishingCode TEXT,"
				. "resultAttributes TEXT,"
				. "resultSignedOff TEXT,"
				. "resultDeclaration TEXT,"
				. "resultRdgScore REAL,"
				. "PRIMARY KEY(resultRegKey,resultCupEssence,resultYear,resultRaceNumber)";
			$fmt = "CREATE TABLE IF NOT EXISTS " . $name . "(" . $spec . ")";
			$this->exec($fmt);
		}


		if (!$found[$name = "resultArchive"])
		{
			$spec = ""
				. "cupYearFleetEssence TEXT PRIMARY KEY"
				. ",cupYearFleet TEXT"
				. ",jsonEncodedData TEXT";
			$fmt = "CREATE TABLE IF NOT EXISTS " . $name . "(" . $spec . ")";
			$this->exec($fmt);
		}


		if (!$found[$name = "namedValues"])
		{
			$spec = ""
				. "name TEXT"
				. ",value TEXT"
				. ",unixEpochSecondsModified INTEGER"
				. ",whoModified TEXT"
				. ",PRIMARY KEY(name)";
			$fmt = "CREATE TABLE IF NOT EXISTS " . $name . "(" . $spec . ")";
			$this->exec($fmt);
		}


		// users table for admin login
		if (!$found[$name = "users"])
		{
			$spec = ""
				. "user_id INTEGER PRIMARY KEY,"
				. "user_name TEXT NOT NULL UNIQUE,"
				. "user_password_hash TEXT NOT NULL,"
				. "user_email TEXT NOT NULL UNIQUE,"
				. "user_active INTEGER NOT NULL DEFAULT '0',"
				. "user_activation_hash TEXT DEFAULT NULL,"
				. "user_password_reset_hash TEXT DEFAULT NULL,"
				. "user_password_reset_timestamp INTEGER DEFAULT NULL,"
				. "user_rememberme_token TEXT DEFAULT NULL,"
				. "user_failed_logins INTEGER NOT NULL DEFAULT '0',"
				. "user_last_failed_login INTEGER DEFAULT NULL,"
				. "user_registration_datetime TEXT NOT NULL DEFAULT '1000-01-01 00:00:00',"
				. "user_registration_ip TEXT DEFAULT '0.0.0.0'";
			$fmt = "CREATE TABLE IF NOT EXISTS " . $name . "(" . $spec . ")";
			$this->exec($fmt);
		}

		// Need some views for digging out class names and sailor names in the reg table

		$fmt = "CREATE VIEW IF NOT EXISTS viewreghelm AS" 
				. " SELECT regKey, sailorName FROM reg LEFT JOIN sailor ON reghelmKey = sailorKey";
		$this->exec($fmt);

		$fmt = "CREATE VIEW IF NOT EXISTS viewregcrew AS" 
				. " SELECT regKey, sailorName FROM reg LEFT JOIN sailor ON regcrewKey = sailorKey";
		$this->exec($fmt);

		$fmt = "CREATE VIEW IF NOT EXISTS viewregextracrew AS" 
				. " SELECT regKey, sailorName FROM reg LEFT JOIN sailor ON regextracrewKey = sailorKey";
		$this->exec($fmt);

		$fmt = "CREATE VIEW IF NOT EXISTS viewregclass AS"
				. " SELECT regKey, className, classPortsmouthNumber FROM reg LEFT JOIN class ON regClassKey = classKey";
		$this->exec($fmt);

		$fmt = "CREATE VIEW IF NOT EXISTS viewreg AS"
				. " SELECT reg.*, viewregclass.className AS className, viewregclass.classPortsmouthNumber AS portsmouthNumber, regSailNumber AS sailNumber, viewreghelm.sailorName AS helmName, viewregcrew.sailorName AS crewName, viewregextracrew.sailorName AS extraCrewName"
				. " FROM reg,viewregclass,viewreghelm,viewregcrew,viewregextracrew"
				. " WHERE viewreghelm.regKey = reg.regKey"
				. " AND viewregcrew.regKey = reg.regKey"
				. " AND viewregextracrew.regKey = reg.regKey"
				. " AND viewregclass.regKey = reg.regKey";
		$this->exec($fmt);





	}

	public function getUserById($user_id)
	{
		$fmt = "SELECT * FROM users WHERE user_id=" . $user_id;
		return($this->db->querySingle($fmt, true));
	}

	public function getUserByEmail($user_email)
	{
		$fmt = "SELECT * FROM users WHERE user_email LIKE " . $this->quote($user_email);
		return($this->db->querySingle($fmt, true));
	}

	public function getUserByName($user_name)
	{
		$fmt = "SELECT * FROM users WHERE user_name LIKE " . $this->quote($user_name);
		return($this->db->querySingle($fmt, true));
	}

	public function setUserValue($user_id, $columnName, $value)
	{
		$fmt = "UPDATE users SET " . $columnName . "= " . $this->quote($value) . " WHERE user_id=" . $user_id;
		return($this->db->exec($fmt));
	}

	public function insertUser($user_name, $user_password_hash, $user_email, $user_activation_hash)
	{
		$fmt = "INSERT INTO users (user_name, user_password_hash, user_email, user_activation_hash, user_registration_ip, user_registration_datetime)"
			. " VALUES("
			. $this->quote($user_name) . ","
			. $this->quote($user_password_hash) . ","
			. $this->quote($user_email) . ","
			. $this->quote($user_activation_hash) . ","
			. $this->quote($_SERVER["REMOTE_ADDR"]) . ","
			. "datetime())";
		return($this->db->exec($fmt));
	}

	public function deleteUserById($user_id)
	{
		$this->exec("DELETE FROM users WHERE user_id=" . $user_id);
	}

	public function quote($s)
	{
		if (empty($s)) return("NULL");

		switch (gettype($s))
		{
			case "integer": return($s);
			case "double": return($s);
		}

		switch (gettype($s))
		{
			case "boolean": return(1);
			case "NULL": return("NULL");
			case "string":
			{
				$s = trim($s);
				if ($s == "")
				{
					return("NULL");
				}
				return("'" . $this->db->escapeString($s) . "'");
			}
			default: return("NULL");
		}
		return("NULL");
	}

	public function getValue($name)
	{
		$s = $this->querySingle("SELECT value FROM namedValues WHERE name LIKE " . $this->quote($name));
		return(json_decode($s));
	}

	public function getValueArray($name)
	{
		$s = $this->querySingle("SELECT value FROM namedValues WHERE name LIKE " . $this->quote($name));
		return((array)json_decode($s));
	}

	public function setValue($name, $value)
	{
		if (empty($this->querySingle("SELECT name FROM namedValues WHERE name LIKE " . $this->quote($name))))
		{
			$fmt = "UPDATE namedValues SET value=" . $this->quote($value) . " WHERE name LIKE " . $this->quote($name);
			$this->exec("UPDATE");
		}
		return($this->querySingle("SELECT value FROM namedValues WHERE name LIKE " . $this->quote($name)));
	}

	public function removeValue($name)
	{
		$fmt = "DELETE FROM namedValues WHERE name LIKE " . $this->quote($name);
		$this->exec("UPDATE");
	}

	public function retrieveValue($tableName, $columnName, $key)
	{
		$fmt = "SELECT " . $columnName
				. " FROM " . $tableName
				. " WHERE " . $tableName . "Key=" . $key; 
		return($this->querySingle($fmt));
	}

	public function getSailorNameBySailorKey($sailorKey)
	{
		if (empty($sailorKey))
		{
			return(null);
		}
		$fmt = "SELECT sailorName FROM sailor WHERE sailorKey=" . $sailorKey;
		return($this->querySingle($fmt));
	}
	public function getSailorKeyBySailorName($sailorName)
	{
		$essence = Misc::essence($sailorName);
		$fmt = "SELECT sailorKey FROM sailor WHERE sailorEssence=" . $this->quote($essence);
		return($this->querySingle($fmt));
	}
	public function getSailorNameBySailorEssence($sailorEssence)
	{
		$fmt = "SELECT sailorName FROM sailor WHERE sailorEssence=" . $this->quote($sailorEssence);
		return($this->querySingle($fmt));
	}

	public function getClassNameByClassKey($classKey)
	{
		if (empty($classKey))
		{
			return(null);
		}
		$fmt = "SELECT className FROM class WHERE classKey=" . $this->quote($classKey);
		return($this->querySingle($fmt));
	}
	public function getClassKeyByClassName($className)
	{
		$essence = Misc::essence($className);
		$fmt = "SELECT classKey FROM class WHERE classKey=" . $this->quote($essence);
		return($this->querySingle($fmt));
	}

	public function getPortsmouthNumberByClassName($className)
	{
		$essence = Misc::essence($className);
		$fmt = "SELECT classPortsmouthNumber FROM class WHERE classKey=" . $this->quote($essence);
		return($this->querySingle($fmt));
	}

	private function appExit()
	{
		$object = new stdClass();
		$object->trace = debug_backtrace();
		$object->errorMessage = $this->lastErrorMessage;
		$object->errorCode = $this->lastErrorCode;
		$this->db->exec("ROLLBACK");
		echo(json_encode($object, JSON_PRETTY_PRINT));
		exit();
	}
	public function query($fmt)
	{
		$count = Database::BUSY_TIMEOUT_SECONDS;
		while (($count > 0) && (($result = $this->db->query($fmt)) === false))
		{
			if ($this->db->lastErrorCode() === 5)
			{
				sleep(1);
				$count --;
			}
			else
			{
				$this->lastErrorCode = $this->db->lastErrorCode();
				$this->lastErrorMessage = $this->db->lastErrorMsg();
				$this->appExit();
			}
		}

		if ($count === 0)
		{
			$this->lastErrorCode = $this->db->lastErrorCode();
			$this->lastErrorMessage = $this->db->lastErrorMsg();
			$this->appExit();
		}

		return($result);
	}

	public function lastInsertRowId()
	{
		return($this->db->lastInsertRowId());
	}

	public function querySingle($fmt, $entireRow = false)
	{
		$count = Database::BUSY_TIMEOUT_SECONDS;
		while (($count > 0) && (($result = $this->db->querySingle($fmt, $entireRow)) === false))
		{
			if ($this->db->lastErrorCode() === 5)
			{
				sleep(1);
				$count --;
			}
			else
			{
				$this->lastErrorCode = $this->db->lastErrorCode();
				$this->lastErrorMessage = $this->db->lastErrorMsg();
				$this->appExit();
			}
		}

		if ($count === 0)
		{
			$this->lastErrorCode = $this->db->lastErrorCode();
			$this->lastErrorMessage = $this->db->lastErrorMsg();
			$this->appExit();
		}

		return($result);
	}

	public function exec($fmt)
	{
		$count = Database::BUSY_TIMEOUT_SECONDS;
		while (($count > 0) && ($this->db->exec("BEGIN IMMEDIATE") === false))
		{
			if ($this->db->lastErrorCode() === 5)
			{
				sleep(1);
				$count --;
			}
			else
			{
				$this->lastErrorCode = $this->db->lastErrorCode();
				$this->lastErrorMessage = $this->db->lastErrorMsg();
				$this->appExit();
			}
		}

		if ($count === 0)
		{
			$this->lastErrorCode = $this->db->lastErrorCode();
			$this->lastErrorMessage = $this->db->lastErrorMsg();
			$this->appExit();
		}

		if ($this->db->exec($fmt) === false)
		{
			$this->lastErrorCode = $this->db->lastErrorCode();
			$this->lastErrorMessage = $this->db->lastErrorMsg();
			$this->appExit();
		}

//		file_put_contents(Database::DATABASE_LOG_SPEC, "-- " . round(microtime(true) * 1000) . "\n", FILE_APPEND);
//		file_put_contents(Database::DATABASE_LOG_SPEC, $fmt . "\n", FILE_APPEND);

		if ($this->db->exec("COMMIT") === false)
		{
			$this->lastErrorCode = $this->db->lastErrorCode();
			$this->lastErrorMessage = $this->db->lastErrorMsg();
			$this->db->exec("ROLLBACK");
			$this->appExit();
		}
	}

// To avoid encountering SQLITE_BUSY errors in the middle of a transaction,
// the application can use BEGIN IMMEDIATE instead of just BEGIN to start
// a transaction. The BEGIN IMMEDIATE command might itself return
// SQLITE_BUSY, but if it succeeds, then SQLite guarantees that no
// subsequent operations on the same database through the next COMMIT
// will return SQLITE_BUSY.
//
	public function execArray($statements)
	{
		$count = Database::BUSY_TIMEOUT_SECONDS;
		while (($count > 0) && ($this->db->exec("BEGIN IMMEDIATE") === false))
		{
			if ($this->db->lastErrorCode() === 5)
			{
				sleep(1);
				$count --;
			}
			else
			{
				$this->lastErrorCode = $this->db->lastErrorCode();
				$this->lastErrorMessage = $this->db->lastErrorMsg();
				$this->appExit();
			}
		}

		if ($count === 0)
		{
			$this->lastErrorCode = $this->db->lastErrorCode();
			$this->lastErrorMessage = $this->db->lastErrorMsg();
			$this->appExit();
		}

		foreach($statements as $fmt)
		{
			if ($this->db->exec($fmt) === false)
			{
				$this->lastErrorCode = $this->db->lastErrorCode();
				$this->lastErrorMessage = $this->db->lastErrorMsg();
				$this->db->exec("ROLLBACK");
				$this->appExit();
			}
		}

//		file_put_contents(Database::DATABASE_LOG_SPEC, "-- " . round(microtime(true) * 1000) . "\n", FILE_APPEND);
//		file_put_contents(Database::DATABASE_LOG_SPEC, implode("\n", $statements) . "\n", FILE_APPEND);


		if ($this->db->exec("COMMIT") === false)
		{
			$this->lastErrorCode = $this->db->lastErrorCode();
			$this->lastErrorMessage = $this->db->lastErrorMsg();
			$this->db->exec("ROLLBACK");
			$this->appExit();
		}
	}

	public function getSchema($tableName)
	{
		$fmt = "SELECT sql FROM sqlite_master WHERE type='table' and name= '" . $tableName . "'";
		return($this->querySingle($fmt));
	}

	/*
	public function parseConfigScript($s)
	{
		$this->items = array();
		$lines = explode("\n", $s);
		$linenumber = 0;
		foreach ($lines as $line)
		{
			$linenumber++;
			$this->parseConfigScriptLine($line);
		}
		return($this->items);
	}

	private function parseConfigScriptLine($line)
	{
		$arrayPattern = "/^\s*([a-z][a-z0-9]*)\[\s*([a-z0-9][a-z0-9]*\s*[a-z][a-z0-9.@]*)\s*\]\s*\:(.*)/i";
		$stringPattern = "/^\s*([a-z][a-z0-9]*)\s*\=(.*)/i";

		$matches = array();
		if (preg_match($stringPattern, $line, $matches))
		{
			// someVariableName = someValue
			if (!empty($value = $matches[2]))
			{
				$name = trim($matches[1]);
				$this->items[$name] = trim($value);
			}
		}
		else if (preg_match($arrayPattern, $line, $matches))
		{
			if (!empty($key = $matches[2]) && !empty($value = $matches[3]))
			{
				$name = trim($matches[1]);
				if (empty($this->items[$name]))
				{
					$this->items[$name] = array();
				}
				$item = array();
				if (strpos($value, "=") > 0)
				{
					// It's an object
					$bits = explode(",", $value);
					foreach($bits as $bit)
					{	
						$components = array();
						if (preg_match("/^\s*([a-z][a-z0-9]*)\s*\=(.*)/i", $bit, $components))
						{
							if (!empty($v = $components[2]))
							{
								$item[trim($components[1])] = trim($v);
							}
						}
					}
				}
				$this->items[$name][$key] = $item;

//				$this->debug = $this->items[$name][$key];
//				$this->debug = $this->items[$name][$key];
			}
		}
	}
	 * 
	 */

	public function getConfigurationScript()
	{
		return(file_get_contents(Database::CONFIG_SCRIPT_FILE_SPEC));
	}

	static function parseConfigScript($s = false)
	{
		$parser = new Parser($s);
		return($parser->toArray());
	}
}

class Parser
{
	function __construct($s)
	{
		if (!$s)
		{
			$s = file_get_contents(Database::CONFIG_SCRIPT_FILE_SPEC);
		}
		$this->parseConfigScript();
	}

	public function toArray()
	{
		return($this->items);
	}

	private function parseConfigScript()
	{
		$s = file_get_contents(Database::CONFIG_SCRIPT_FILE_SPEC);
		$this->items = array();
		$lines = explode("\n", $s);
		$linenumber = 0;
		foreach ($lines as $line)
		{
			$linenumber++;
			$this->parseConfigScriptLine($line);
		}
		return($this->items);
	}

	private function parseConfigScriptLine($line)
	{
//		$arrayPattern = "/^\s*([a-z][a-z0-9]*)\[\s*([a-z0-9][a-z0-9]*\s*[a-z][a-z0-9.@]*)\s*\]\s*\:(.*)/i";
		$arrayPattern = "/^\s*([a-z][a-z0-9]*)\[(.*)\]\s*\:(.*)/i";
		$stringPattern = "/^\s*([a-z][a-z0-9]*)\s*\=(.*)/i";

		$matches = array();
		if (preg_match($stringPattern, $line, $matches))
		{
			// someVariableName = someValue
			if (!empty($value = $matches[2]))
			{
				$name = trim($matches[1]);
				$this->items[$name] = trim($value);
			}
		}
		else if (preg_match($arrayPattern, $line, $matches))
		{
			if (!empty($key = $matches[2]) && !empty($value = $matches[3]))
			{
				$name = trim($matches[1]);
				if (empty($this->items[$name]))
				{
					$this->items[$name] = array();
				}
				$item = array();
				if (strpos($value, "=") > 0)
				{
					// It's an object
					$bits = explode(",", $value);
					foreach($bits as $bit)
					{	
						$components = array();
						if (preg_match("/^\s*([a-z][a-z0-9]*)\s*\=(.*)/i", $bit, $components))
						{
							if (!empty($v = $components[2]))
							{
								$item[trim($components[1])] = trim($v);
							}
						}
					}
				}
				$this->items[$name][$key] = $item;

//				$this->debug = $this->items[$name][$key];
//				$this->debug = $this->items[$name][$key];
			}
		}
	}
}