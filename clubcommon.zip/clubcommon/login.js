"use strict";

////////////////////////////////////////////////////////////////////
//
function loginSubmit(evt)
{
	evt.preventDefault();
	
	let code = document.getElementById("code").value.split(" ").join("");

	// DOES THE SERVER LIKE THIS CODE?
	let xmlhttp = commonCreateXMLHTTP();
	xmlhttp.successFunction = loginDeploy;
	xmlhttp.failureFunction = loginDisplay;
	xmlhttp.code = code;
	xmlhttp.send("code=" + code + "&command=login");
}
//
//////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//
function loginOnInput(evt)
{
	document.getElementById("ok").disabled = true;

	let captcha = document.getElementById("captcha");
	if ((captcha) && (captcha.value.trim().length != 6)) return;

	let email = document.getElementById("email");
	if ((email) && (!email.value.trim())) return;

	let code = document.getElementById("code");
	if (code)
	{
		code = code.value;
		let bits = code.split(" ");
		code = bits.join("");
		if (code.length != 16) return;
	}
	document.getElementById("ok").disabled = false;
}
//
//////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//
function loginCallBack(input)
{
	let evt = {"input": input};
	loginOnInput(evt);
}
//
//////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//
function loginEmailSuccess(xmlhttp)
{
	mApp.scrollingDiv.innerHTML = "";

	let p = document.createElement("p");
	mApp.scrollingDiv.appendChild(p);
	p.innerHTML = "<b>NSC Sign-On</b>";
	
	p = document.createElement("p");
	mApp.scrollingDiv.appendChild(p);
	p.innerHTML = "Your request for an email was received by the server.";

	p = document.createElement("p");
	mApp.scrollingDiv.appendChild(p);
	p.innerHTML = "If your email address was recognised by the server, an email is already on its way to you.";

	p = document.createElement("p");
	mApp.scrollingDiv.appendChild(p);
	p.innerHTML = "No email? Check your junk and spam folders. Did you type your email address carefully. For security reasons, if your email is not recognised, the server will silently ignore your request.";

	p = document.createElement("p");
	mApp.scrollingDiv.appendChild(p);
	p.innerHTML = "Click here for the login page.";

	p = document.createElement("p");
	mApp.scrollingDiv.appendChild(p);
	let button = document.createElement("button");
	p.appendChild(button);
	button.innerHTML = "Return to login page";
	button.addEventListener("click", loginDisplay);
}
//
//////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//
function loginEmailFailure(xmlhttp)
{
	if (xmlhttp.object.errorMessage)
	{
		let p = document.getElementById("message");
		if (p) p.innerHTML = xmlhttp.object.errorMessage;
	}
}
//
//////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//
function loginEmailSubmit(evt)
{
	evt.preventDefault();

	// IT SEEMS IMPOSSIBLE TO DERIVE THE ID OF THE BUTTON THAT CUSED THE SUBMIT
	// ONCLICK EVENT ON THE SUBMIT BUTTONS HAVE SET A GLOBAL VALUE
	if (mApp.submitValue == "Cancel")
	{
		loginDisplay();
		return;
	}
	
	let captcha = document.getElementById("captcha").value.trim().toUpperCase();
	let email = document.getElementById("email").value.trim();
	let sha256 = new jsSHA('SHA-256', 'TEXT');
	sha256.update(email.toLowerCase() + email.toUpperCase());
	let digest = sha256.getHash('HEX');

	// DOES THE SERVER LIKE THIS DIGEST?
	let xmlhttp = commonCreateXMLHTTP();
	xmlhttp.successFunction = loginEmailSuccess;
	xmlhttp.failureFunction = loginEmailFailure;
	xmlhttp.send("command=requestlink&captcha=" + captcha + "&digest=" + digest);
}
//
//////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//
function loginEmailCaptcha(evt)
{
	evt.target.setAttribute("src", "index.php?command=captcha&r=" + Math.random());
	document.getElementById("captcha").value = "";
	document.getElementById("ok").disabled = true;
}
//
//////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//
function loginEmailSetValue(evt)
{
	mApp.submitValue = evt.target.value;
}
//
//////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//
function loginOnGoogleSuccess(googleUser)
{
	console.log('Logged in as: ' + googleUser.getBasicProfile().getName());
}
//
//////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//
function loginOnGoogleFailure(error)
{
	console.log(error);
}
//
//////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//
function loginEmail(evt)
{
	mApp.scrollingDiv.innerHTML = "";
	
	let form = document.createElement("form");
	mApp.scrollingDiv.appendChild(form);

	let p = document.createElement("p");
	form.appendChild(p);
	p.innerHTML = "<b>NSC Sign-On</b>";

	p = document.createElement("p");
	p.id = "message";
	p.style.color = "red";
	form.appendChild(p);

	p = document.createElement("p");
	form.appendChild(p);
	p.innerHTML = "Don't know your NSC member's code?";
	
	p = document.createElement("p");
	form.appendChild(p);
	p.innerHTML = "Fill in the details below for an email";

	p = document.createElement("p");
	form.appendChild(p);
	p.innerHTML = "Email: ";

	let input = document.createElement("input");
	p.appendChild(input);
	input.type = "email";
	input.style.paddingLeft = "0.2em";
	input.style.fontSize = "150%";
	input.style.width = "17em";
	input.style.border = "black 1px solid";
	input.id = "email";
	input.addEventListener("input", loginOnInput);
	
	p = document.createElement("p");
	form.appendChild(p);
	p.innerHTML = "Apologies for the captcha.<br>Click the image for a new one if it's unreadable.";

	p = document.createElement("p");
	form.appendChild(p);
	let img = document.createElement("img");
	p.appendChild(img);
	img.style.border = "black 1px solid";
	img.style.width = "14em";
	img.src = "index.php?command=captcha";
	img.addEventListener("click", loginEmailCaptcha);

	p = document.createElement("p");
	form.appendChild(p);
	p.innerHTML = "Captcha: ";
	input = document.createElement("input");
	p.appendChild(input);
	input.type = "text";
	input.style.fontSize = "150%";
	input.style.paddingLeft = "0.2em";
	input.style.width = "5em";
	input.autocapitalize = "characters";
	input.style.border = "black 1px solid";
	input.id = "captcha";
	input.addEventListener("input", loginOnInput);
	input = document.createElement("input");
	p.appendChild(input);
	input.type = "submit";
	input.style.marginLeft = "0.4em";
	input.style.fontSize = "150%";
	input.value = "OK";
	input.id = "ok";
	input.disabled = true;
	input.addEventListener("click", loginEmailSetValue);
	
	input = document.createElement("input");
	p.appendChild(input);
	input.type = "submit";
	input.style.marginLeft = "0.4em";
	input.style.fontSize = "150%";
	input.value = "Cancel";
	input.addEventListener("click", loginEmailSetValue);

	p = document.createElement("p");
	form.appendChild(p);
	p.innerHTML = "Type your email carefully.<br>If you make a mistake the server will silently ignore your request.";

	form.addEventListener("submit", loginEmailSubmit);
}
//
//
//////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//
function loginDisplay(xmlhttp)
{
	mApp.scrollingDiv.innerHTML = "";
	
	if ((xmlhttp) && (xmlhttp.object) && (xmlhttp.object.errorMessage))
	{
		alert(xmlhttp.object.errorMessage);
	}
	
	let form = document.createElement("form");
	mApp.scrollingDiv.appendChild(form);
	
	let p = document.createElement("p");
	form.appendChild(p);
	p.innerHTML = "<b>NSC Sign-On</b>";
	
	if ((xmlhttp) && (xmlhttp.object) && (xmlhttp.object.errorMessage))
	{
		p = document.createElement("p");
		form.appendChild(p);
		p.style.color = "red";
		p.innerHTML = xmlhttp.object.errorMessage;
	}

	p = document.createElement("p");
	form.appendChild(p);
	p.innerHTML = "The server needs your secret NSC member's code.";

	p = document.createElement("p");
	form.appendChild(p);
	p.innerHTML = "It's 16 digits long - like a credit card number.";

	p = document.createElement("p");
	form.appendChild(p);
	let input = document.createElement("input");
	p.appendChild(input);
	input.type = "text";
	input.style.fontSize = "150%";
	input.style.paddingLeft = "0.2em";
	input.style.width = "10em";
	input.className = "keyboard";
	input.style.border = "black 1px solid";
	input.id = "code";
	input.addEventListener("input", loginOnInput);

	input = document.createElement("input");
	p.appendChild(input);
	input.type = "submit";
	input.style.fontSize = "150%";
	input.style.marginLeft = "0.4em";
	input.id = "ok";
	input.value = "OK";
	input.disabled = true;

	p = document.createElement("p");
	form.appendChild(p);
	p.innerHTML = "&nbsp;";

	form.addEventListener("submit", loginSubmit);
	
	p = document.createElement("p");
	form.appendChild(p);
	p.innerHTML = "Don't know your NSC member's code? Click below.";

	p = document.createElement("p");
	mApp.scrollingDiv.appendChild(p);
	let button = document.createElement("button");
	p.appendChild(button);
	button.innerHTML = "I don't know my code number";
	button.addEventListener("click", loginEmail);
	
	keyboardInit(loginCallBack);

}
//
//////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//
function loginDeploy(xmlhttp)
{
	if ((xmlhttp) && (xmlhttp.object) && (xmlhttp.object.token))
	{
		mApp.token = xmlhttp.object.token;
		if (xmlhttp.code) localStorage.setItem("authorisationCode", xmlhttp.code);
		mApp.callBack();
		return;
	}
	alert("You made a mistake with your code or your code has been changed.");
}
//
//////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////
//
function loginOnResize()
{
	if (mApp.scrollingDiv)
	{
		mApp.scrollingDiv.style.width = "" + (window.innerWidth) + "px";
		mApp.scrollingDiv.style.height = "" + (window.innerHeight) + "px";
	}
	commonSetFontSize();
}
//
//////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//
function login(callback)
{
	mApp.callBack = callback;

	mApp.scrollingDiv.innerHTML = "";
	mApp.scrollingDiv.scrollTop = 0;
 
	// FOR THE LOBBY AREA SCREENS WE CAN SET THE USER CODE IN THE LINK
	// IS CODE IN THE QUERY
	let code = commonGetParameterByName("code");

	// OTHERWISE, TRY IN LOCAL STORAGE
	if (!code) code = localStorage.getItem("authorisationCode");
	if (!code)
	{
		// NO CODE. ASK USER FOR CODE
		loginDisplay();
		return;
	}

	// DOES THE SERVER LIKE THIS CODE?
	let xmlhttp = commonCreateXMLHTTP();
	xmlhttp.successFunction = loginDeploy;
	xmlhttp.failureFunction = loginDisplay;
	xmlhttp.code = code;
	xmlhttp.send("code=" + code + "&command=login");
}
//
//////////////////////////////////////////////////////////////////
