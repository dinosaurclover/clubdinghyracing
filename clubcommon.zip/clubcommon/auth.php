<?php

// Accepts connections from auth.js module on the client
// Server accesses the database for a list of autorised email addresses
// If the user has a valid token it is transmitted and checked.
// Must be within date.
// Emails must match.
// Ip addresses must match.
// Server side script names must match.
// hostnames must match.
// If check fails, client must request a challenge.
// Server returns the challenge and also emails a 6 digit key
// User inputs the key and client sends challenge and key back to server
// If all is OK, server returns a token. Client stores the token in local storage.


function authGetEnv($key)
{
	$s = $_SERVER[$key];
	if (!empty($s)) return($s);
	return(getenv($key));
}

function authErrorExit($message)
{
	$object = new stdClass();
	$object->errorMessage = $message;
	echo(json_encode($object));
	exit();
}

// Client provides account name when it first checks a token retrieved from local storage.
// Subsequently we just check that the token is OK and determine the account name from the md5 within it.
// Return an object that can be passed back to the client
function authCheckToken($context, $thorough)
{
	$token = authGetEnv("HTTP_TOKEN");
	if (empty($token)) authErrorExit("No Token");

	if ($thorough)
	{
		$email = strtolower(trim(commonGetFormValue("email", "")));
		if (empty($email)) authErrorExit("No email Address");
	}

	// APACHE PROVIDES THIS
	$hostName = authGetEnv("SERVER_NAME");
	$ipAddress = authGetEnv("HTTP_X_FORWARDED_FOR");
	if (empty($ipAddress)) $ipAddress = authGetEnv("REMOTE_ADDR");

	$scriptFileName = "Universal admin login procedure";

	$bits = explode(".", $token);
	if (count($bits) != 3) authErrorExit("Invalid Token");
	for ($i = 0; $i < 3; $i ++)
	{
		while (count($words = explode(" ", $bits[$i])) > 1) $bits[$i] = implode("", $words);
	}
	$sha256 = base64_encode(hash("sha256", $bits[0] . "." . $bits[1] . ".decade"));
	if ($sha256 == $bits[2])
	{
		$payload = json_decode(base64_decode($bits[1]));
		if (time() < $payload->time + (365 * 24 * 60 * 60))
		{
			if (($ipAddress == $payload->ipAddress) &&
				($hostName == $payload->hostName) &&
				($payload->scriptFileName == $scriptFileName))
			{
				// TOKEN IS GOOD. IS THE OWNER STILL ON  THE LIST?
				foreach($context->clubConfig->administrators as $name)
				{
					if (($payload->idMD5 == md5($name)) && ((!$thorough) || ($name == $email)))
					{
						$context->loginName = $name;
						$object = new stdClass();
						$object->token = $token;
						return($object);
					}
				}
			}
		}
	}
	authErrorExit("Invalid Token");
}

function authIssueToken($context)
{
	$email = strtolower(trim(commonGetFormValue("email", "")));
	if (empty($email)) authErrorExit("No email Address");

	$challenge = authGetEnv("HTTP_CHALLENGE");
	if (empty($challenge)) authErrorExit("No challenge");

	$key = strtolower(trim(commonGetFormValue("key", "")));
	if (empty($key)) authErrorExit("No key");

	// APACHE PROVIDES THIS
	$hostName = authGetEnv("SERVER_NAME");
	$ipAddress = authGetEnv("HTTP_X_FORWARDED_FOR");
	if (empty($ipAddress)) $ipAddress = authGetEnv("REMOTE_ADDR");

	$scriptFileName = "Universal admin login procedure";

	if ($challenge != base64_encode(hash("sha256", $hostName . "." . $ipAddress . $email . $key . $scriptFileName . ".decade")))
	{
		authErrorExit("Invalid Key");
	}

	$header->alg = "sha256";
	$header->type = "JWT";
	$header = base64_encode(json_encode($header));

	$payload = new stdClass();
	$payload->time = time();
	$payload->hostName = $hostName;
	$payload->ipAddress = $ipAddress;
	$payload->idMD5 = md5($email);
	$payload->scriptFileName = $scriptFileName;
	$payload = base64_encode(json_encode($payload));
	$signature = base64_encode(hash("sha256", $header . "." . $payload . ".decade"));

	$object = new stdClass();
	$object->token = $header . "." . $payload . "." . $signature;
	echo(json_encode($object));
	exit();
}

// Key is derived from today's date, ipaddress, hostname, script file name 
// Challenge is derived from key, ipaddress, hostname, script file name.
function authIssueChallenge($context)
{
	$email = strtolower(trim(commonGetFormValue("email", "")));
	if (empty($email)) authErrorExit("No email Address");

	$found = false;
	foreach($context->clubConfig->administrators as $name)
	{
		if ($email == $name) $found = true;
	}

	if (!$found) authErrorExit("Unrecognised Email Address");

	if (function_exists("random_bytes"))
	{
		$challenge = bin2hex(random_bytes(48));
	}
	else
	{
		$a = array();
		for ($i = 0; $i < 40; $i ++)
		{
			array_push($a, chr(mt_rand(0, 255)));
			$challenge = bin2hex(implode("", $a));
		}
	}

	// APACHE PROVIDES THIS
	$hostName = authGetEnv("SERVER_NAME");
	$ipAddress = authGetEnv("HTTP_X_FORWARDED_FOR");
	if (empty($ipAddress)) $ipAddress = authGetEnv("REMOTE_ADDR");
	$scriptFileName = "Universal admin login procedure";

	$s = hash("sha256", $hostName . "." . $ipAddress . date("Y-m-d") . $email . $scriptFileName . ".decade");
	$key = 100000 + hexdec(substr($s, 0, 10)) % 899999;
	file_put_contents(".key", $key);

	$address = $context->clubConfig->administrators[$i];
	$subject = "NSC administration - " . "your login key";
	if (function_exists("mail"))
	{
		$code = mail($email, $subject, $key);
		file_put_contents(".mailCode", $code);
	}

	$object = new stdClass();
	$object->challenge = base64_encode(hash("sha256", $hostName . "." . $ipAddress . $email . $key . $scriptFileName . ".decade"));
	echo(json_encode($object));


	exit();
}


