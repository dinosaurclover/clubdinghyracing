<?php

/*
  Copyright � 2019 Ian Rye, espforwindows
 */

/*

You can locate your files somewhere else if you like by changing the values here
Make sure that your php has read/write access to them
For apache, they need to be accessible to a user called www-data
Not sure about IIS - its'been a long time. Might be IUSR

If you're using a folder in your website directory, protect it.
There are other ways of doing it but for apache,
you can edit (or create) the .htaccess file and put the line 

Require all denied

PHP will be able to read and write to the folder but HTTP/S will be denied.
 
*/ 

define ("DATABASE_FILE_SPEC", "../clubdata/database.sql3");
define ("CONFIG_SCRIPT_FILE_SPEC", "../clubdata/config.script");
define ("CONFIG_JSON_FILE_SPEC", "../clubdata/config.json");
define ("MEMBERS_JSON_FILE_SPEC", "../clubdata/members.json");
define ("MEMBERS_XLSX_FILE_SPEC", "../clubdata/members.xlsx");
define ("LOG_TXT_FILE_SPEC", "../clubdata/log.txt");


function sqlite_escape_string($context, $s)
{
	return($context->db->escapeString($s));
}

// If json file exists and is less than 24 hours old return it.
// If club database mysql read fails, return old json file if it exists.
function commonListSailors($context)
{
	clearstatcache();

	$object = false;

	if (file_exists(MEMBERS_JSON_FILE_SPEC))
	{
		$s = file_get_contents(MEMBERS_JSON_FILE_SPEC);
		$object = json_decode($s);
		if ((filemtime(MEMBERS_JSON_FILE_SPEC) > (time() + 24 * 60 * 60)))
		{
			return($object);
		}
	}

	$headers = "From: webmaster@netleysc.co.uk\r\nReply-To: ianrye@espforwindows.com\r\nX-Mailer: PHP/" . phpversion();

	// GET LIST OF MEMBERS FROM WEBSITE MYSQL DATABASE
	// mysql -hnetleysc.co.uk -unetley_raceman -pL3t5G0Rac!ng -Dnetley_netleysc
	$servername = "netleysc.uk";
	$username = "netley_raceman";
	$password = "L3t5G0Rac!ng";
	$port = 3306;
	$databasename = "netley_netleysc";
	$conn = new mysqli($servername, $username, $password, $databasename, $port);

	// CHECK CONNECTION
	if ($conn->connect_error)
	{
//		mail('ianrye@espforwindows.com', 'SignOn List Members', "Error: Failed mysql connect", $headers);
		return($object);
	}

	$members = array();

	$query = "SELECT DISTINCT member_lastname,member_firstname,member_number,member_sub_number,memberid,member_email from tblmember WHERE member_current>0";
	$result = $conn->query($query);
	if (!$result)
	{
		mail('ianrye@espforwindows.com', 'SignOn List Members', "Error: Failed member database select", $headers);
		return($object);
	}
	while ($row = $result->fetch_row())
	{
		$member = new stdClass();
		$lastname = $row[0];
		$lastname = explode("\"", $lastname);
		$lastname = implode("'", $lastname);
		$member->lastName = $lastname;

		$firstname = $row[1];
		$firstname = explode("\"", $firstname);
		$firstname = implode("'", $firstname);
		$member->firstName = $firstname;

		$member->number = $row[2];
		$member->subNumber = $row[3];
		$member->id = $row[4];
		$member->email = $row[5];

		if (json_encode($member))
		{
			array_push($members, $member);
		}
		else
		{
//			mail('ianrye@espforwindows.com', 'SignOn List Members', "Warning: json encode fail " . $member->id, $headers);
		}
	}

	$s = json_encode($members, JSON_PRETTY_PRINT);
	file_put_contents(MEMBERS_JSON_FILE_SPEC, $s);
	return($members);
}

function commonIsEmailValid($context, $email)
{
	$email = strtolower($email);
	$members = commonListSailors($context);
	foreach($members as $member)
	{
		if ($email == strtolower($member->email)) return(true);
	}
	return(false);
}

function commonGetFormValue($key, $default)
{
	error_reporting(0);
	$s = $_POST[$key];
	if (isset($s) == FALSE)
		$s = $_GET[$key];
	error_reporting(E_ERROR | E_PARSE);

	if (isset($s) != FALSE)
		$s = trim($s);
	else
		return($default);
	return($s);
}

function commonGetTask()
{
	if (!($task = commonGetFormValue("jsonencodedtask", false)))
	{
		commonExitWithErrorMessage("Error - GetTask. Bad parameters");
	}
	if (!($task = json_decode($task)))
	{
		commonExitWithErrorMessage("Error - GetTask. Bad json encoding");
	}
	return($task);
}

function commonExitWithErrorMessage($message)
{
	$object = new stdClass();
	$object->errorMessage = $message;
	echo(json_encode($object));
	exit();
}

function commonExitWithErrorMessageDB($context)
{
	$object = new stdClass();
	$object->errorMessage = $context->db->lastErrorMsg();
	echo(json_encode($object));
	exit();
}

// Remove any non alphanumeric
function commonStrip($s)
{
	return(preg_replace("/[^A-Za-z0-9]/", '', $s));
}

// The original plan was for applications to use the default
// item if it was not specified.
// It makes life easier if we copy them here if they are not specified.

function commonCopyDefaults($config)
{
	$flights = array();
	foreach ($config->flights AS $flight)
	{
		$flights[strtolower(commonStrip($flight->name))] = $flight;
	}

	if (empty($config->startInterval))
		$config->startInterval = "3";
	if ($config->cups)
	{
		for ($i = 0; $i < count($config->cups); $i++)
		{
			if (!$config->cups[$i]->startInterval)
			{
				$config->cups[$i]->startInterval = $config->startInterval;
			}
			if (!$config->cups[$i]->dutyCodes)
			{
				if (($config->cups[$i]->regatta))
					$config->cups[$i]->dutyCodes = $config->regattaDutyCodes;
				else
					$config->cups[$i]->dutyCodes = $config->seriesDutyCodes;
			}
			if (!($config->cups[$i]->discardProfile))
			{
				if (($config->cups[$i]->regatta))
					$config->cups[$i]->discardProfile = $config->regattaDiscardProfile;
				else
					$config->cups[$i]->discardProfile = $config->seriesDiscardProfile;
			}
			if (!($config->cups[$i]->scoringSystem))
			{
				$config->cups[$i]->scoringSystem = $config->scoringSystem;
			}
			if (empty($config->cups[$i]->starts))
			{
				commonError($config->cups[$i]->name . ". Missing starts value.");
			}
		}
	}
}

function commonFormSlashArray($value)
{
	$a = explode("/", $value);
	for ($i = 0; $i < count($a); $i++)
		$a[$i] = trim($a[$i]);
	return($a);
}

// Some symbols will cause problems for the parser.

function commonTranslate($value)
{
	$value = preg_replace('/\s+/', ' ', $value);
	for ($i = 0; $i < 10; $i++)
		$value = preg_replace('/\bOR\b/i', '||', $value);
	for ($i = 0; $i < 10; $i++)
		$value = preg_replace('/\bAND\b/i', '&&', $value);
	for ($i = 0; $i < 10; $i++)
		$value = preg_replace('/\bNOT LIKE\b/i', '.toLowerCase() !=', $value);
	for ($i = 0; $i < 10; $i++)
		$value = preg_replace('/\bLIKE\b/i', '.toLowerCase() ==', $value);
	for ($i = 0; $i < 10; $i++)
		$value = preg_replace('/\bNOT\b/i', '!', $value);
	for ($i = 0; $i < 10; $i++)
		$value = preg_replace('/\bGREATER THAN\b/i', '>', $value);
	for ($i = 0; $i < 10; $i++)
		$value = preg_replace('/\bLESS THAN\b/i', '<', $value);
	return($value);
}

function commonParseConfigLine($config, $line)
{
	$bits = explode(",", $line);

	if (empty($bits[0]))
		return(true);

	$components = array();

	$a = explode("=", $bits[0]);
	if (count($a) == 1)
		return(true);
	if (count($a) != 2)
		return(false);
	$a[0] = trim($a[0]);
	$a[1] = trim($a[1]);
	if (strpos($a[0], " ") !== false)
		return(true);
	array_push($components, array(trim($a[0]), trim($a[1])));

	if ((empty($components[0][0])))
		return(false);
	if ((empty($components[0][1])))
		return(false);

	for ($i = 1; $i < count($bits); $i++)
	{
		$a = explode("=", $bits[$i]);
		$count = count($a);
		if ($count > 0)
		{
			if ($count != 2)
			{
				return(false);
			}
			array_push($components, array(trim($a[0]), trim($a[1])));
			if ((empty($components[$i][0])))
				return(false);
		}
	}

	$key = strtolower($components[0][0]);
	switch ($key)
	{
		// EASY ONE-LINERS

		case "regattadiscardprofile": $config->regattaDiscardProfile = $components[0][1];
			break;
		case "raceofficerpassword": $config->raceofficerPassword = $components[0][1];
			break;
		case "raceofficermailaddress": $config->raceofficerMailAddress = $components[0][1];
			break;
		case "scoringsystem": $config->scoringSystem = $components[0][1];
			break;
		case "seriesdiscardprofile": $config->seriesDiscardProfile = $components[0][1];
			break;
		case "signonpassword": $config->signonPassword = $components[0][1];
			break;
		case "signoffpassword": $config->signoffPassword = $components[0][1];
			break;
		case "memberpassword": $config->memberPassword = $components[0][1];
			break;
		case "startinterval": $config->startInterval = $components[0][1];
			break;
		case "allowableduties": $config->allowableDuties = $components[0][1];
			break;
		case "timezone": $config->timeZone = $components[0][1];
			break;
		case "covid19": $config->covid19 = $components[0][1];
			break;

		case "administrator": array_push($config->administrators, $components[0][1]);
			break;
		case "regattadutycode": array_push($config->regattaDutyCodes, $components[0][1]);
			break;
		case "seriesdutycode": array_push($config->seriesDutyCodes, $components[0][1]);
			break;

		case "classname": {
				$object = new stdClass();
				$object->className = "" . $components[0][1];
				for ($i = 1; $i < count($components); $i++)
				{
					$key = $components[$i][0];
					$value = $components[$i][1];
					if (strtolower($key) == "basename")
						$object->baseName = $value;
					else if (strtolower($key) == "allowance")
						$object->allowance = $value;
					else if (strtolower($key) == "py")
						$object->py = $value;
					else if (strtolower($key) == "rig")
						$object->rig = $value;
					else if (strtolower($key) == "crew")
						$object->crew = $value;
					else if (strtolower($key) == "spinnaker")
						$object->spinnaker = $value;
					else if (strtolower($key) == "emailaddress")
						$object->emailAddress = $value;
					else
						return(false);
				}

				// THE PY MODULE NOW READS THE SCRIPT FILE ITSELF
				// $key = "_" . strtolower(pyStrip($object->className));
				// $config->classes->$key = $object;
				break;
			}

		case "flight": {
				$object = new stdClass();
				$object->name = "" . $components[0][1];
				for ($i = 1; $i < count($components); $i++)
				{
					$key = $components[$i][0];
					$value = $components[$i][1];
					if (strtolower($key) == "where")
						$object->where = $value;
					else
						return(false);
				}
				array_push($config->flights, $object);
				break;
			}

		case "scoringcode": {
				$object = new stdClass();
				$object->code = "" . strtoupper($components[0][1]);
				for ($i = 1; $i < count($components); $i++)
				{
					$key = $components[$i][0];
					$value = $components[$i][1];
					if (strtolower($key) == "description")
						$object->description = $value;
					else
						return(false);
				}
				array_push($config->scoringCodes, $object);
				break;
			}

		case "resource": {
				$object = new stdClass();
				$object->name = "" . $components[0][1];
				for ($i = 1; $i < count($components); $i++)
				{
					$key = $components[$i][0];
					$value = $components[$i][1];
					if (strtolower($key) == "type")
						$object->type = strtoupper($value);
					else
						return(false);
				}
				array_push($config->resources, $object);
				break;
			}

		case "pyadjustmentjs": {
				$value = $components[0][1];
				// SYMBOLS CAUSE A PROBLEM FOR THIS SIMPLE PARSER
				// COMMON TRANSLATE CONVERTS CERTAIN PHRASES TO SYMBOLS
				$value = commonTranslate($value);
				$config->pyAdjustmentJS = $value;
				break;
			}

		case "pyadjustmentphp": {
				$value = $components[0][1];
				// SYMBOLS CAUSE A PROBLEM FOR THIS SIMPLE PARSER
				// COMMON TRANSLATE CONVERTS CERTAIN PHRASES TO SYMBOLS
				$value = commonTranslate($value);
				$config->pyAdjustmentPHP = $value;
				break;
			}

		case "duty": {
				$object = new stdClass();
				$object->weight = 1;
				$object->specialist = false;
				$object->code = "" . $components[0][1];
				for ($i = 1; $i < count($components); $i++)
				{
					$key = $components[$i][0];
					$value = $components[$i][1];
					if (strtolower($key) == "type")
						$object->type = strtoupper($value);
					else if (strtolower($key) == "name")
						$object->name = $value;
					else if (strtolower($key) == "period")
						$object->period = $value;
					else if (strtolower($key) == "start")
						$object->start = $value;
					else if (strtolower($key) == "resourcetype")
						$object->resourceType = $value;
					else if (strtolower($key) == "weight")
						$object->weight = intval($value);
					else if (strtolower($key) == "specialist")
						$object->specialist = strtoupper($value);
					else
						return(false);
				}
				if (strtolower($object->specialist) == "no")
					$object->specialist = false;
				else if (strtolower($object->specialist) == "FALSE")
					$object->specialist = false;
				else if ($object->specialist)
					$object->specialist = true;
				array_push($config->duties, $object);
				break;
			}

		case "cup": {
				$object = new stdClass();
				$object->discardProfile = false;
				$object->starts = [];
				$object->sis = false;
				$object->status = false;
				$object->startInterval = false;
				$object->regatta = false;
				$object->scoringSystem = false;
				$object->dutyCodes = false;
				$object->name = "" . $components[0][1];
				for ($i = 1; $i < count($components); $i++)
				{
					$key = $components[$i][0];
					$value = $components[$i][1];
					if (strtolower($key) == "color")
						$object->color = $value;
					else if (strtolower($key) == "regatta")
						$object->regatta = $value;
					else if (strtolower($key) == "dutycodes")
						$object->dutyCodes = commonFormSlashArray($value);
					else if (strtolower($key) == "startinterval")
						$object->startInterval = $value;
					else if (strtolower($key) == "discardprofile")
						$object->discardProfile = $value;
					else if (strtolower($key) == "sis")
						$object->sis = $value;
					else if (strtolower($key) == "status")
						$object->status = $value;
					else if (strtolower($key) == "s1")
					{
						$bits = explode("/", $value);
						if (count($bits) == 2)
						{
							$start = new stdClass();
							$start->flag = trim($bits[0]);
							$start->flight = trim($bits[1]);
							$object->starts[1] = $start;
						}
					}
					else if (strtolower($key) == "s2")
					{
						$bits = explode("/", $value);
						if (count($bits) == 2)
						{
							$start = new stdClass();
							$start->flag = trim($bits[0]);
							$start->flight = trim($bits[1]);
							$object->starts[2] = $start;
						}
					}
					else if (strtolower($key) == "s3")
					{
						$bits = explode("/", $value);
						if (count($bits) == 2)
						{
							$start = new stdClass();
							$start->flag = trim($bits[0]);
							$start->flight = trim($bits[1]);
							$object->starts[3] = $start;
						}
					}
					else if (strtolower($key) == "s4")
					{
						$bits = explode("/", $value);
						if (count($bits) == 2)
						{
							$start = new stdClass();
							$start->flag = trim($bits[0]);
							$start->flight = trim($bits[1]);
							$object->starts[4] = $start;
						}
					}
					else
						return(false);
				}
				array_push($config->cups, $object);
				break;
			}

		case "yearplannercolumn": {
				$object = new stdClass();
				$object->name = "" . $components[0][1];
				for ($i = 1; $i < count($components); $i++)
				{
					$key = $components[$i][0];
					$value = $components[$i][1];
					if (strtolower($key) == "title")
						$object->title = $value;
					else if (strtolower($key) == "type")
						$object->type = strtolower($value);
					else
						return(false);
				}
				array_push($config->yearplannerColumns, $object);
				break;
			}

		case "imapserver": {
				$object = new stdClass();
				$object->URL = "" . $components[0][1];
				for ($i = 1; $i < count($components); $i++)
				{
					$key = $components[$i][0];
					$value = $components[$i][1];
					if (strtolower($key) == "accountname")
						$object->accountName = $value;
					else if (strtolower($key) == "password")
						$object->password = $value;
					else
						return(false);
				}
				$config->imapServer = $object;
				break;
			}

		default: return(false);
	}
	return(true);
}

function commonReadScript($context, $script)
{
	$lines = explode("\n", $script);
	$config = new stdClass();
	$config->administrators = array();
	$config->scoringCodes = array();
	$config->flights = array();
	$config->resources = array();
	$config->duties = array();
	$config->seriesDutyCodes = array();
	$config->regattaDutyCodes = array();
	$config->cups = array();
	$config->yearplannerColumns = array();

	$linenumber = 0;
	foreach ($lines as $line)
	{
		$linenumber++;
		if (!commonParseConfigLine($config, $line))
			commonError("Error in line " . $linenumber . ".");
	}

	commonCopyDefaults($config);

	$s = json_encode($config, JSON_PRETTY_PRINT);
	file_put_contents(CONFIG_JSON_FILE_SPEC, $s);

	return($config);
}

// If json file exists and is newer than the txt file use it
// Otherwise use the txt file;
// Pasword protected admin applications need the list of administators

function commonLoadConfiguration($keepadministratorlist = false)
{
	$config = false;

	clearstatcache();

	if (file_exists(CONFIG_JSON_FILE_SPEC))
	{
		if (file_exists(CONFIG_SCRIPT_FILE_SPEC))
		{
			if (filemtime(CONFIG_JSON_FILE_SPEC) > filemtime(CONFIG_SCRIPT_FILE_SPEC))
			{
				$s = file_get_contents(CONFIG_JSON_FILE_SPEC);
				$object = json_decode($s);
				if (!$keepadministratorlist) commonSanitise($object);
				if ($object->timeZone) date_default_timezone_set($object->timeZone);
				return($object);
			}
		}
	}

	$context = new stdClass();
	$db = commonDatabaseOpen($context);

	$script = @file_get_contents(CONFIG_SCRIPT_FILE_SPEC);
	$config = commonReadScript($context, $script);
	if (!$keepadministratorlist) commonSanitise($config);
	if ($object->timeZone) date_default_timezone_set($object->timeZone);
	return($config);
}

function commonError($message)
{
	$object = new stdClass();
	$object->errorMessage = $message;
	echo(json_encode($object));
	exit();
}

function commonErrorSQL($context)
{
	$object = new stdClass();
	$object->errorMessage = $context->db->lastErrorMsg();
	$context->db->exec("ROLLBACK");
	echo(json_encode($object));
	exit();
}

// If excel file exists and is newer than the sql3 file use it
// Otherwise use the sql3 file;

function commonLoadMembership($context)
{
	if (file_exists(MEMBERS_XLSX_FILE_SPEC))
	{
		if (!($db = commonDatabaseOpen($context)))
			return(false);
		if (!($xlsx = SimpleXLSX::parse($path . "xlsx")))
			return(false);
		if (!($rows = $xlsx->rows()))
			return(false);
		$lastname = false;
		$firstname = false;
		$email = false;
		for ($i = 0; $i < count($rows[0]); $i++)
		{
			switch (strtolower($rows[0][$i]))
			{
				case "lastname": $lastname = $i;
					break;
				case "firstname": $firstname = $i;
					break;
				case "email": $email = $i;
					break;
			}
		}
		if ($firstname === false)
			return(false);
		if ($lastname === false)
			return(false);
		if ($email === false)
			return(false);
		$db->exec("BEGIN");
		$db->exec("DROP TABLE IF EXISTS sailors");
		$db->exec("CREATE TABLE sailors(sha256 PRIMARY KEY,firstName,LastName,eMail)");
		for ($i = 1; $i < count($rows); $i++)
		{
			$row = $rows[$i];
			$s = implode("", $row);
			if (strpos($s, '"') === false)
			{
				$sha256 = hash('sha256', strtolower($row[$email]) . strtoupper($row[$email]));
				$fmt = 'INSERT INTO sailors VALUES("' . $sha256 . '","' . $row[$firstname] . '","' . $row[$lastname] . '","' . $row[$email] . '")';
				$db->exec($fmt);
			}
		}
		$db->exec("COMMIT");
		if (file_exists(MEMBERS_XLSX_FILE_SPEC . ".bak"))
			unlink(MEMBERS_XLSX_FILE_SPEC . ".bak");
		rename(MEMBERS_XLSX_FILE_SPEC, MEMBERS_XLSX_FILE_SPEC . ".bak");
	}
	return(false);
}

function commonMD5($context, $email)
{
	return(md5(strtolower($email) . $context->clubConfig->passkey));
}

// Common16 is a 16 digit decimal digest - good enough for unimportant use.

function common16($context, $email)
{
	$md5 = md5(strtolower($email) . $context->clubConfig->passkey, true);
	$result = array();
	for ($i = 0; $i < 16; $i++)
	{
		$result[$i] = chr(48 + (ord($md5[$i]) % 10));
	}
	return(implode("", $result));
}

// Check that this person (email address) is a member
// Client has submitted an sha256 of emaillowercase + emailuppercase.

function commonSendAdministratorLink($context, $dirname)
{
	$url = "http" . (!empty($_SERVER['HTTPS']) ? "s" : "") . "://" . $_SERVER['SERVER_NAME'] . $_SERVER['PHP_SELF'];
	$digest = commonGetFormValue("digest", false);
	commonLog($context, $url, $digest);

	// IS GIVEN EMAIL IN THE ADMIN LIST (JSON CONFIG FILE)
	for ($i = 0; $i < count($context->clubConfig->administrators); $i++)
	{
		$email = $context->clubConfig->administrators[$i]->email;
		$sha256 = hash('sha256', strtolower($email) . strtoupper($email));
		if ($sha256 == $digest)
		{
			commonLog($context, $url, $email);
			$message = $url . "?code=" . commonMD5($context, $email);
			$result = mail($email, $context->name . " " . $dirname . " new link.", $message);
			commonLog($context, "result|: ", $result);
			$context->clubConfig->passkey = "";
			return;
		}
	}

	commonLog($context, $url, "not found");
}

function commonDie($message)
{
//	$headers = "From: webmaster@pyracing.co.uk\r\nReply-To: ianrye@espforwindows.com\r\nX-Mailer: PHP/" . phpversion();
//	mail('ianrye@espforwindows.com', 'SignOn', "Error: Failed mysql connect", $headers);
	sleep(2);
	$object = new stdClass();
	$object->errorMessage = $message;
	echo(json_encode($object));
	return(false);
}


// The javascript standard saw fit to make the crypto functions
// asynchronous; possibly because they can be time consuming.
// Note that the digest is computed every time the user presses
// a key and we hope that processing is finished before the submit
// button is pressed. My understanding of the javascript event loop
// is that this will always be the case.
// Nasty - but the alternatives are awkward.

function commonRequestAdministratorLink($context)
{
	$html = ""
		. "<DOCTYPE html>\n"
		. "<html>\n"
		. "<head>\n"
		. "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>\n"
		. "<title>Signup</title>\n"
		. "<style>\n"
		. "body{-webkit-text-size-adjust:none;font-family:sans-serif;margin:0;padding:0.5em;}\n"
		. "p, ol, ul, li, table, tr, td, select, option, div, button, input, textarea{font-size:inherit;font-family:inherit;}\n"
		. "</style>\n"
		. "<script>\n";
	echo($html);

	readfile("../clubcommon/sha256.js");

	$html = ""
		. "\n"
		. "var mDigestInput = false;\n"
		. "\n"
		. "function signupOnInput(input)\n"
		. "{\n"
		. "	if (!mDigestInput) mDigestInput = document.getElementById('digest');\n"
		. "	var sha256 = new jsSHA('SHA-256', 'TEXT');\n"
		. "	sha256.update(input.value.toLowerCase() + input.value.toUpperCase());\n"
		. "	mDigestInput.value = sha256.getHash('HEX');\n"
		. "}\n"
		. "\n"
		. "</script>\n"
		. "</head>\n"
		. "<body>\n"
		. "<form method='POST'>\n"
		. "<p>The page you have requested is for club administrators only.</p>\n"
		. "<p>The easiest way to open the page is to use the link we sent you in an email.</p>\n"
		. "<p>Use the latest email.<br>If there has been a recent password change your old links will not work.</p>\n"
		. "<p>Request a new email below.</p>\n"
		. "<p>email: <input type='email' id='email' style='width:24em;' oninput='signupOnInput(this)'></p>\n"
		. "<p><input type='submit' value='OK'></p>\n"
		. "<input type='hidden' name='command' value='requestlink'>\n"
		. "<input type='hidden' name='digest' id='digest'>\n"
		. "</form>\n"
		. "</body>\n"
		. "</html>";
	echo($html);
}

// The javascript standard saw fit to make the crypto functions
// asynchronous; possibly because they can be time consuming.
// Note that the digest is computed every time the user presses
// a key and we hope that processing is finished before the submit
// button is pressed. My understanding of the javascript event loop
// is that this will always be the case.
// Nasty - but the alternatives are awkward.

function commonRequestMemberLink($context)
{
	$html = ""
		. "<DOCTYPE html>\n"
		. "<html>\n"
		. "<head>\n"
		. "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>\n"
		. "<title>Signup</title>\n"
		. "<style>\n"
		. "body{-webkit-text-size-adjust:none;font-family:sans-serif;margin:0;padding:0.5em;}\n"
		. "p, ol, ul, li, table, tr, td, select, option, div, button, input, textarea{font-size:inherit;font-family:inherit;}\n"
		. "</style>\n"
		. "<script>\n";
	echo($html);

	readfile("../clubcommon/sha256.js");

	$html = ""
		. "\n"
		. "var mDigestInput = false;\n"
		. "\n"
		. "function signupOnInput(input)\n"
		. "{\n"
		. "	if (!mDigestInput) mDigestInput = document.getElementById('digest');\n"
		. "	var sha256 = new jsSHA('SHA-256', 'TEXT');\n"
		. "	sha256.update(input.value.toLowerCase() + input.value.toUpperCase());\n"
		. "	mDigestInput.value = sha256.getHash('HEX');\n"
		. "}\n"
		. "\n"
		. "</script>\n"
		. "</head>\n"
		. "<body>\n"
		. "<form method='POST' onsubmit='formsubmit()'>\n"
		. "<p>The page you have requested is for club members only.</p>\n"
		. "<p>The easiest way to open the page is to use the link we sent you in an email.</p>\n"
		. "<p>Use the latest email.<br>If there has been a recent password change your old links will not work.</p>\n"
		. "<p>Request a new email below.</p>\n"
		. "<p>email: <input type='email' id='email' style='width:24em;' oninput='signupOnInput(this)'></p>\n"
		. "<p><input type='submit' value='OK'></p>\n"
		. "<input type='hidden' name='command' value='requestlink'>\n"
		. "<input type='hidden' name='digest' id='digest'>\n"
		. "</form>\n"
		. "</body>\n"
		. "</html>";
	echo($html);
}

// Get given value ready for appending to an SQL query (SQLite3 style).

function commonQuote($context, $s)
{
	if (empty($s))
		return("NULL");
	switch (gettype($s))
	{
		case "boolean": return(1);
		case "integer": return($s);
		case "double": return($s);
		case "NULL": return("NULL");
		case "string": {
				$s = trim($s);
				if ($s == "")
					return("NULL");
				return("'" . $context->db->escapeString($s) . "'");
			}
		default: return(false);
	}
	return(false);
}

function commonCreateSignonTables($context)
{
	$fmt = "CREATE TABLE IF NOT EXISTS signons("
		. "helmName TEXT,"
		. "dateYYYYMMDD TEXT,"
		. "className TEXT,"
		. "portsmouthNumber INTEGER,"
		. "sailNumber TEXT,"
		. "crewNames TEXT,"
		. "type TEXT,"
		. "PRIMARY KEY(dateYYYYMMDD,helmName))";
	$context->db->exec($fmt);

	$fmt = "CREATE INDEX IF NOT EXISTS signonsDateYYYYMMDD ON signons(dateYYYYMMDD)";
	$context->db->exec($fmt);

	$fmt = "SELECT * FROM signons LIMIT 1";
	if (empty($context->db->querySingle($fmt)))
	{
		$fmt = "SELECT helmName,dateYYYYMMDD,className,portsmouthNumber,sailNumber,crewName,extraCrewName"
			. " FROM results"
			. " WHERE helmName IS NOT NULL AND dateYYYYMMDD IS NOT NULL AND className IS NOT NULL AND portsmouthNumber IS NOT NULL AND sailNumber IS NOT NULL";
		$result = $context->db->query($fmt);
		$a = array();
		while ($cells = $result->fetchArray(SQLITE3_NUM))
		{
			$a[$cells[0] . $cells[1]] = $cells;
		}

		foreach($a as $cells)
		{
			$bits = array();
			array_push($bits, "INSERT INTO signons VALUES");
			array_push($bits, "('" . $cells[0] . "'");
			array_push($bits, ",'" . $cells[1] . "'");
			array_push($bits, ",'" . $cells[2] . "'");
			array_push($bits, "," . $cells[3] . "");
			array_push($bits, ",'" . $cells[4] . "'");
			if (!empty($cells[5]))
			{
				if (empty($cells[6]))
				{
					array_push($bits, ",'" . $cells[5] . "'");
				}
				else if ($cells[5] === $cells[6])
				{
					array_push($bits, ",'" . $cells[5] . "'");
				}
				else
				{
					array_push($bits, ",'" . $cells[5] . "," . $cells[6] . "'");
				}
			}
			else
			{
				array_push($bits, ",NULL");
			}
			array_push($bits, ",'racing')");
			$fmt = implode("", $bits);
			$context->db->exec($fmt);
		}
	}

	$fmt = "CREATE TABLE IF NOT EXISTS members("
		. "memberName TEXT,"
		. "memberKey TEXT,"
		. "PRIMARY KEY(memberKey))";
	$context->db->exec($fmt);

	$fmt = "CREATE TABLE IF NOT EXISTS guests("
		. "dateYYYYMMDD TEXT,"
		. "guestName TEXT,"
		. "guestKey TEXT,"
		. "PRIMARY KEY(guestKey))";
	$context->db->exec($fmt);

	$fmt = "CREATE TABLE IF NOT EXISTS ice("
		. "sailorKey TEXT,"
		. "sailorName TEXT,"
		. "iceName TEXT,"
		. "iceTelephone TEXT,"
		. "PRIMARY KEY(sailorKey))";
	$context->db->exec($fmt);

	$fmt = "CREATE TABLE IF NOT EXISTS signonCache("
		. "name TEXT,"
		. "value TEXT,"
		. "dateYYYYMMDD TEXT,"
		. "checkSum TEXT,"
		. "PRIMARY KEY(name))";
	$context->db->exec($fmt);

	

}


function commonCreateProgrammeTables($context)
{
	$fmt = "CREATE TABLE IF NOT EXISTS programme("
		. "rowDate,"
		. "columnName,"
		. "eventName,"
		. "eventTime,"
		. "notes,"
		. "whoModified,"
		. "whenModified,"
		. "CONSTRAINT programmeKey PRIMARY KEY (rowDate,columnName))";
	$context->db->exec($fmt);

	$fmt = "CREATE TABLE IF NOT EXISTS duties("
		. "rowDate,"
		. "columnName,"
		. "dutyCode,"
		. "dutyTime,"
		. "memberId,"
		. "memberName,"
		. "whoModified,"
		. "whenModified,"
		. "CONSTRAINT dutiesKey PRIMARY KEY (rowDate,columnName,dutyCode))";
	return($context->db->exec($fmt));
}

function commonCreateConfigTable($context)
{
	$names = ""
		. "whenModified"
		. ",whoModified"
		. ",type"
		. ",content";

	$fmt = "CREATE TABLE IF NOT EXISTS config(" . $names . ")";
	return($context->db->exec($fmt));
}

function commonCreateResultsTable($context)
{
	$names = ""
		. "helmName"
		. ",seriesName"
		. ",raceName"
		. ",className"
		. ",sailNumber"
		. ",crewName"
		. ",fleet"
		. ",dateYYYYMMDD"
		. ",portsmouthNumber"
		. ",startHHMMSS"
		. ",laps"
		. ",endHHMMSS"
		. ",comment"
		. ",status"
		. ",rawCorrectedAverageLapTime"
		. ",finalCorrectedAverageLapTime"
		. ",helmAge"
		. ",crewAge"
		. ",extraCrewName"
		. ",extraCrewAge"
		. ",extraCrew2Name"
		. ",extraCrew2Age"
		. ",rdgScore";

	$fmt = "CREATE TABLE IF NOT EXISTS results(" . $names . ",PRIMARY KEY(helmName,seriesName,raceName))";
	return($context->db->exec($fmt));
}

function commonCreateStigTable($context)
{
	$names = ""
		. "helmName"
		. ",className"
		. ",sailNumber"
		. ",crewName"
		. ",dateYYYYMMDD"
		. ",portsmouthNumber REAL"
		. ",startHHMMSS"
		. ",comment"
		. ",status"
		. ",elapsedSeconds INTEGER"
		. ",correctedElapsedSeconds INTEGER"
		. ",helmAge"
		. ",crewAge"
		. ",extraCrewName"
		. ",extraCrewAge"
		. ",extraCrew2Name"
		. ",extraCrew2Age"
		. ",windKnots REAL"
		. ",windGustKnots REAL"
		. ",windDirection INTEGER";

	$fmt = "CREATE TABLE IF NOT EXISTS stig(" . $names . ",PRIMARY KEY(helmName,dateYYYYMMDD,startHHMMSS))";
	return($context->db->exec($fmt));
}

// Allow SQLite to create the database if it doesn't exist already '
// Ensure that the required tables have been created.
// Return handle to open database

function commonDatabaseOpen($context)
{
	if (isset($context->db) != false)
	{
		return($context->db);
	}

	$context->name = DATABASE_FILE_SPEC;

	$saveerror = error_reporting(0);

	$db = new SQLite3(DATABASE_FILE_SPEC);

	if ($db == false)
	{
		error_reporting($saveerror);
		return(false);
	}

	$context->db = $db;

	commonCreateConfigTable($context);
	commonCreateResultsTable($context);
	commonCreateProgrammeTables($context);

	commonCreateStigTable($context);

	$fmt = "CREATE TABLE IF NOT EXISTS version(versionNumber)";
	$context->db->exec($fmt);

	$fmt = "CREATE TABLE IF NOT EXISTS sessions("
		. "challenge PRIMARY KEY,"
		. "hostName TEXT,"
		. "ipAddress TEXT,"
		. "scriptFileName TEXT,"
		. "emailKey TEXT,"
		. "unixEpochSeconds INTEGER)";
	$context->db->exec($fmt);

	$fmt = "DELETE FROM sessions WHERE unixEpochSeconds<" . (time() - 24 * 60 * 60);
	$context->db->exec($fmt);

	error_reporting($saveerror);

	return($db);
}

function commonLog($context, $f0 = false, $f1 = false, $f2 = false, $f3 = false, $f4 = false, $f5 = false)
{
	$s = $context->loginMailAddress . " " . date("Y m d h:i") . "\n";
	if ($t = $f0)
		$s .= $t . "\n";
	if ($t = $f1)
		$s .= $t . "\n";
	if ($t = $f2)
		$s .= $t . "\n";
	if ($t = $f3)
		$s .= $t . "\n";
	if ($t = $f4)
		$s .= $t . "\n";
	if ($t = $f5)
		$s .= $t . "\n";
	$s .= "\n";
	$code = file_put_contents(LOG_TXT_FILE_SPEC, $s, FILE_APPEND | LOCK_EX);
	if ($code == false)
	{
		echo("Log write fail");
	}
	flush();
}

function commonAuthAdministrator($context)
{
	file_put_contents("debug", "\n" . __FILE__ . " " . __LINE__, FILE_APPEND);

	// APACHE PROVIDES THIS
	$context->hostName = $_SERVER["SERVER_NAME"];
	$ipaddress = getenv("HTTP_X_FORWARDED_FOR");
	if (!$ipaddress)
		$ipaddress = getenv("REMOTE_ADDR");

	$token = getenv("HTTP_TOKEN");
	if (empty($token))
		$token = getenv("HTTP_APPTOKEN");
	if (empty($token))
		$token = $_SERVER["HTTP_APPTOKEN"];
	if ($token)
	{
		file_put_contents("debug", "\n" . __FILE__ . " " . __LINE__, FILE_APPEND);
		$context->commonLog .= "\n" . __LINE__;

		$bits = explode(".", $token);
		if (count($bits) != 3)
		{
			return(false);
		}
		for ($i = 0; $i < 3; $i++)
		{
			while (count($words = explode(" ", $bits[$i])) > 1)
				$bits[$i] = implode("", $words);
		}
		$sha256 = base64_encode(hash("sha256", $bits[0] . "." . $bits[1] . ".decade"));
		if ($sha256 == $bits[2])
		{
			$context->commonLog .= "\n" . __LINE__;

			$payload = json_decode(base64_decode($bits[1]));
			if (time() < $payload->time + (365 * 24 * 60 * 60))
			{
				if (($ipaddress == $payload->ipAddress) &&
					($payload->scriptFileName == getenv("SCRIPT_FILENAME")))
				{
					$context->commonLog .= "\n" . __LINE__;

					// TOKEN IS GOOD
					foreach ($context->clubConfig->administrators as $name)
					{
						if ($payload->idMD5 == md5($name))
						{
							$context->loginName = $name;
							return(true);
						}
					}
				}
			}
		}
	}

	$context->commonLog .= "\n" . __LINE__;

	$digest = getenv("HTTP_DIGEST");
	$challenge = getenv("HTTP_CHALLENGE");
	$hashid = getenv("HTTP_IDHASH");
	if ((!empty($challenge)) && (!empty($hashid)))
	{
		file_put_contents("debug", "\n" . __FILE__ . " " . __LINE__, FILE_APPEND);
		$context->commonLog .= "\n" . __LINE__;
		$context->commonLog .= "\nchallenge = " . $challenge;
		$context->commonLog .= "\nhashid = " . $hashid;

		// WE CAN DETERMINE CLIENT EMAIL ADDRESS
		for ($i = 0; $i < count($context->clubConfig->administrators); $i++)
		{
			$name = $context->clubConfig->administrators[$i];
			file_put_contents("debug", "\n" . __FILE__ . " " . __LINE__ . " " . $name, FILE_APPEND);
			$context->commonLog .= "\ncalc = " . hash("sha256", $name . $challenge);
			if (hash("sha256", $name . $challenge) == $hashid)
			{
				file_put_contents("debug", "\n" . __FILE__ . " " . __LINE__ . " " . $name, FILE_APPEND);
				$context->commonLog .= "\n" . __LINE__;

				$context->loginName = $name;
				$fmt = "SELECT * FROM sessions WHERE challenge='" . $challenge . "'";
				$result = $context->db->query($fmt);
				if (($result) && ($cells = $result->fetchArray(SQLITE3_ASSOC)))
				{
					$context->commonLog .= "\n" . __LINE__;

					if (!empty($digest))
					{
						file_put_contents("debug", "\n" . __FILE__ . " " . __LINE__ . " " . $name, FILE_APPEND);
						$context->commonLog .= "\n" . __LINE__;

						// USER HAS PROVIDED ENOUGH INFORMATION TO CREATE A TOKEN
						$passworddigest = hash("sha256", $context->appName . $name . $context->hostName . $cells["emailKey"] . $context->appName);
						$sha256 = hash("sha256", $challenge . $passworddigest);
						if ($sha256 == $digest)
						{
							$context->commonLog .= "\n" . __LINE__;

							// BUILD A TOKEN
							$header = new stdClass();
							$header->alg = "sha256";
							$header->type = "JWT";
							$header = base64_encode(json_encode($header));

							$payload = new stdClass();
							$payload->time = time();
							$payload->hostName = $context->hostName;
							$payload->ipAddress = $ipaddress;
							$payload->idMD5 = md5($name);
							$payload->scriptFileName = getenv("SCRIPT_FILENAME");
							$payload = base64_encode(json_encode($payload));
							$signature = base64_encode(hash("sha256", $header . "." . $payload . ".decade"));
							$context->token = $header . "." . $payload . "." . $signature;
							return(true);
						}
					}
					else
					{
						file_put_contents("debug", "\n" . __FILE__ . " " . __LINE__ . " " . $name, FILE_APPEND);
						$context->commonLog .= "\n" . __LINE__;

						// STILL NOT AUTHENTICATED BUT NOW WE KNOW WHO THE CLIENT IS
						// WE CAN EMAIL A ONE OFF PASSWORD
						$address = $context->clubConfig->administrators[$i];
						$subject = $context->appName . " - " . "your login key";
						file_put_contents("debug", "\n" . __FILE__ . " " . __LINE__ . " " . $name, FILE_APPEND);
						$code = mail($context->loginName, $subject, $cells["emailKey"]);
						file_put_contents("debug", "\n" . __FILE__ . " " . __LINE__ . " " . $code, FILE_APPEND);
						file_put_contents(".key", $cells["emailKey"]);
						$m = $context->loginName . " " . $code . " " . $cells["emailKey"];
						file_put_contents("log", $cells["emailKey"]);
						return(false);
					}
				}
			}
		}
	}
	file_put_contents("debug", "\n" . __FILE__ . " " . __LINE__, FILE_APPEND);

	return(false);
}

function commonAuthRaceOfficer($context)
{
	$pass = $context->clubConfig->raceofficerPassword;
	if (empty($pass))
		return(true);

	// APACHE PROVIDES THIS
	$context->hostName = $_SERVER["SERVER_NAME"];
	$ipaddress = getenv("HTTP_X_FORWARDED_FOR");
	if (!$ipaddress)
		$ipaddress = getenv("REMOTE_ADDR");

	$token = getenv("HTTP_TOKEN");
	if ($token)
	{
		$bits = explode(".", $token);
		if (count($bits) != 3)
			return(false);
		for ($i = 0; $i < 3; $i++)
		{
			while (count($words = explode(" ", $bits[$i])) > 1)
				$bits[$i] = implode("", $words);
		}
		$sha256 = base64_encode(hash("sha256", $bits[0] . "." . $bits[1] . ".decade"));
		if ($sha256 == $bits[2])
		{
			$payload = json_decode(base64_decode($bits[1]));
			if (time() < $payload->time + (20 * 60 * 60))
			{
				if (($ipaddress == $payload->ipAddress) &&
					($payload->scriptFileName == getenv("SCRIPT_FILENAME")))
				{
					// TOKEN IS GOOD
					return(true);
				}
			}
		}
	}

	$digest = getenv("HTTP_DIGEST");
	$challenge = getenv("HTTP_CHALLENGE");
	if ((!empty($challenge)) && (!empty($digest)))
	{
		// USER HAS PROVIDED ENOUGH INFORMATION TO CREATE A TOKEN
		$passworddigest = hash("sha256", $context->appName . $pass . $context->hostName . $pass . $context->appName);
		$sha256 = hash("sha256", $challenge . $passworddigest);
		if ($sha256 == $digest)
		{
			// BUILD A TOKEN
			$header = new stdClass();
			$header->alg = "sha256";
			$header->type = "JWT";
			$header = base64_encode(json_encode($header));

			$payload = new stdClass();
			$payload->time = time();
			$payload->hostName = $context->hostName;
			$payload->ipAddress = $ipaddress;
			$payload->scriptFileName = getenv("SCRIPT_FILENAME");
			$payload = base64_encode(json_encode($payload));
			$signature = base64_encode(hash("sha256", $header . "." . $payload . ".decade"));
			$context->token = $header . "." . $payload . "." . $signature;
			return(true);
		}
	}
	return(false);
}

function commonIssueChallenge($context)
{
	$challenge = getenv("HTTP_CHALLENGE");

	if (!empty($challenge))
	{
		$fmt = "SELECT * FROM sessions WHERE challenge='" . $challenge . "'";
		$result = $context->db->query($fmt);
		if (($result) && ($cells = $result->fetchArray(SQLITE3_ASSOC)))
		{
			return($challenge);
		}
	}

	if (function_exists("random_bytes"))
	{
		$challenge = bin2hex(random_bytes(48));
	}
	else
	{
		$a = array();
		for ($i = 0; $i < 40; $i++)
		{
			array_push($a, chr(mt_rand(0, 255)));
			$challenge = bin2hex(implode("", $a));
		}
	}

	// APACHE PROVIDES THIS
	$hostname = $_SERVER["SERVER_NAME"];
	$ipaddress = getenv("HTTP_X_FORWARDED_FOR");
	if (!$ipaddress)
		$ipaddress = getenv("REMOTE_ADDR");
	$scriptfilename = getenv("SCRIPT_FILENAME");
	$key = "" . mt_rand(100000, 999999);

	$fmt = "INSERT INTO sessions VALUES("
		. "'" . $challenge . "',"
		. "'" . $context->db->escapeString($hostname) . "',"
		. "'" . $ipaddress . "',"
		. "'" . $context->db->escapeString($scriptfilename) . "',"
		. "'" . $key . "',"
		. time() . ")";
	$context->db->exec($fmt);

	return($challenge);
}

function base64url_encode($data)
{
	return rtrim(strtr(base64_encode($data), '+/', '-_'	), '=');
//	return str_replace(['+','/','='], ['-','_',''], base64_encode($data));
}

function base64url_decode($data)
{
//    return base64_decode(str_replace(['-','_'], ['+','/'], $string));
	return base64_decode(str_pad(strtr($data, '-_', '+/'), strlen($data) % 4, '=', STR_PAD_RIGHT));
}

function commonDeliverToken($context, $code, $admin)
{
	$header = new stdClass();
	$header->alg = "private";
	$header->type = "jwt";
	$header = base64url_encode(json_encode($header));

	$payload = new stdClass();
	$payload->iat = time();
	$payload->iss = $_SERVER['SERVER_NAME'];
	if ($admin)
		$payload->admin = $admin;
	$payload->code = $code;
	$payload->addr = getenv("REMOTE_ADDR");
	$payload = base64url_encode(json_encode($payload));
	$test = base64url_decode($payload);
	$test = json_decode($test);

	$signature = hash_hmac("sha256", $header . "." . $payload, $context->passkey);

	$object = new stdClass();
	$object->token = $header . "." . $payload . "." . $signature;
	echo(json_encode($object));
}


function commonAuthMember($context)
{
	// APACHE PROVIDES THIS
	$context->hostName = $_SERVER["SERVER_NAME"];
	$ipaddress = getenv("HTTP_X_FORWARDED_FOR");
	if (!$ipaddress)
		$ipaddress = getenv("REMOTE_ADDR");

	$token = getenv("HTTP_TOKEN");
	if ($token)
	{
		$bits = explode(".", $token);
		if (count($bits) != 3)
			return(false);
		for ($i = 0; $i < 3; $i++)
		{
			while (count($words = explode(" ", $bits[$i])) > 1)
				$bits[$i] = implode("", $words);
		}
		$sha256 = base64_encode(hash("sha256", $bits[0] . "." . $bits[1] . ".decade"));
		if ($sha256 == $bits[2])
		{
			$payload = json_decode(base64_decode($bits[1]));
			if (time() < $payload->time + (20 * 60 * 60))
			{
				if (($ipaddress == $payload->ipAddress) &&
					($payload->scriptFileName == getenv("SCRIPT_FILENAME")))
				{
					// TOKEN IS GOOD
					return(true);
				}
			}
		}
	}

	$digest = getenv("HTTP_DIGEST");
	$challenge = getenv("HTTP_CHALLENGE");
	if ((!empty($challenge)) && (!empty($digest)))
	{
		$fmt = "SELECT * FROM sessions WHERE challenge='" . $challenge . "'";
		$result = $context->db->query($fmt);
		if (($result) && ($cells = $result->fetchArray(SQLITE3_ASSOC)))
		{
			// USER HAS PROVIDED ENOUGH INFORMATION TO CREATE A TOKEN
			$a = get_object_vars($context->clubConfig);
			$password = $a[$context->appName . "Password"];
			$passworddigest = hash("sha256", $context->appName . $password . $context->hostName . $password . $context->appName);
			$sha256 = hash("sha256", $challenge . $passworddigest);
			if ($sha256 == $digest)
			{
				// BUILD A TOKEN
				$header = new stdClass();
				$header->alg = "sha256";
				$header->type = "JWT";
				$header = base64_encode(json_encode($header));

				$payload = new stdClass();
				$payload->time = time();
				$payload->hostName = $context->hostName;
				$payload->ipAddress = $ipaddress;
				$payload->scriptFileName = getenv("SCRIPT_FILENAME");
				$payload = base64_encode(json_encode($payload));
				$signature = base64_encode(hash("sha256", $header . "." . $payload . ".decade"));
				$context->token = $header . "." . $payload . "." . $signature;
				return(true);
			}
		}
	}
	return(false);
}

// Remove anything we don't want sent in plain over the link

function commonSanitise($object)
{
	if (empty($object->clubConfig))
		return;

	// ADMINISTRATOR LIST NOT REQUIRED
	$object->clubConfig->administrators = null;
	$object->signonPassword = false;
	$object->raceofficerPassword = false;
}

function commonCaptcha($context)
{
	$image = imagecreatetruecolor(200, 50);
	$background_color = imagecolorallocate($image, 255, 255, 255);
	imagefilledrectangle($image, 0, 0, 200, 50, $background_color);

	$line_color = imagecolorallocate($image, 64, 64, 64);
	$number_of_lines = rand(3, 7);

	for ($i = 0; $i < $number_of_lines; $i++)
	{
		imageline($image, 0, rand() % 50, 250, rand() % 50, $line_color);
	}

	$pixel = imagecolorallocate($image, 0, 0, 255);

	for ($i = 0; $i < 500; $i++)
	{
		imagesetpixel($image, rand() % 200, rand() % 50, $pixel);
	}

	$allowed_letters = 'ABCDEFGHJKLNPRSTVXYZ23456789';
	$length = strlen($allowed_letters);
	$letter = $allowed_letters[rand(0, $length - 1)];
	$word = '';
	$text_color = imagecolorallocate($image, 0, 0, 0);
	$cap_length = 6; // No. of character in image
	for ($i = 0; $i < $cap_length; $i++)
	{
		$letter = $allowed_letters[rand(0, $length - 1)];
		imagestring($image, 5, 20 + ($i * 30), 20, $letter, $text_color);
		$word .= $letter;
	}

	$savemode = error_reporting(0);

	if (!commonDatabaseOpen($context))
		return(false);

	// A CAPTURE IS RANDOMLY GENERATED FOR AN IP ADDRESS
	// N.B. IF SIMOULTANEOUS APPLICATIONS ARE MADE FROM THE SAME IP ADDRESS
	// THIS WILL GO WRONG.
	// THE KEY IS THE IP ADDRESS
	$fmt = "CREATE TABLE IF NOT EXISTS captcha(captchaKey TEXT PRIMARY KEY,"
		. "captchaMinute INTEGER,"
		. "captchaWord TEXT)";
	if (!$context->db->exec($fmt))
	{
		$err = $context->db->lastErrorMsg();
		echo("System failure " . __LINE__ . " " . $err . " " . $fmt . " " . $filespec);
		die();
	}


	$minute = round(time() / 60);
	$fmt = "DELETE FROM captcha WHERE captchaMinute<" . ($minute - 60);
	$context->db->exec($fmt);
	$key = getenv("REMOTE_ADDR");
	$fmt = "INSERT INTO captcha VALUES('" . $key . "'," . $minute . ",'" . $word . "')";
	if (!$context->db->exec($fmt))
	{
		$fmt = "UPDATE captcha SET captchaMinute=" . $minute . ",captchaWord='" . $word . "'";
		$context->db->exec($fmt);
	}
	$context->db->close();

	ob_start();
	imagepng($image);
	$image = ob_get_clean();

	error_reporting($savemode);
	header('Content-Type: image/png');
	echo($image);
}

?>
