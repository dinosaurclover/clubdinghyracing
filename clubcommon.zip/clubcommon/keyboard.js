//////////////////////////////////////////////////////////
//
function keyboardOnResize()
{
}
//
//////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////
//
function keyboardOnIndexClick(evt)
{
	var div = document.getElementById("keyboardShield");
	var input = div.input;

	if (evt.target.title == "Left")
	{
		var pos = input.selectionStart;
		if (pos > 0) pos --;
		input.focus();
		input.setSelectionRange(pos, pos);
	}
	else if (evt.target.title == "Right")
	{
		var pos = input.selectionStart;
		if (pos < input.value.length) pos ++;
		input.focus();
		input.setSelectionRange(pos, pos);
	}
	else if (evt.target.title == "Delete Right")
	{
		var pos = input.selectionStart;
		if (pos < input.value.length)
		{
			var left = input.value.substr(0, pos);
			var right = input.value.substr(pos + 1);
			input.value = left + right;
			input.focus();
			input.setSelectionRange(pos, pos);
		}
	}
	else if (evt.target.title == "Destructive Backspace")
	{
		var pos = input.selectionStart;
		if (pos > 0)
		{
			var left = input.value.substr(0, pos - 1);
			var right = input.value.substr(pos);
			input.value = left + right;
			input.focus();
			pos --;
			input.setSelectionRange(pos, pos);
		}
	}
	else if (evt.target.title == "OK")
	{
		var div = document.getElementById("keyboardShield");
		document.body.removeChild(div);
	}
	else
	{
		var pos = input.selectionStart;
		var left = input.value.substr(0, pos);
		var right = input.value.substr(pos);
		input.value = left + evt.target.innerText.trim() + right;
		input.focus();
		pos ++;
		input.setSelectionRange(pos, pos);
	}
	if (input.callBack) input.callBack(input);
}
//
//////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////
//
function keyboardOnBlur(evt)
{
	var div = document.getElementById("keyboardShield");
	document.body.removeChild(div);
}
//
//////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////
//
function keyboardPosition(elem)
{
	var offsetLeft = 0, offsetTop = 0;;
	do
	{
		if (!isNaN(elem.offsetLeft))
		{
			offsetLeft += elem.offsetLeft - elem.scrollLeft;
		}
		if (!isNaN(elem.offsetTop))
		{
			offsetTop += elem.offsetTop - elem.scrollTop;
		}
	}
	while((elem = elem.offsetParent));
	return([offsetLeft, offsetTop]);
}
//
//////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////
//
function keyboardCancel(evt)
{
	if (evt.target.tagName != "DIV") return;
	var div = document.getElementById("keyboardShield");
	document.body.removeChild(div);
}
//
//////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////
//
function keyboardOnFocus(evt)
{
	var div;
	/*
	Needs a little extra here
	Make sure input will be visible above the keyboard
	Should simply look to see if there is room for the keyboard and if not,
	scroll the window up a bit.
	Also, keyboard position should be fixed.
	*/
	console.log("focus");

	var div = document.getElementById("keyboardShield");
	if (div) return;

	var input = evt.target;

	div = document.createElement("div");
	div.id = "keyboardShield";
	div.style.position = "fixed";
	div.style.overflow = "hidden";
	div.style.top = 0;
	div.style.left = 0;
	div.style.width = "" + window.innerWidth + "px";
	div.style.height = "" + window.innerHeight + "px";
//	div.style.background = "rgba(0, 0, 0, 0.4)";
	document.body.appendChild(div);
	var shield = div;

//	var dummy = document.createElement("input");
//	div.appendChild(dummy);
//	dummy.focus();
//	dummy.style.display = "none";

	div.input = input;

	input.orgValue = input.value;
	input.modified = false;
	
	let style = getComputedStyle(document.body);

	var buttons = document.createElement("div");
	buttons.style.position = "absolute";
	buttons.style.overflowX = "hidden";
	buttons.style.left = 0;
	buttons.style.backgroundColor = style.backgroundColor;
	buttons.style.whiteSpace = "nowrap";
	buttons.style.boxSizing = "border-box";
	buttons.style.border = "black solid 1px";
	buttons.style.width = "" + div.clientWidth + "px";

	var keys =
	[
		["1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "Del", "&#8617;", "&#8701;", "&#8702;", "OK"],
		["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"]
	];

	var i, j;
	for (i = 0; i < keys.length; i ++)
	{
		if (i > 0)
		{
			var br = document.createElement("br");
			buttons.appendChild(br);
		}
		for (j = 0; j < keys[i].length; j ++)
		{
			var button = document.createElement("button");
			button.style.boxSizing = "border-box";
			button.style.width = "" + (div.clientWidth / keys[i].length) + "px";
//			button.style.height = "1em";
			button.innerHTML = keys[i][j];
			if (keys[i][j] == "Del") button.title = "Delete Right";
			else if (keys[i][j] == "&#8617;") button.title = "Destructive Backspace";
			else if (keys[i][j] == "&#8701;") button.title = "Left";
			else if (keys[i][j] == "&#8702;") button.title = "Right";
			else if (keys[i][j] == "OK") button.title = "OK";
			button.addEventListener("click", keyboardOnIndexClick);
			buttons.appendChild(button);
		}
	}
	div.appendChild(buttons);
	buttons.style.top = "" + (window.innerHeight - buttons.offsetHeight) + "px";

	var v = keyboardPosition(input);

	let inputtop = v[1];
	let inputbottom = inputtop + input.offsetHeight;

	let keyboardtop = window.innerHeight - buttons.offsetHeight;
	if (keyboardtop > inputbottom)
	{
		keyboardtop = inputbottom;
	}
	else
	{
		mApp.scrollingDiv.scrollTop += (inputbottom - keyboardtop);
	}
	buttons.style.top = "" + keyboardtop + "px";
	div.addEventListener("click", keyboardCancel);
	input.setSelectionRange(0, 0);
}
//
//////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////
//
function keyboardInit(callback)
{
	if (mApp.raspberryPi)
	{
		keyboardOnResize();
		window.addEventListener("resize", keyboardOnResize);


		var inputs = document.getElementsByClassName("keyboard");
		var i;
		for (i = 0; i < inputs.length; i ++)
		{
			if (inputs[i].className == "keyboard")
			{
				inputs[i].addEventListener("focus", keyboardOnFocus);
				if (callback) inputs[i].callBack = callback;
			}
		}
	}
}
//
//////////////////////////////////////////////////////////

