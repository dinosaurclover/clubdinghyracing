<?php

require_once '../clubcommon/Database.php';
require_once '../clubcommon/Misc.php';

class Portal
{
	function __construct()
	{
		$this->scanfConfigurationFile();

		if (empty($this->mailAddress = $this->getEnv("HTTP_MAILADDRESS")))
		{
			$this->mailAddress = "";
		}

		if (empty($this->mailAddress) || (empty($this->configurationItems["administrator"][$this->mailAddress]) && !$this->isMember($this->mailAddress)))
		{
			sleep(2);
			Misc::errorExit("Login failed. Mail address not recognised. " . $this->mailAddress , 400);
		}

		$accessCode = Misc::getFormValue("accesscode", false);

		if (!$this->checkToken())
		{
			// No token or token is invalid
			// Send an unverified token with a new random access string
				// User has a valid token but it's not verified
			// Must be requesting a verification email
			$this->sendAccessCodeMail();
			$text = $this->createToken();
			header("token: " . $text);
			Misc::errorExit("Email sent. Access code required", 403);
		}

		if ($this->tokenVerified)
		{
			if (!empty($this->configurationItems["administrator"][$this->mailAddress]))
			{
				// Client is now logged on. Is client an administrator
				$this->administrator = true;
			}
		}
		else
		{
			if (!empty($accessCode))
			{
				if (empty($this->db))
				{
					if (!($this->db = DataBase::getRawSqlite3Object()))
					{
						$text = $this->createToken();
						header("token: ". $text);
						Misc::errorExit("Login failed. Database does not exist.", 401);
					}
				}
				
				// access table might not exist
				// it will be created when first email is sent

				$essence = Misc::essence($accessCode);
				$fmt = "SELECT mailAddress FROM access WHERE accessEssence='" . $essence . "'";
				if (($address = $this->db->querySingle($fmt)) == false)
				{
					$text = $this->createToken();
					header("token: ". $text);
					Misc::errorExit($this->db->lastErrorMsg(), 404);
				}
				else if (empty($address))
				{
					$text = $this->createToken();
					header("token: ". $text);
					Misc::errorExit("Incorrect access code.", 404);
				}
				else
				{
					$fmt = "SELECT unixEpochSeconds FROM access WHERE accessEssence='" . $essence . "'";
					$t = intval($this->db->querySingle($fmt));
					if ($t < (time() - 30 * 60))
					{
						$text = $this->createToken();
						header("token: ". $text);
						Misc::errorExit("Expired access code(30 minutes life). Please start login again.", 404);
					}
				}

				// Now we can create a new, verified token
				$text = $this->createToken("Yes");

				// Send it back to client
				header("token: ". $text);

				if (!empty($this->configurationItems["administrator"][$this->mailAddress]))
				{
					// Client is now logged on. Is client an administrator
					$this->administrator = true;
				}
			}
			else
			{
				// User has a valid token but it's not verified
				// Must be requesting a verification email
				$this->sendAccessCodeMail();
				$text = $this->createToken();
				header("token: ". $text);
				Misc::errorExit("Email sent. Access code required", 403);
			}
		}
	}

	private function isMember($mailAddress)
	{
		if (!($this->db = DATABASE::getRawSqlite3Object()))
		{
			return(false);
		}

		$fmt = "SELECT sailorName FROM sailor WHERE sailorMailAddress LIKE '" . $mailAddress . "'";
		$this->userName = $this->db->querySingle($fmt);
		return((empty($this->userName)) ? false : true);
	}


	private function decodeToken($text)
	{
		if (empty($text))
		{
			return(false);
		}

		$bits = explode(".", $text);
		if (count($bits) != 3)
		{
			return(false);
		}

		for ($i = 0; $i < 3; $i++)
		{
			while (count($words = explode(" ", $bits[$i])) > 1)
			{
				$bits[$i] = implode("", $words);
			}
		}

		$sha256 = base64_encode(hash("sha256", $bits[0] . "." . $bits[1] . $this->configurationItems["tokenSecret"]));
		if ($sha256 != $bits[2])
		{
			// Something has messed with the token
			return(false);
		}

		$t = intval($this->configurationItems["tokenLifeDays"]);
		$expiresUnixEpochSeconds = time() + $t * 24 * 60 * 60;

		$payload = json_decode(base64_decode($bits[1]));
		if (time() > $expiresUnixEpochSeconds)
		{
			return(false);
		}

		// APACHE PROVIDES THIS
		$hostName = $this->getEnv("SERVER_NAME");
		$ipAddress = $this->getEnv("HTTP_X_FORWARDED_FOR");
		if (empty($ipAddress)) $ipAddress = $this->getEnv("REMOTE_ADDR");

		if (($ipAddress != $payload->ipAddress) || ($hostName != $payload->hostName))
		{
			return(false);
		}

		if (empty($payload->mailAddress))
		{	
			return(false);
		}

		if ($this->mailAddress != $payload->mailAddress)
		{
			return(false);
		}

		$this->tokenVerified = empty($payload->verified) ? false : true;
		if (!empty($this->configurationItems["administrator"][$this->mailAddress]))
		{
			$this->administrator = "Yes";
		}

		return(true);
	}

	private function checkToken()
	{
		if (empty($token = $this->getEnv("HTTP_TOKEN")))
		{
			return(false);
		}

		if (!$this->decodeToken($token))
		{
			return(false);
		}

		return(true);
	}

	private function createToken($verified = "")
	{
		// APACHE PROVIDES THIS
		$hostName = $this->getEnv("SERVER_NAME");
		$ipAddress = $this->getEnv("HTTP_X_FORWARDED_FOR");
		if (empty($ipAddress)) $ipAddress = $this->getEnv("REMOTE_ADDR");

		$header->alg = "sha256";
		$header->type = "JWT";
		$header = base64_encode(json_encode($header));

		$payload = new stdClass();
		$payload->time = time();
		$payload->hostName = $hostName;
		$payload->ipAddress = $ipAddress;
		$payload->mailAddress = $this->mailAddress;
		$payload->verified = $verified;

		$payload = base64_encode(json_encode($payload));

		$signature = base64_encode(hash("sha256", $header . "." . $payload . $this->configurationItems["tokenSecret"]));

		return($header . "." . $payload . "." . $signature);
	}

	private function getEnv($key)
	{
		$s = $_SERVER[$key];
		if (!empty($s)) return($s);
		return(getenv($key));
	}

	// Cannot access the configuration in the normal way - user might not be authorized
	// Scan the script instead.
	// Look for equalities only. Any arrays can be ignored.
	private function scanfConfigurationFile()
	{
		$arrayPattern = "/^\s*([a-z][a-z0-9]*)\[\s*([a-z][a-z0-9]*\s*[a-z][a-z0-9.@]*)\s*\]\s*\:(.*)/i";
		$stringPattern = "/^\s*([a-z][a-z0-9]*)\s*\=(.*)/i";

		$fileSpec = Database::CONFIG_SCRIPT_FILE_SPEC;
		$lines = file($fileSpec);
		$this->configurationItems = array();
		foreach($lines as $line)
		{
			$matches = array();
			if (preg_match($stringPattern, $line, $matches))
			{
				// someVariableName = someValue
				if (!empty($value = $matches[2]))
				{
					$name = trim($matches[1]);
					$this->configurationItems[$name] = trim($value);
				}
			}
			else if (preg_match($arrayPattern, $line, $matches))
			{
				if (!empty($key = $matches[2]) && !empty($value = $matches[3]))
				{
					$name = trim($matches[1]);
					if (empty($this->configurationItems[$name]))
					{
						$this->configurationItems[$name] = array();
					}
					$item = array();
					if (strpos($value, "=") > 0)
					{
						// It's an object
						$bits = explode(",", $value);
						foreach ($bits as $bit)
						{
							$components = array();
							if (preg_match("/^\s*([a-z][a-z0-9]*)\s*\=(.*)/i", $bit, $components))
							{
								if (!empty($v = $components[2]))
								{
									$item[trim($components[1])] = trim($v);
								}
							}
						}
					}
					$this->configurationItems[$name][$key] = $item;
				}
			}
		}
	}

	private function sendAccessCodeMail()
	{
		if (empty($this->db))
		{
			if (!($this->db = new SQLite3(Database::DATABASE_FILE_SPEC)))
			{
				$text = $this->createToken();
				header("token: " . $text);
				Misc::errorExit("Login failed. Database does not exist.");
			}
		}

		$fmt = "CREATE TABLE IF NOT EXISTS access(accessEssence TEXT PRIMARY KEY, mailAddress TEXT, unixEpochSeconds INTEGER)";
		if ($this->db->exec($fmt) == false)
		{
			$text = $this->createToken();
			header("token: " . $text);
			Misc::errorExit("Login failed. Database problem.");
		}

		do
		{
			$n = mt_rand(1000000, 2000000);
			$s = "" . $n;
			$accessCode = substr($s, 1);
			$fmt = "INSERT INTO access VALUES('" . Misc::essence($accessCode) . "','" . $this->mailAddress . "'," . time() . ")";
			$this->db->exec($fmt);
		}
		while ($this->db->lastErrorCode() == 5);

		if ($this->db->lastErrorCode() != 0)
		{
			Misc::errorExit("Login failed. Database problem.");
		}

		$subject = $accessCode . " Access code for club racing admin";

		$message = "Please ignore this message if you did not request access to the NSC sailing admin site."
			. "\n"
			. "\nHere is your new access code."
			. "\n"
			. "\n" . $accessCode
			. "\n"
			. "\nType your new access code into the box on the webpage."
			. "\n"
			. "\nYour PC, laptop, phone or tablet will remain logged in for the foreseeable future.\n"
			. "\n"
			. "\nIf you switch off your phone or switch off your router you might be asked to login again."
			. "\n"
			. "\nIf the club administrator invalidates all logins you will be asked to login again.";

		$this->sendMail($this->mailAddress, $subject, $message);

		file_put_contents("debug", $message);
	}

	private function sendMail($mailAddress, $subject, $message)
	{
		$mail = new PHPMailer;

		if (!empty($this->configurationItems["mailHost"]))
		{
			// Set mailer to use SMTP
			$mail->IsSMTP();
			//useful for debugging, shows full SMTP errors
			$mail->SMTPDebug = 0; // debugging: 1 = errors and messages, 2 = messages only
			// Enable SMTP authentication
			$mail->SMTPAuth = true;
			// Enable encryption, usually SSL/TLS
			if (!empty($this->configurationItems["ssl"]))
			{
				$mail->SMTPSecure = "ssl";
			}
			// Specify host server
			$mail->Host = $this->configurationItems["mailHost"];
			$mail->Username = $this->configurationItems["mailUser"];
			$mail->Password = $this->configurationItems["mailPass"];
			$mail->Port = intval($this->configurationItems["mailPort"]);
		}
		else
		{
			$mail->IsMail();
		}

		$mail->From = $this->configurationItems["mailFrom"];
		$mail->FromName = $this->configurationItems["mailSigned"];
		$mail->AddAddress($mailAddress);
		$mail->Subject = $subject;

		// the link to your register.php, please set this value in config/email_verification.php
		$mail->Body = $message;

		if (!$mail->Send())
		{
			Misc::errorExit("Login failed. Server unable to send email.");
			return false;
		}
		else
		{
			return true;
		}
	}

}


