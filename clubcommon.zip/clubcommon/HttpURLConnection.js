/*
 * Copyright 2021 Ian Rye. All Rights Reserved.
 * ianrye@espforwindows.com
 * Interface for communicating with an active http server
 * This class sends query strings, for example
 * command=test&param=1
 * If the query is successful the server resonds with a json encoded object.
 * Site is password protected. A valid token is required.
 */

"use strict"

var mHttpURLConnection = {};

class HttpURLConnection extends XMLHttpRequest
{
	constructor(mode)
	{
		super();
		this.addEventListener("load", this.loadListener)
		this.addEventListener("error", this.errorListener)
		this.addEventListener("timeout", this.timeoutListener)
		this.addEventListener("readystatechange", this.readystatechangeListener)
		this.addEventListener("load", this.loadListener)
		this.open("POST", "index.php", true);
		this.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		this.timeout = 3000;
		if (mHttpURLConnection.token) this.setRequestHeader("apptoken", mHttpURLConnection.token);
		if (mode == "write") this.setRequestHeader("databasemode","write");
	}

	/* public */
	setSuccessFunction(fn)
	{
		this.callback = fn;
	}

	/* public */
	transmit(data)
	{
		// CREATE A GUARD DIV TO DISABLE POINTER
		let guard = document.createElement('div');
		document.body.appendChild(guard);
		guard.style.position = "absolute";
		guard.style.left = 0;
		guard.style.top = 0;
		guard.style.width = "" + window.innerWidth + "px";
		guard.style.height = "" + window.innerHeight + "px";
//		guard.style.background = "rgba(0, 0, 0, 0.2)";

		guard.addEventListener("pointerdown", prevent, true);
		guard.addEventListener("click", prevent, true);

		function prevent(evt)
		{
			evt.preventDefault();
		}

		this.guard = guard;

		this.send(data);
	}

	/* public */
	setFailureFunction(fn)
	{
		this.failureCallback = fn;
	}

	/* public */
	setAuthenticationFunction(fn)
	{
		this.authenticationCallback = fn;
	}

	// SHOULD BE PRIVATE BUT AT TIME OF WRITING, NO JAVASCRIPT CLASS PRIVATE
	errorListener()
	{
		if (this.guard) document.body.removeChild(this.guard);
		dialogAlert("HttpURLConnection error");
	}

	// SHOULD BE PRIVATE BUT AT TIME OF WRITING, NO JAVASCRIPT CLASS PRIVATE
	readystatechangeListener()
	{
	}

	// SHOULD BE PRIVATE BUT AT TIME OF WRITING, NO JAVASCRIPT CLASS PRIVATE
	timeoutListener()
	{
		if (this.guard) document.body.removeChild(this.guard);
		// dialogAlert("Connection to server lost or timed out<br>Timeout is currently set to 3 seconds.<br>Use Tools/GlobalSettings to Change Timeout Value.");
		alert("Connection to server lost or timed out.\nTimeout is currently set to 3 seconds.\nUse Tools/GlobalSettings to Change Timeout Value.");
	}

	// SHOULD BE PRIVATE BUT AT TIME OF WRITING, NO JAVASCRIPT CLASS PRIVATE
	loadListener()
	{
		if (this.guard) document.body.removeChild(this.guard);
		if (this.status == 401)
		{
			// SERVER WILL HAVE RETURNED A CHALLENGE
			document.body.style.backgroundColor = "";
			if (this.authenticationCallback)
			{
				this.authenticationCallback(this);
			}
			else if (dialogAlert) dialogAlert("Authentication required");
			else alert("Authentication required");
			return;
		}
		else if (this.status != 200)
		{
			this.object = {};
			this.object.errorMessage = "Server returned HTTP status code " + this.status;
		}
		else
		{
			// THE RESPONSE SHOULD BE VALID JSON TEXT WHICH CAN BE
			// DECODED TO AN OBJECT
			let object = false;
			try
			{
				this.object = JSON.parse(this.responseText);
			}
			catch(error)
			{
				this.object = {};
				this.object.errorMessage = "Unexpected (non-json) response from server.<br>If this persists please contact development team."
			}
			if (!this.object)
			{
				dialogAlert("Unexpected response from server.<br>If this persists please contact development team.");
			}
			else if (this.object.errorMessage)
			{
				if (this.failureCallback) this.failureCallback(this);
				else if (dialogAlert) dialogAlert(this.object.errorMessage);
				else alert(this.object.errorMessage);
				return;
			}
			else
			{
				if (this.object.token) mHttpURLConnection.token = this.object.token;
				if (this.callback) this.callback(this);
			}
		}
	}
}

