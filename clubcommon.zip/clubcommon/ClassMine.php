<?php

include_once '../clubcommon/SimpleXLSX.php';
include_once '../clubcommon/Misc.php';
include_once '../clubcommon/Database.php';

/*
Every day, retrieve files from schrs and great lakes
Construct a list as follows
Insert all the entries from the great lakes file - use RYA column where possible
It looks like not all schrs classes are in the great lakes file. Add any missing ones from the schrs file.
Finally, read the 'clubClasses.xlsx' file. Add any missing lines. Override existing lines.
 */

class ClassMine
{
	const SCHRS_URL = "https://schrs.com/downloads.html";
	const SCHRS_ROOT = "https://schrs.com/";
	const SCHRS_FILESPEC = "../clubdata/schrs.csv";

	const GREATLAKES_URL = "http://greatlakes.org.uk/The-Data.php";
	const GREATLAKES_ROOT = "http://greatlakes.org.uk/";
	const GREATLAKES_FILESPEC = "../clubdata/greatLakes.xlsx";

	const CLUB_FILESPEC = "../clubdata/club.xlsx";
	const TOUCH_FILESPEC = "../clubdata/classmine.touched";

	public static function schrs()
	{
		$s = file_get_contents(ClassMine::SCHRS_URL);
		$doc = new DOMDocument();
		$bool = $doc->loadHTML($s);

		$anchors = $doc->getElementsByTagName("a");
		foreach($anchors as $anchor)
		{
			$href = $anchor->getAttribute("href");
			$bits = explode(".", $href);
			$type = array_pop($bits);
			if ($type == "csv")
			{
				$s = file_get_contents(ClassMine::SCHRS_ROOT . $href);
				if (file_put_contents(ClassMine::SCHRS_FILESPEC, $s) === false)
				{
					ClassMine::reportError("Failed to write file " . ClassMine::SCHRS_FILESPEC);
					return(false);
				}
				return(true);
			}
		}
		ClassMine::reportError("Anchor for csv file not found in  " . ClassMine::SCHRS_URL);
		return(false);
	}

	public static function greatLakes()
	{
		$s = file_get_contents(ClassMine::GREATLAKES_URL);
		$doc = new DOMDocument();
		if (!$doc->loadHTML($s))
		{
			ClassMine::reportError("DOM load document failed " . ClassMine::GREATLAKES_URL);
			return(false);
		}

		$anchors = $doc->getElementsByTagName("a");
		foreach($anchors as $anchor)
		{
			$href = $anchor->getAttribute("href");
			$bits = explode(".", $href);
			$type = array_pop($bits);
			if ($type == "xlsx")
			{
				$s = file_get_contents(ClassMine::GREATLAKES_ROOT . $href);
				if (file_put_contents(ClassMine::GREATLAKES_FILESPEC, $s) === false)
				{
					echo("Failed to write file " . ClassMine::GREATLAKES_FILESPEC);
					return(false);
				}
				return(true);
			}
		}
		ClassMine::reportError("Anchor for csv file not found in  " . ClassMine::GREATLAKES_URL);
		return(false);
	}

	public static function build()
	{
		$found = array();
		$db = new Database();
		$commands = array();
		array_push($commands, "DELETE FROM class");

		$flags = 0;
		$started = false;
		if ( $xlsx = SimpleXLSX::parse(ClassMine::GREATLAKES_FILESPEC))
		{
			foreach ($xlsx->rows() as $cells)
			{
				if (!$started)
				{
					$cellIndex = 0;
					foreach($cells as $cell)
					{
						$cell = trim($cell);
						$essence = Misc::essence($cell);
						switch($essence)
						{
							case "_type":
							{
								$flags |= 1;
								$typeIndex = $cellIndex;
								break;
							}
							case "_boatclass":
							{
								$flags |= 2;
								$classIndex = $cellIndex;
								break;
							}
							case "_handicapstatus":
							{
								$flags |= 4;
								$statusIndex = $cellIndex;
								break;
							}
							case "_ryaclasshandicap":
							{
								$flags |= 8;
								$ryaNumberIndex = $cellIndex;
								break;
							}
							case "_greatlakeshandicap":
							{
								$flags |= 16;
								$glNumberIndex = $cellIndex;
								break;
							}
						}
						$cellIndex ++;
					}
					if ($flags == 31)
					{
						$started = true;
					}
				}
				else
				{
					$type = trim($cells[$typeIndex]);
					if (($type == "D") || ($type == "M") || ($type == "K"))
					{
						$className = trim($cells[$classIndex]);
						$classKey = Misc::essence($className);
						$classPortsmouthNumber = intval($cells[$ryaNumberIndex], 10);
						$classSource = trim($cells[$statusIndex]);
						if (!($classPortsmouthNumber > 0))
						{
							$classPortsmouthNumber = intval($cells[$glNumberIndex], 10);
						}
						if ($classPortsmouthNumber > 0)
						{
							$found[$classKey] = true;
							$fmt = "INSERT INTO class("
									. "classKey,"
									. "className,"
									. "classSource,"
									. "classPortsmouthNumber) VALUES("
									. $db->quote($classKey) . ","
									. $db->quote($className) . ","
									. $db->quote($classSource) . ","
									. $classPortsmouthNumber . ")";
							array_push($commands, $fmt);
							$found[$classKey] = $classPortsmouthNumber;
							if ($type == "M")
							{
								$fmt = "UPDATE class SET classMultiHull='yes' WHERE classKey=" . $db->quote($classKey);
								array_push($commands, $fmt);
							}
						}
					}
				}
			}
		}

		if (!$started)
		{
			ClassMine::reportError("File " . ClassMine::GREATLAKES_FILESPEC . " does not contain the required columns.");
			return(false);
		}

		$flags = 0;
		$started = false;
		if ($rows = array_map('str_getcsv', file(ClassMine::SCHRS_FILESPEC)))
		{
			foreach ($rows as $cells)
			{
				if (!$started)
				{
					$cellIndex = 0;
					foreach($cells as $cell)
					{
						$cell = trim($cell);
						$essence = Misc::essence($cell);
						switch($essence)
						{
							case "_class":
							{
								$flags |= 1;
								$classIndex = $cellIndex;
								break;
							}
							case "_pnla":
							{
								$flags |= 2;
								$schrsNumberIndex = $cellIndex;
								break;
							}
							case "_crew":
							{
								$flags |= 4;
								$crewIndex = $cellIndex;
								break;
							}
						}
						$cellIndex ++;
					}
					if ($flags == 7)
					{
						$started = true;
					}
				}
				else
				{
					$crew = intval($cells[$crewIndex], 10);
					if ($crew > 0)
					{
						$className = trim($cells[$classIndex]);
						$classKey = Misc::essence($className);
						$classPortsmouthNumber = intval($cells[$schrsNumberIndex]);
						if (isset($found[$classKey]))
						{
							$fmt = "UPDATE class SET classCrew=" . $crew . " WHERE classKey=" . $db->quote($classKey);
							array_push($commands, $fmt);
						}
						else
						{
							$fmt = "INSERT INTO class("
								. "classKey,"
								. "className,"
								. "classSource,"
								. "classMultiHull,"
								. "classCrew,"
								. "classPortsmouthNumber) VALUES("
								. $db->quote($classKey) . ","
								. $db->quote($className) . ","
								. "'SCHRS',"
								. "'yes',"
								. $crew . ","
								. $classPortsmouthNumber . ")";
							array_push($commands, $fmt);
							$found[$classKey] = $classPortsmouthNumber;
						}
					}
				}
			}
		}

		if (!$started)
		{
			ClassMine::reportError("File " . ClassMine::SCHRS_FILESPEC . " does not contain the required columns.");
			return(false);
		}

		if (file_exists(ClassMine::CLUB_FILESPEC))
		{
			$flags = 0;
			$started = false;

			if ($xlsx = SimpleXLSX::parse(ClassMine::CLUB_FILESPEC))
			{
				// Club file contains extra classes and overriders
				foreach ($xlsx->rows() as $cells)
				{
					if (!$started)
					{
						$cellIndex = 0;
						foreach ($cells as $cell)
						{
							$cell = trim($cell);
							$essence = Misc::essence($cell);
							switch ($essence)
							{
								case "_classname": {
										$flags |= 1;
										$classNameIndex = $cellIndex;
										break;
									}
								case "_basename": {
										$flags |= 2;
										$baseNameIndex = $cellIndex;
										break;
									}
								case "_number": {
										$flags |= 4;
										$numberIndex = $cellIndex;
										break;
									}
								case "_allowance": {
										$flags |= 8;
										$allowanceIndex = $cellIndex;
										break;
									}
								case "_multihull": {
										$flags |= 16;
										$multihullIndex = $cellIndex;
										break;
									}
								case "_crew": {
										$flags |= 32;
										$crewIndex = $cellIndex;
										break;
									}
							}
							$cellIndex++;
						}
						if ($flags == 63)
						{
							$started = true;
						}
					}
					else
					{
						$className = trim($cells[$classNameIndex]);
						$classKey = Misc::essence($className);
						$baseName = trim($cells[$baseNameIndex]);
						$baseKey = Misc::essence($baseName);
						$classPortsmouthNumber = intval($cells[$numberIndex], 10);
						$classAllowance = intval($cells[$allowanceIndex]);
						$classCrew = intval($cells[$crewIndex]);
						$classMultiHull = intval($cells[$multiHullIndex]);

						
						if ((isset($classAllowance)) && (!empty($baseKey)))
						{
							if ($baseKey == $classKey)
							{
								ClassMine::reportError("File " . ClassMine::CLUB_FILESPEC . " Base name cannot be the same as Class Name.");
								return(false);
							}
							if (!isset($found[$baseKey]))
							{
								ClassMine::reportError("File " . ClassMine::CLUB_FILESPEC . " Base name " . $className . " not found in Great Lakes or SCHRS lists.");
								return(false);
							}
							if (isset($found[$classKey]))
							{
								// User is overiding a number using the number of another class
								$fmt = "UPDATE class SET classAllowance=" . $classAllowance
									. ", classBaseName=" . $db->quote($classBaseName)
									. ", classPortsmouthNumber=" . ($found[$baseKey] + $classAllowance)
									. ", classSource='Club'"
									. " WHERE classKey=" . $db->quote($classKey);
								array_push($commands, $fmt);
							}
							else
							{
								// User is inserting a new class using the number of another class
								$fmt = "INSERT INTO class("
									. "classKey,"
									. "className,"
									. "classBaseName,"
									. "classSource,"
									. "classMultiHull,"
									. "classCrew,"
									. "classAllowance,"
									. "classPortsmouthNumber) VALUES("
									. $db->quote($classKey) . ","
									. $db->quote($className) . ","
									. $db->quote($baseName) . ","
									. "'club',"
									. $db->quote($classMultiHull) . ","
								. $classCrew . ","
								. $classAllowance . ","
								. $classPortsmouthNumber . ")";
								array_push($commands, $fmt);
							}
						}
						else if ($classPortsmouthNumber > 0)
						{
							if (isset($found[$classKey]))
							{
								// User is overriding the number of an existing class
								$fmt = "UPDATE class SET classPortsmouthNumber=" . ($found[$baseKey] + $classAllowance)
									. ", classSource='Club'"
									. " WHERE classKey=" . $db->quote($classKey);
								array_push($commands, $fmt);
							}
							else
							{
								// User is inserting a new class using the number of another class
								$fmt = "INSERT INTO class("
									. "classKey,"
									. "className,"
									. "classSource,"
									. "classMultiHull,"
									. "classCrew,"
									. "classPortsmouthNumber) VALUES("
									. $db->quote($classKey) . ","
									. $db->quote($className) . ","
									. "'Club',"
									. $db->quote($classMultiHull) . ","
								. $classCrew . ","
								. $classPortsmouthNumber . ")";
								array_push($commands, $fmt);
							}
						}
					}
				}
			}
			if (!$started)
			{
				ClassMine::reportError("File " . ClassMine::CLUB_FILESPEC . " does not contain the required columns.");
				return(false);
			}
		}
		$db->execArray($commands);
		return(true);
	}

	public static function reportError($message)
	{
		// Should email administrators
	}

	// Before May 2023 we had duplicate names
	public static function rectify()
	{
		$db = new Database();
		$commands = array();
		$items = array(
			array("14 INTERNATIONAL", "int 14"),
			array("14International", "int 14"),
			array("A CLASS", " A Class Classic"),
			array("BLAZE (ALLOY RIG)", "Blaze (Alloy Rig)"),
			array("CANOE INTERNATIONAL", "Int Canoe"),
			array("ILCA 4", "ILCA 4 / Laser 4.7"),
			array("ILCA 6", "ILCA 6 / Laser Radial"),
			array("Int Moth", "Int Moth (Non-foiling)"),
			array("LASER", "ILCA 7 / Laser"),
			array("Laser", "ILCA 7 / Laser"),
			array("LASER 4.7", "ILCA 4 / Laser 4.7"),
			array("Laser 4.7", "ILCA 4 / Laser 4.7"),
			array("LASER PICO (6.4 Sail)"),
			array("LASER RADIAL", "ILCA 6 / Laser Radial"),
			array("Laser Radial", "ILCA 6 / Laser Radial"),
			array("MERLIN-ROCKET 2165 - 2832", "Merlin Rocket (2165 - 2832)"),
			array("MERLIN-ROCKET 3331 - 3429", "Merlin Rocket (3331 - 3429)"),
			array("Mirror", "Mirror (D/H)"),
			array("MIRROR DH", "Mirror (D/H)"),
			array("MOTH FOILING", "Int Moth (Foiling)"),
			array("Moth Foiling", "Int Moth (Foiling)"),
			array("National 12 DB"),
			array("PHANTOM (CARBON NON-FRP)"),
			array("RS 100 10.2", "RS100 10.2"),
			array("RS 100 8.4", "RS100 8.4"),
			array("RS 200", "RS200"),
			array("RS 300", "RS300"),
			array("RS 400", "RS400"),
			array("RS 500", "RS500"),
			array("RS 600", "RS600"),
			array("RS 800", "RS700"),
			array("RS FEVA XL N/S"),
			array("SPRINT 15", "Dart 15"),
			array("SPRINT 15 SPORT", "Dart 15 Sport"));

		foreach($items as $item)
		{
			$fmt = "UPDATE result SET resultClassName=" . $db->quote($item[1])
				. " WHERE resultClassName LIKE " . $db->quote($item[0]);
			array_push($commands, $fmt);
		}
		$db->execArray($commands);

		// Now rebuild the reg table

		$db->exec("DROP TABLE IF EXISTS t");
		$fmt = "CREATE TEMPORARY TABLE t AS"
				. " SELECT resultHelmName, resultClassName, resultSailNumber, resultCrewName, resultExtraCrewName, MAX(resultYYYYMMDD) AS resultYYYYMMDD"
				. " FROM result group BY resultHelmName, resultClassName, resultSailNumber, resultCrewName, resultExtraCrewName";
		$db->exec($fmt);

		$fmt = "SELECT * FROM t WHERE resultYYYYMMDD > '2021-01-01'";
		$result = $db->query($fmt);

		$commands = array();
		array_push($commands, "DELETE FROM reg");
		while ($cells = $result->fetchArray(SQLITE3_ASSOC))
		{
			$helmKey = $db->getSailorKeyBySailorName($cells["resultHelmName"]);
			$crewKey = $db->getSailorKeyBySailorName($cells["resultCrewName"]);
			$extraCrewKey = $db->getSailorKeyBySailorName($cells["resultExtraCrewName"]);
			$classKey = $db->getClassKeyByClassName($cells["resultClassName"]);

			if (!(empty($helmKey)) && !(empty($classKey)))
			{
				$fmt = "INSERT INTO reg VALUES(NULL"
					. "," . $db->quote($classKey)
					. "," . $db->quote($cells["resultSailNumber"])
					. "," . $db->quote(Misc::essence($cells["resultSailNumber"]))
					. "," . $db->quote($helmKey)
					. "," . $db->quote($crewKey)
					. "," . $db->quote($extraCrewKey)
					. ",NULL, NULL)";
				array_push($commands, $fmt);
			}
		}
		$db->execArray($commands);

		return(true);
	}

	public static function update($force = false)
	{
		$unixEpochSecondsFile = filemtime(ClassMine::TOUCH_FILESPEC);
		if ($force || (time() > $unixEpochSecondsFile + 24 * 60 * 60) || (filemtime(ClassMine::CLUB_FILESPEC) > $unixEpochSecondsFile))
		{
			if (file_put_contents(ClassMine::TOUCH_FILESPEC, "" . time()) === false)
			{
				ClassMine::reportError("Failed to touch file " . ClassMine::TOUCH_FILESPEC);
				return(false);
			}
			if (!ClassMine::greatLakes())
			{
				return(false);
			}
			if (!ClassMine::schrs())
			{
				return(false);
			}
			if (!ClassMine::build())
			{
				return(false);
			}
			ClassMine::rectify();
			return(true);
		}
		return(true);
	}
}

