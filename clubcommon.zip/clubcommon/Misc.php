<?php

class Misc
{
	function __construct()
	{

	}


	static function errorExit($message, $code = false)
	{
		$object = new stdClass();
		$object->trace = debug_backtrace();
		if (!empty($code))
		{
			$object->errorCode = $code;
		}
		$object->errorMessage = $message;
		echo(json_encode($object, JSON_PRETTY_PRINT));
		exit();
	}

	static function getFormValue($key, $default)
	{
		error_reporting(0);
		$s = $_POST[$key];
		if (isset($s) == FALSE) $s = $_GET[$key];
		error_reporting(E_ERROR | E_PARSE);

		if (isset($s) != FALSE) $s = trim($s);
		else return($default);
		return($s);
	}

	static function getTask()
	{
		if (!($task = Misc::getFormValue("jsonencodedtask", false)))
		{
			return new stdClass();
		}
		if (!($task = json_decode($task)))
		{
			Misc::errorExit("Error - GetTask. Bad json encoding");
		}
		return($task);
	}


	static function essence($s)
	{
		if (empty($s))
		{
			return("");
		}
		$s = strtolower(preg_replace("/[^A-Za-z0-9]/", '', $s));
		if (empty($s))
		{
			return("");
		}
		return("_" . $s);
	}

	static function getConfigValue($db, $name)
	{
		$s = $db->querySingle("SELECT value FROM namedValues WHERE name LIKE '" . $name . "'");
		if (empty($s))
		{
			return(array());
		}

		if (empty($got = json_decode($s)))
		{
			Misc::errorExit("Malformed json in namedValues table (" . $name .")");
		}

		return($got);
	}

	static function getConfigValueAssoc($db, $name)
	{
		$a = Misc::getConfigValue($db, $name);
		if (empty($a))
		{
			return(array());
		}
		$b = array();
		foreach($a AS $item)
		{
			$b[$item->key] = $item;
		}
		return($b);
	}

	static function getConfigValueFirstItemKey($db, $name)
	{
		$s = $db->querySingle("SELECT value FROM namedValues WHERE name LIKE '" . $name . "'");
		if (empty($s))
		{
			return(false);
		}

		if (empty($got = json_decode($s)))
		{
			Misc::errorExit("Malformed json in namedValues table (" . $name .")");
		}

		if (count($got) == 0)
		{
			return(false);
		}

		return($got[0]->key);
	}


	static function fetchSignOns($db, $startUnixEpochSeconds, $endUnixEpochSeconds, $type)
	{
		if ($type == "duty")
		{
			$fmt = "SELECT sailorKey, sailorName as helmName,signonType"
			. " FROM signon,sailor"
			. " WHERE signonUnixEpochSeconds>" . $startUnixEpochSeconds
			. " AND signonUnixEpochSeconds<" . $endUnixEpochSeconds
			. " AND sailorKey = signonHelmKey"
			. " AND (signonType=" . $db->quote($type) . " OR signonType='signoff')"
			. " ORDER BY signonUnixEpochSeconds";
			$result = $db->query($fmt);

			// Overwrite subsequent signons made by each helm during the period
			// Determine whether entries are signed off or not.
			$signons = array();
			while ($cells = $result->fetchArray(SQLITE3_ASSOC))
			{
				$helmKey = $cells["sailorKey"];
				if ($cells["signonType"] == "signoff")
				{
					if ($signons[$helmKey])
					{
						$signons[$helmKey]["signedOff"] = true;
					}
				}
				else
				{
					$signons[$helmKey] = $cells;
				}
			}
			$items = array();
			foreach ($signons as $signon)
			{
				array_push($items, $signon);
			}
			return($items);
		}



		$fmt = "SELECT className,classPortsmouthNumber,sailorName as helmName,signonType,reg.*"
			. " FROM signon,class,reg,sailor"
			. " WHERE signonUnixEpochSeconds>" . $startUnixEpochSeconds
			. " AND signonUnixEpochSeconds<" . $endUnixEpochSeconds
			. " AND classKey = regClassKey"
			. " AND sailorKey = regHelmKey"
			. " AND signonRegKey=regKey"
			. " AND (signonType=" . $db->quote($type) . " OR signonType='signoff')"
			. " ORDER BY signonUnixEpochSeconds";
		$result = $db->query($fmt);

		// Overwrite subsequent signons made by each helm during the period
		// Determine whether entries are signed off or not.
		$signons = array();
		while ($cells = $result->fetchArray(SQLITE3_ASSOC))
		{
			$helmKey = $cells["regHelmKey"];
			if ($cells["signonType"] == "signoff")
			{
				if ($signons[$helmKey])
				{
					$signons[$helmKey]["signedOff"] = true;
				}
			}
			else
			{
				if (!empty($s = $cells["regCrewKey"]))
				{
					$cells["crewName"] = $db->getSailorNameBySailorKey($s);
				}
				if (!empty($s = $item["regExtraCrewKey"]))
				{
					$cells["extraCrewName"] = $db->getSailorNameBySailorKey($s);
				}
				$signons[$helmKey] = $cells;
			}
		}
		$items = array();
		foreach($signons as $signon)
		{
			array_push($items, $signon);
		}
		return($items);
	}


}
