/*
 * function dialogPush(title)
 * returns a div to which you can append elements
 * You will probably add an OK button and a Cancel button.
 *
 * function dialogPop()
 * removes the most recently pushed dialog from the stack and the screen.
 *
 */

"use strict";

var mDialog = {};

////////////////////////////////////////////////////////////////////////////
//
function dialogCheckVisibility(div)
{
	let left = parseFloat(div.style.left);
	let width = div.offsetWidth;
	if ((left + width) > window.innerWidth) div.style.left = "" + (window.innerWidth - width) + "px";
	left = parseFloat(div.style.left);
	if (left < 0) div.style.left = 0;
	let top = parseFloat(div.style.top);
	let height = div.offsetHeight;
	if ((top + height) > window.innerHeight) div.style.top = "" + (window.innerHeight - height) + "px";
	top = parseFloat(div.style.top);
	if (top < 0) div.style.top = 0;
}
//
//////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
// Resize a guard div.
//
function dialogResize(evt)
{
	evt.target.style.width = "" + window.innerWidth + "px";
	evt.target.style.height = "" + window.innerHeight + "px";

	if (!mDialog.current) return;
	dialogCheckVisibility(mDialog.current);
}
//
//////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
function dialogPointerDown(evt)
{
	evt.preventDefault();
	// get the pointer cursor position at startup:
	mDialog.clientX = evt.clientX;
	mDialog.clientY = evt.clientY;
	mDialog.form = evt.target.parentElement;
	document.addEventListener("pointerup", dialogPointerUp);
	document.addEventListener("pointermove", dialogPointerMove);
}
//
//////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
function dialogPointerMove(evt)
{
	evt.preventDefault();
	// calculate the new cursor position:
	let deltax = mDialog.clientX - evt.clientX;
	let deltay = mDialog.clientY - evt.clientY;
	mDialog.clientX = evt.clientX;
	mDialog.clientY = evt.clientY;
	mDialog.form.style.top = "" + (mDialog.form.offsetTop - deltay) + "px";
	mDialog.form.style.left = "" + (mDialog.form.offsetLeft - deltax) + "px";
}
//
//////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
 function dialogPointerUp(evt)
 {
	dialogCheckVisibility(mDialog.form);
	document.removeEventListener("pointermove", dialogPointerMove);
	document.removeEventListener("pointerup", dialogPointerUp);
}
//
//////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
function dialogPreventDefault(evt)
{
	evt.preventDefault();
}
//
//////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
function dialogButtonHandler(evt)
{
	evt.preventDefault();
	let form = dialogGetForm(evt.target);
	if (form.submitHandler) form.submitHandler(evt);
	else dialogPop();
}
//
//////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
function dialogDefaultSubmitHandler(evt)
{
	evt.preventDefault();
}
//
//////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
// Create Submit Button
//
function dialogCSB(parentelement, html, handler)
{
	let button = document.createElement("button");
	button.innerHTML = html;
	button.style.marginLeft = "0.5em";
	if (!handler) handler = dialogButtonHandler;
	button.addEventListener("click", handler);
	parentelement.appendChild(button);
	return(button);
}
//
//////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
// Create Cancel Button
//
function dialogCCB(parentelement, html, handler)
{
	let button = document.createElement("button");
	button.innerHTML = html;
	button.style.marginLeft = "0.5em";
	if (!handler) handler = dialogPop;
	button.addEventListener("click", handler);
	parentelement.appendChild(button);
	return(button);
}
//
//////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
// The print module needs to hide any dialog boxes
//
function dialogHideAll()
{
	let div = mDialog.current;
	while (div)
	{
		div.style.display = "none";
		div.guard.style.display = "none";
		div = div.previous;
	}
}
//
//////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
// The print module needs to hide any dialog boxes
//
function dialogShowAll()
{
	let div = mDialog.current;
	while (div)
	{
		div.style.display = "";
		div.guard.style.display = "";
		div = div.previous;
	}
}
//
//////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
function dialogPop(evt)
{
	let div = mDialog.current;
	if (!div) return;
	mDialog.current = div.previous;
	document.body.removeChild(div.guard);
	document.body.removeChild(div);
	if (!mDialog.current) return;
	dialogCheckVisibility(mDialog.current);
}
//
//////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
function dialogCloseButtonHandler(evt)
{
	evt.preventDefault();
	let form = dialogGetForm(evt.target);
	if (form.closeButtonHandler) form.closeButtonHandler(evt);
	else dialogPop();

}
//
//////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
function dialogKeyboardListener(evt)
{
	if (evt.key != "Enter") return;
	let form = dialogGetForm(evt.target);
	if (!form) return;

	if (form.submitHandler)
	{
		evt.preventDefault();
		form.submitHandler(evt);
	}
}
//
//////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
// Detect enter key in any inputs of type text or number
// and set focus to first input found.
//
function dialogSetKeybardListener(form)
{
	let inputs = form.getElementsByTagName("input");
	let input = false;
	for (let i = 0; i < inputs.length; i ++)
	{
		switch(inputs[i].type.toLowerCase())
		{
			case "text":
			case "number":
			{
				if (!input) input = inputs[i];
				inputs[i].addEventListener("keydown", dialogKeyboardListener);
			}
		}
	}
	if (input) input.focus();
}
//
//////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
function dialogSelectStartHandler(evt)
{
	evt.preventDefault();
}
//
////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
function dialogPush(title, submithandler)
{
	// CREATE A GUARD DIV TO DISABLE POINTER
	let guard = document.createElement('div');
	document.body.appendChild(guard);
	guard.style.position = "absolute";
	guard.style.left = 0;
	guard.style.top = 0;
	guard.style.width = "" + window.innerWidth + "px";
	guard.style.height = "" + window.innerHeight + "px";
	guard.style.background = "rgba(0, 0, 0, 0.2)";

	guard.addEventListener("resize", dialogResize);
	guard.addEventListener("pointerdown", dialogPreventDefault, true);
	guard.addEventListener("click", dialogPreventDefault, true);

	let x = "1em";
	let y = "1em";
	if (mDialog.current)
	{
		x = "" + (mDialog.current.offsetLeft + 14) + "px";
		y = "" + (mDialog.current.offsetTop + 14) + "px";
	}

	let form = document.createElement('div');
	form.setAttribute("class", "form");
	form.style.position = "fixed";
	form.style.left = x;
	form.style.top = y;
	form.style.display = "block";
	form.style.borderStyle = "solid";
	form.style.borderWidth = "1px";
	form.style.borderColor = "black";
	form.style.borderRadius = "0.5em";
	form.style.padding = "0.3em";
	form.style.cursor = "default";
	form.style.background = "linear-gradient(" + mColor.backgroundColor + ", white)";
	if (submithandler) form.submitHandler = submithandler;

	form.guard = guard;

	form.addEventListener("selectstart", dialogSelectStartHandler);
	form.addEventListener("submit", dialogDefaultSubmitHandler);

	form.stack = [];

	document.body.appendChild(form);
	form.previous = mDialog.current;
	mDialog.current = form;

	if (!title) title = mApp.name;
	else title = mApp.name + " - " + title;

	let div = document.createElement("div");
	form.appendChild(div);
	div.innerHTML = title;
	div.style.paddingRight = "2em";
	div.style.paddingTop = "0.2em";
	div.style.paddingBottom = "0.5em";

	div.addEventListener("pointerdown", dialogPointerDown);

	var button = document.createElement("button");
	form.appendChild(button);
	button.style.position = "absolute";
	button.style.top = "0.3em";
	button.style.right = "0.3em";
	button.style.color = "red";
	button.style.padding = "0.1em";
	button.innerHTML = "X";
	button.addEventListener("click", dialogCloseButtonHandler);
	form.closeButton = button;

	setTimeout(dialogCheckVisibility, 100, form);

	return(form);
}
//
////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////
//
function dialogAddCloseButton(form, listener)
{
	if (!listener) return;
	if (form.closeButtonHandler) form.closeButton.removeListener(form.closeButtonHandler);
	form.closeButtonHandler = listener;
}
//
////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////////////////
//
function dialogAlert(message, handler)
{
	if (!handler) handler = dialogPop;
	let form = dialogPush();
	dialogAddCloseButton(form)

	let p = document.createElement("p");
	form.appendChild(p);
	p.innerHTML = message;

	p = document.createElement("p");
	form.appendChild(p);
	let button = dialogCSB(p, "OK", handler);
	button.focus();
}
//
//////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////
//
function dialogAlertOnceOK(evt)
{
	let form = dialogGetForm(evt.target);
	if (form.checkbox.checked)
	{
		mApp.suppressed[form.message] = true;
	}
	dialogPop();
}
//
//////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////
//
function dialogAlertOnce(message)
{
	if (mApp.suppressed[message]) return;
	let form = dialogPush(false);
	dialogAddCloseButton(form)

	let p = document.createElement("p");
	form.appendChild(p);
	p.innerHTML = message;

	p = document.createElement("p");
	form.appendChild(p);
	let button = dialogCSB(p, "OK", dialogAlertOnceOK);
	button.focus();

	p = document.createElement("p");
	form.appendChild(p);
	let checkbox = appCheckBox(p, "Do not show this message again.", false);

	form.message = message;
	form.checkbox = checkbox;

	input.focus();
}
//
//////////////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////
//
class dialogTable
{
	constructor(element)
	{
		this.table = document.createElement("table");
		this.table.style.marginRight = "1em";
		this.table.style.overflowY = "auto";
		element.appendChild(this.table);

	}

	appendRow(name, value)
	{
		let row = this.table.insertRow(-1);
		let cell = row.insertCell(-1);
		cell.innerHTML = name;
		cell.style.verticalAlign = "top";
		cell = row.insertCell(-1);
		cell.innerHTML = value;
		cell.style.maxWidth = "32em";
		return(row);
	}

	appendBlankRow()
	{
		let row = this.table.insertRow(-1);
		let cell = row.insertCell(-1);
		cell.innerHTML = "&nbsp"
		cell.style.fontSize = "50%";
		cell.style.borderStyle = "none";
		return(row);
	}

	appendTitleRow(title)
	{
		appendSplitRow()
		let row = this.table.insertRow(-1);
		let cell = row.insertCell(-1);
		cell.setAttribute("colspan", "2");
		cell.innerHTML = "<b>" + title + "</b>";
		return(row);
	}

	appendSignatureRow(whomodified, whenmodified)
	{
		let row = this.table.insertRow(-1);
		let cell = row.insertCell(-1);
		cell.setAttribute("colspan", "2");
		cell.style.textAlign = "right";
		cell.style.fontSize = "60%";
		cell.innerHTML = whomodified + " " + appFormatDateTime(whenmodified);
		return(row);
	}

	print()
	{
		printTable(this.table);
	}
}
//
////////////////////////////////////////////////////////////////////////////


//////////////////////////////////////////////////////////////////////////////////////////
//
function dialogHandler(evt)
{
	let button = evt.target;
	dialogPop();
	button.userHandler(evt);
}
//
////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////
//
function dialogYes(context, message, onyes, onno)
{
	let form = dialogPush(false, onyes);
	dialogAddCloseButton(form);

	let p = document.createElement("p");
	form.appendChild(p);
	p.innerHTML = message;

	p = document.createElement("p");
	p.style.textAlign = "right";
	form.appendChild(p);

	let button = dialogCSB(p, "Yes", dialogHandler);
	button.userHandler = onyes;
	button.context = context;
	button.focus();

	if (onno)
	{
		button = dialogCSB(p, "No", dialogHandler);
		button.userHandler = onno;
		button.context = context;
		button.focus();
	}

	dialogCCB(p, "Cancel");
}
//
//////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////
//
function dialogQueryDiscard(context, message, savehandler, discardhandler)
{
	let form = dialogPush();
	let p = document.createElement("p");
	form.appendChild(p);
	p.innerHTML = message;

	p = document.createElement("p");
	p.style.textAlign = "right";
	form.appendChild(p);

	let button = dialogCSB(p, "Save Changes", dialogHandler);
	button.userHandler = savehandler;
	button.context = context;
	button.focus();

	button = dialogCSB(p, "Discard Changes", dialogHandler);
	button.userHandler = discardhandler;
	button.context = context;

	dialogCCB(p, "Cancel");
}
//
//////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//
function dialogGetForm(element)
{
	while ((element) &&
			(element.tagName.toLowerCase() != "div") &&
			(element.className.toLowerCase() != "form")) element = element.parentElement;
	return(element);
}
//
//////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////
//
function dialogPreventDefault(evt)
{
	evt.preventDefault();
}
//
//////////////////////////////////////////////////////////////////

