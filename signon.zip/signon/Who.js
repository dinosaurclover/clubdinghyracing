/* global Sailing */
/* global What */

class Who
{
	static pickSailor()
	{
		Sailing.bringToFront("who");
		let conn = new HttpURLConnection();
		let xmlhttp = new HttpURLConnection();
		xmlhttp.setFailureFunction((conn) =>
		{
			Sailing.setError("who", conn.object.errorMessage);
		});
		xmlhttp.setSuccessFunction((conn) => 
		{
			Who.sailors = conn.object.sailors;
			Who.display();
		});
		xmlhttp.transmit("command=listsailorsbyname");
	}
	
	static display()
	{
		let div = document.getElementById("who");
		
		let contentDiv = div.children[1];
		contentDiv.innerHTML = "";
		let h2 = document.createElement("h2");
		contentDiv.appendChild(h2);
		h2.innerHTML = "Who Are You?";
		if (Auth.type !== "duty")
		{
			h2 .appendChild(document.createTextNode(" (helm)"));
		}

		let p = document.createElement("p");
		contentDiv.appendChild(p);
		let input = document.createElement("input");
		p.appendChild(input);
		let datalist = document.getElementById("names");
		datalist.innerHTML = "";
		input.setAttribute("list", "names");
		for (const key in Who.sailors)
		{
			let option = document.createElement("option");
			option.innerHTML = Who.sailors[key];
			datalist.appendChild(option);
		}
		
		p = document.createElement("p");
		contentDiv.appendChild(p);
		let button = document.createElement("button");
		p.appendChild(button);
		button.innerHTML = "OK";
		button.addEventListener("click", () =>
		{
			What.className = "";
			What.sailNumber = false;
			What.crewName = false;
			What.ExtraCrewName = false;
			
			// User might, eventually, register a new boat with guest crew names
			Register.zero();
			
			let wordCount = 0;
			input.value = input.value.toLowerCase().replace(/\b\w/g, (c) => 
			{
				wordCount ++;
				return(c.toUpperCase());
			});
			
			if (wordCount < 2)
			{
				Sailing.setError("who", "Unacceptable helm name. Please enter first name and last name.");
				return;
			}
			
			input.validated = false;
			let key = Misc.essence(input.value);
			if (!Who.sailors[key])
			{
				Register.previous = "who";
				Register.addGuest(input, () =>
				{
					if (input.validated)
					{
						// User declared name as guest or picked from a list of similar names.
						Who.helmName = input.value;
						What.pickBoat();
					}
					Sailing.bringToFront("who");
				});
				return;
			}
			Who.helmName = input.value;
			What.pickBoat();
		});
		
		if (!Sailing.flags)
		{
			input.value = localStorage.getItem("signonHelmName");
			input.focus();
			input.addEventListener("keydown", (evt) =>
			{
				if (evt.key === "Enter")
				{
					button.click();
				}
			});
		}
		else
		{
			input.addEventListener("focus", () =>
			{
				new Keyboard(input);
			});
		}
		Sailing.resize();
	}
	
	/*
	static populate(evt)
	{
		let sailors = evt.target.sailors;
		let div = document.getElementById("who");
		let contentDiv = div.children[1];
		contentDiv.innerHTML = "";
		
		for (const key in sailors)
		{
			let button = document.createElement("button");
			contentDiv.appendChild(button);
			button.setAttribute("class", "sailorButton");
			button.innerHTML = sailors[key];
			contentDiv.appendChild(document.createElement("br"));
			button.addEventListener("click", What.pickBoat);
		}
		Sailing.resize();
	}
	 * */
}