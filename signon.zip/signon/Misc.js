class Misc
{
	static modified = false;
	
	static toast(html)
	{
		let div = document.createElement("div");
		div.id = "snackbar";
		document.body.appendChild(div);
		div.innerHTML = html;
		div.className = "show";
		setTimeout(function ()
		{
			div.className = div.className.replace("show", "");
		}, 3000);
		setTimeout(function ()
		{
			document.body.removeChild(div);
		}, 5000);
	}
	
	static climbTo(element, tagName)
	{
		tagName = tagName.toLocaleLowerCase();
		while ((element) && (element.tagName.toLocaleLowerCase() !== tagName))
		{
			element = element.parentElement;
		}
		return(element);
	}

	static similarText(first, second, percent)
	{ // eslint-disable-line camelcase
		//  discuss at: https://locutus.io/php/similar_text/
		// original by: Rafał Kukawski (https://blog.kukawski.pl)
		// bugfixed by: Chris McMacken
		// bugfixed by: Jarkko Rantavuori original by findings in stackoverflow (https://stackoverflow.com/questions/14136349/how-does-similar-text-work)
		// improved by: Markus Padourek (taken from https://www.kevinhq.com/2012/06/php-similartext-function-in-javascript_16.html)
		//   example 1: similar_text('Hello World!', 'Hello locutus!')
		//   returns 1: 8
		//   example 2: similar_text('Hello World!', null)
		//   returns 2: 0
		if (first === null ||
				second === null ||
				typeof first === 'undefined' ||
				typeof second === 'undefined')
		{
			return(0);
		}
		first = String(first);
		second += String(second);
		const firstLength = first.length;
		const secondLength = second.length;
		
		let pos1 = 0;
		let pos2 = 0;
		let max = 0;
		let p = false;
		let q = false;
		let l = false;
		let sum = false;
		for (p = 0; p < firstLength; p++)
		{
			for (q = 0; q < secondLength; q++)
			{
				for (l = 0; (p + l < firstLength) && (q + l < secondLength) && (first.charAt(p + l) === second.charAt(q + l)); l++)
				{ // eslint-disable-line max-len
					// @todo: ^-- break up this crazy for loop and put the logic in its body
				}
				if (l > max)
				{
					max = l;
					pos1 = p;
					pos2 = q;
				}
			}
		}
		sum = max;
		if (sum)
		{
			if (pos1 && pos2)
			{
				sum += Misc.similarText(first.substr(0, pos1), second.substr(0, pos2));
			}
			if ((pos1 + max < firstLength) && (pos2 + max < secondLength))
			{
				sum += Misc.similarText(
						first.substr(pos1 + max, firstLength - pos1 - max),
						second.substr(pos2 + max,
								secondLength - pos2 - max));
			}
		}
		if (!percent)
		{
			return(sum);
		}
		return((sum * 200) / (firstLength + secondLength));
	}
	

	static findDistance(first, second, percent)
	{ // eslint-disable-line camelcase
		//  discuss at: https://locutus.io/php/similar_text/
		// original by: Rafał Kukawski (https://blog.kukawski.pl)
		// bugfixed by: Chris McMacken
		// bugfixed by: Jarkko Rantavuori original by findings in stackoverflow (https://stackoverflow.com/questions/14136349/how-does-similar-text-work)
		// improved by: Markus Padourek (taken from https://www.kevinhq.com/2012/06/php-similartext-function-in-javascript_16.html)
		//   example 1: similar_text('Hello World!', 'Hello locutus!')
		//   returns 1: 8
		//   example 2: similar_text('Hello World!', null)
		//   returns 2: 0
		if (first === null ||
				second === null ||
				typeof first === 'undefined' ||
				typeof second === 'undefined')
		{
			return(0);
		}
		let a = String(first);
		let b = String(second);
		
		a = Array.from(a);
		b = Array.from(b);
		
		let alen = a.length;
		let blen = b.length;
		
		let matrix = [];
		
		for (let i = 0; i <= blen; i ++)
		{
			let row = [];
			for (let j = 0; j <= alen; j ++)
			{
				row.push(0);
			}
			matrix.push(row);
		}
		// Initialising first column:
		for (let i = 0; i <= blen; i ++)
		{
			matrix[i][0] = i;
		}
		// Initialising first row:
		for (let i = 0; i <= alen; i ++)
		{
			matrix[0][i] = i;
		}

		// Applying the algorithm:
		let insertion = false;
		let deletion = false;
		let replacement = false;

		for (let i = 1; i <= blen; i++)
		{
			for (let j = 1; j <= alen; j++)
			{
				if(b[i - 1] === a[j - 1])
				{
					matrix[i][j] = matrix[i - 1][j - 1];
				}
				else
				{
					// Choosing the best option:
					insertion = matrix[i][j - 1];
					deletion = matrix[i - 1][j];
					replacement = matrix[i - 1][j - 1];
					matrix[i][j] = 1 + findMin(insertion, deletion, replacement);
					function findMin(x, y, z)
					{
						if (x <= y && x <= z)
						{
							return x;
						}
						else if ((y <= x) && (y <= z))
						{
							return y;
						}
						else
						{
							return z;
						}
					}
				}
			}
		}
 
		let sum = matrix[blen][alen];

		if (!percent)
		{
			return(sum);
		}
		return((sum * 200) / (alen + blen));
	}	



	static setModified(status = true)
	{
		if (Misc.modified == status)
		{
			return;
		}
		if (status)
		{
			window.addEventListener("beforeunload", Misc.listener);
		}
		else
		{
			window.removeEventListener("beforeunload", Misc.listener);
		} 
		Misc.modified = status;
	}

	static listener(evt)
	{
		// There is no way of making anything happen here
		// Browser puts up a "Changes you made may not be saved"
		// User gets a choice:
		// Leave (continue with loading new page or refresh)
		// or Cancel.
		// Listener is set when anything is changed
		// Cleared after a successful save or discard changes request

		evt.preventDefault();
		evt.stopPropagation();
		evt.returnValue = '';
		console.log("beforeunload");
	}
	
	static essence(s)
	{
		s = s.replace(/[^A-Za-z0-9]/g, "").toLowerCase();
		if (!s)
		{
			return("");
		}
		// Prepend an underscore and strip non-alphanumeric
		return("_" + s);
	}
	
	static translateTableNames(s)
	{
		if (!s)
		{
			return("")
		}
		s = s.replace(/Mothers/g, mESPCRM.aliases.mothers);
		s = s.replace(/mothers/gi, mESPCRM.aliases.mothers.toLowerCase());
		s = s.replace(/Mother/g, mESPCRM.aliases.mother);
		s = s.replace(/mother/gi, mESPCRM.aliases.mother.toLowerCase());
		s = s.replace(/Children/g, mESPCRM.aliases.children);
		s = s.replace(/children/gi, mESPCRM.aliases.children.toLowerCase());
		s = s.replace(/Child/g, mESPCRM.aliases.child);
		s = s.replace(/child/gi, mESPCRM.aliases.child.toLowerCase());
		return(s);
	}
	
	static dateToString(s)
	{
		if (s.length == 8)
		{
			s = s.substr(0, 4) + "-" + s.substr(4,2) + "-" + s.substr(6,2);
		}
		let d = new Date(s + "T" + "12:00:00");
		return(d.toDateString());
	}


	static userFileInput(accept, callback)
	{
		let fileinput = document.getElementById("fileinput");
		if (fileinput)
		{
			fileinput.parentNode.removeChild(fileinput);
		}
		fileinput = document.createElement("input");
		fileinput.type = "file";
		fileinput.id = "fileinput";
		fileinput.style = "position:absolute;left:0;top:100px;display:none;";
		document.body.appendChild(fileinput);
		fileinput.value = '';

		fileinput.accept = accept;
		fileinput.addEventListener('change', change, false);
		fileinput.click();
		function change(evt)
		{
			let f = evt.target.files[0];
			if (f)
			{
				var reader = new FileReader();
				reader.fileObject = f;
				reader.onload = onload;
				reader.readAsBinaryString(f);
				function onload(e)
				{
					var filereader = e.currentTarget;
					let object = {};
					object.fileName = f.name;
					object.data = filereader.result;
					callback(object);
				}
			}
		}
	}

	static processFile(object)
	{
		try
		{
			// ASSUME IT'S A SPREADSHEET
			let workBook = XLSX.read(object.data, {type: 'binary'});
			if (workBook)
			{
				let sheetName = workBook.SheetNames[0];
				if (sheetName)
				{
					let sheet = workBook.Sheets[sheetName];
					if (!sheet)
						sheet = workBook.Sheets[0];


					// There is the function excelRows = XLSX.utils.sheet_to_row_object_array(sheet);
					// but it does bizarre things
					// The sheet object exposes attributes with keys A1, A2, A3 ... B1, B2, B3, etc. etc.
					const regex = new RegExp('^[A-Z][0-9]+$');

					let excelRows = [];
					let keys = Object.keys(sheet);
					const A = "A".charCodeAt(0)

					for (let i = 0; i < keys.length; i++)
					{
						let key = keys[i];
						if (regex.test(key))
						{
							// Must be a cell in the table
							let columnIndex = key.charCodeAt(0) - A;
							let rowIndex = parseInt(key.substr(1), 10) - 1;
							if ((rowIndex >= 0) && (columnIndex >= 0) && (columnIndex < 25))
							{
								while (excelRows.length <= rowIndex)
									excelRows.push([]);
								while (excelRows[rowIndex].length < columnIndex)
									excelRows[rowIndex].push("");
								excelRows[rowIndex][columnIndex] = sheet[key].v;
							}
						}
					}
					return(excelRows);

					task = o;
				}
			}
		}
		catch (error)
		{
			return(false);
		}
	}


}