<?php

class Custom
{
	function __construct($db)
	{
		$this->db = $db;

//		$this->updateReg();

//		$this->updateSailors();

	}

	private function updateReg()
	{
		$fmt = "DELETE FROM reg";
		$this->db->exec($fmt);
		$fmt = "SELECT * FROM registrations";
		$result = $this->db->query($fmt);

		while ($cells = $result->fetchArray(SQLITE3_ASSOC))
		{
			$classKey = $this->db->getClassKeyByClassName($cells["className"]);
			$helmKey = $this->db->getSailorKeyBySailorName($cells["helmName"]);
			if ((!empty($classKey)) && (!empty($helmKey)))
			{
				$crewKey = "NULL";
				$crewName = $cells["crewName"];
				if (!empty($crewName))
				{
					$crewKey = $this->db->getSailorKeyBySailorName($cells["crewName"]);
				}
				$fmt = "INSERT INTO reg VALUES(NULL,"
					. $classKey . ","
					. $this->db->quote($cells["sailNumber"]) . ","
					. $helmKey . ","
					. $crewKey . ","
					. "NULL,"
					. $this->db->quote($cells["dateYYYYMMDD"]) . ")";
				$this->db->exec($fmt);
			}
		}
	}
}
