class Register
{
	static classes = false;
	static validatedNames = [];
	static previous = "who";
	static back()
	{
		Sailing.bringToFront(Register.previous);
	}
	
	static display()
	{
		Register.guestsNames = [];
		


		// This can take a second or two
		let saveDiv = false;
		for (const div of document.getElementsByClassName("topLevel"))
		{
			if (div.style.display !== "none")
			{
				saveDiv = div;
				div.style.display = "none";
			}
		}

		if (Register.classes)
		{
			Register.init();
			return;
		}
		
		let conn = new HttpURLConnection();
		conn.setFailureFunction((conn) =>
		{
			Sailing.setError("login", conn.object.errorMessage);
		});
		conn.setSuccessFunction((conn) =>
		{
			Register.classes = conn.object.classes;
			Register.classNames = conn.object.classNames;
			Register.init();
			Sailing.bringToFront("register");
		});

		conn.transmit("command=listclasses");
		
	}
	
	static zero()
	{
		let div = document.getElementById("register");
		let inputs = div.getElementsByTagName("input");
		for (const input of inputs)
		{
			if (input.type === "text")
			{
				input.value = "";
				input.validated = false;
			}
		}
		let select =  div.getElementsByTagName("select")[0];
		select.innerHTML = "";
		
		Register.validatedNames = [];
	}

	static init()
	{
		let div = document.getElementById("register");
		let inputs = div.getElementsByTagName("input");
		for (const input of inputs)
		{
			if (input.type === "text")
			{
				input.value = "";
			}
		}
		
		inputs[0].value = Who.helmName;
		
		let select =  div.getElementsByTagName("select")[0];
		select.innerHTML = "";
		let option = document.createElement("option");
		select.appendChild(option);
		for (const className of Register.classNames)
		{
			let option = document.createElement("option");
			option.innerHTML = className;
			select.appendChild(option);
		}
		
		if (Sailing.flags)
		{
			inputs[1].addEventListener("focus", () =>
			{
				new Keyboard(inputs[1]);
			});
		}
		
		inputs[2].setAttribute("list", "names");
		Register.crewName = inputs[2].value;
		if (Sailing.flags)
		{
			inputs[2].addEventListener("focus", () =>
			{
				new Keyboard(inputs[2]);
			});
		}
		
		inputs[3].setAttribute("list", "names");
		if (Sailing.flags)
		{
			inputs[3].addEventListener("focus", () =>
			{
				new Keyboard(inputs[3]);
			});
		}
		
		Sailing.bringToFront("register");
	}

	// sumbmit is called repeatedly until all inputs have been validated.
	// User can type names that are not on the list
	// If a name is not recognised user gets a few options
	// User can opt to add the name as a guest (validates)
	// A short list of validated names is maintained for the life of this screen.
	static submit()
	{
		let div = document.getElementById("register");
		let inputs = div.getElementsByTagName("input");
		let select = div.getElementsByTagName("select")[0];
		let task = {};
		
		task.className = select.value.trim();
		if (!task.className)
		{
			Sailing.setError("register", "You must pick a class name.");
			return;
		}

		task.sailNumber = inputs[1].value.trim();
		if (!task.sailNumber)
		{
			Sailing.setError("register", "You must specify a sail number.");
			return;
		}
		
		let crewNameInput = inputs[2];
		let extraCrewNameInput = inputs[3];
		
		crewNameInput.value = crewNameInput.value.toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase());
		extraCrewNameInput.value = extraCrewNameInput.value.toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase());

		if (crewNameInput.value.trim())
		{
			let key = Misc.essence(crewNameInput.value);
			if ((!Who.sailors[key]) && (!Register.validatedNames[key]))
			{
				Register.previous = "register";
				Register.addGuest(crewNameInput, () =>
				{
					if (crewNameInput.validated)
					{
						let key = Misc.essence(crewNameInput.value);
						Register.validatedNames[key] = crewNameInput.value;
						setTimeout(Register.submit);
						return;
					}
					Sailing.bringToFront("register");
				});
				return;
			}
		}

		if (extraCrewNameInput.value.trim())
		{
			let key = Misc.essence(extraCrewNameInput.value);
			if ((!Who.sailors[key]) && (!Register.validatedNames[key]))
			{
				Register.previous = "register";
				Register.addGuest(extraCrewNameInput, () =>
				{
					if (extraCrewNameInput.validated)
					{
						let key = Misc.essence(extraCrewNameInput.value);
						Register.validatedNames[key] = extraCrewNameInput.value;
						setTimeout(Register.submit);
						return;
					}
					Sailing.bringToFront("register");
				});
				return;
			}
		}

		// If control arrives here it's safe to add the registration
		
		task.helmName = Who.helmName;
		task.crewName = crewNameInput.value.trim();
		task.extraCrewName = extraCrewNameInput.value.trim();
		
		let conn = new HttpURLConnection();
		conn.setFailureFunction((conn) =>
		{
			Sailing.setError("register", conn.object.errorMessage);
		});
		conn.setSuccessFunction(() =>
		{
			What.className = task.className;
			What.sailNumber = task.sailNumber;
			What.crewName = task.crewName;
			What.extraCrewName = task.extraCrewName;
			What.portsmouthNumber = Register.classes[Misc.essence(What.className)].classPortsmouthNumber;
			Agree.init("register");
		});
		conn.transmit("command=register&jsonencodedtask=" + encodeURIComponent(JSON.stringify(task)));
	}

	// The server was unhappy with this name.
	// Give user opportunity to add it to the guest list.	
	static addGuest(nameInput, callback)
	{
		Register.nameInput = nameInput;
		Register.callback = callback;
		Register.names = Register.listSimilarNames(nameInput.value);

		let div = document.getElementById("guest");
		let contenDiv = div.children[1];
		
		let h2 = contenDiv.getElementsByTagName("h2")[0];
		h2.innerHTML = nameInput.value;
		
		let inputs = [];
		let i = contenDiv.getElementsByTagName("input");
		for (const input of i)
		{
			inputs.push(input);
		}
		
		let input = inputs.shift();
		input.checked = true;
		
		input = inputs.shift();
		input.checked = false;
		input.nextSibling.innerHTML = "Add " + nameInput.value + " as a <b>Guest</b>";
		
		input = inputs.shift();
		input.checked = false;
		input.nextSibling.innerHTML = "Add " + nameInput.value + " as a <b>Member</b>";
		
		let names = [];
		for (const name of Register.names)
		{
			names.push(name);
		}
		while ((input = inputs.shift()))
		{
			let name = names.shift();
			if (name)
			{
				input.parentElement.style.display = "block";
				input.nextSibling.innerHTML = "Change to " + name;
			}
			else
			{
				input.parentElement.style.display = "none";
			}
		}
		Sailing.bringToFront("guest");
	}

	// Control arrives here when user submits the guest form
	static choose()
	{
		let div = document.getElementById("guest");
		let contenDiv = div.children[1];
		
		let inputs = [];
		let i = contenDiv.getElementsByTagName("input");
		for (const input of i)
		{
			inputs.push(input);
		}
		
		let input = inputs.shift();
		if (input.checked)
		{
			Sailing.bringToFront("register");
			Register.callback();
		}
		
		input = inputs.shift();
		if (input.checked)
		{
			Register.nameInput.validated = true;
			Register.callback();
			return;
		}

		input = inputs.shift();
		if (input.checked)
		{
			Register.nameInput.validated = true;
			Register.callback();
			return;
		}

		let names = Register.names;		
		while ((input = inputs.shift()))
		{
			let name = names.shift();
			if (input.checked)
			{
				Register.nameInput.value = name;
				Register.nameInput.validated = true;
				Register.callback();
			}
		}
	}
	
	// Given the name of the sailor, this function returns a small list of likely names
	static listSimilarNames(sailorName)
	{
		let size = 7;
		let sizeMinus1 = size - 1;
		let a = [];
		let needle = Misc.essence(sailorName).substr(1);
		for (const key in Who.sailors)
		{
			// let perc = Misc.similarText(key.substr(1), needle, true);
			let perc = Misc.findDistance(key.substr(1), needle, true);
			if (perc < 60)
			{
				if (a.length < size)
				{
					a.push([perc, key]);
					a.sort((x, y) =>
					{
						return(Math.round(x[0] - y[0]));
					});
				}
				else if (perc < a[sizeMinus1][0])
				{
					a[sizeMinus1] = [perc, key];
					a.sort((x, y) =>
					{
						return(Math.round(x[0] - y[0]));
					});
				}
			}
		}
		let names = [];
		for (const item of a)
		{
			names.push(Who.sailors[item[1]]);
		}
		return(names);
	}
}
