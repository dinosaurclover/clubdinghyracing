/* global Sailing */
/* global What */
/* global Auth */
/* global Agree */
/* global AgreeDuty */

class What
{
	static className;
	static sailNumber;
	static crewName;
	static extraCrewName;
	static portsmouthNumber;
	
	static pickBoat(evt)
	{
		let conn = new HttpURLConnection();
		conn.setFailureFunction((conn) =>
		{
			Sailing.setError("who", conn.object.errorMessage);
		});
		conn.setSuccessFunction((conn) => 
		{
			What.display(conn.object.regs);
		});
		let task = {};
		task.helmName = Who.helmName; 
		conn.transmit("command=listregs&jsonencodedtask=" + encodeURIComponent(JSON.stringify(task)));
	}
	
	static display(regs)
	{
		Sailing.bringToFront("what");
		let div = document.getElementById("what");
		
		let headerDiv = div.children[0];
		let span = headerDiv.getElementsByTagName("span")[0];
		span.innerHTML = "";

		let contentDiv = div.children[1];
		contentDiv.innerHTML = "";
		contentDiv.style.textAlign = "center";
		
		let h2 = document.createElement("h2");
		contentDiv.appendChild(h2);
		h2.innerHTML = Who.helmName;
		
		let p = document.createElement("p");
		contentDiv.appendChild(p);
		if (Auth.type === "duty")
		{
			p.innerHTML = "If you wish to claim <b>Average Points</b> please click the boat you would have raced while signed on today.";
		}
		else
		{
			p.innerHTML = "Please click the boat you wish to sail today.";
		}

		if (Auth.type === "duty")
		{
			let button = document.createElement("button");
			contentDiv.appendChild(button);
			button.setAttribute("class", "regButton");
			button.innerHTML = "No boat. I'm doing a duty.<br>No claim for average points";
			contentDiv.appendChild(document.createElement("br"));
			button.addEventListener("click", (evt) =>
			{
				What.className = false;
				Agree.init("what");
			});
		}

		let count = 0;
		for (const reg of regs)
		{
			let button = document.createElement("button");
			contentDiv.appendChild(button);
			button.setAttribute("class", "regButton");
			button.innerHTML = reg.className + " - " + reg.sailNumber;
			if (reg.crewName)
			{
				button.innerHTML += "<br>Crew: " + reg.crewName;
			}
			if (reg.extraCrewName)
			{
				button.innerHTML += "<br>Crew: " + reg.extraCrewName;
			}
			if ((!reg.crewName) && (!reg.extraCrewName))
			{
				button.innerHTML += "<br>Crew: None (Single-handed)";
			}
			contentDiv.appendChild(document.createElement("br"));
			count ++;
			button.addEventListener("click", (evt) =>
			{
				What.className = reg.className;
				What.sailNumber = reg.sailNumber;
				What.crewName = reg.crewName;
				What.extraCrewName = reg.extraCrewName;
				What.portsmouthNumber = reg.portsmouthNumber;
				Agree.init("what");
			});
			button.reg = reg;
			button.addEventListener("contextmenu", (evt) =>
			{
				document.getElementById("agreedelete").checked = false;
				What.button = button;
				evt.stopPropagation();
				evt.preventDefault();
				Sailing.bringToFront("delete");
				let div = document.getElementById("deletedescription");
				
				div.innerHTML = reg.className + " - " + reg.sailNumber;
				if (reg.crewName)
				{
					div.innerHTML += "<br>" + reg.crewName;
				}
				if (reg.extraCrewName)
				{
					div.innerHTML += "<br>" + reg.extraCrewName;
				}
			});
		}
		
		if (count > 1)
		{
			let p = document.createElement("p");
			contentDiv.appendChild(p);
			p.innerHTML = "Right-click (or long press) to remove old registrations you don't need.";
		}
		
		p = document.createElement("p");
		contentDiv.appendChild(p);
		p.innerHTML = "Not listed above? Click the button below to register a new boat, different crew or different sail number.";

		let button = document.createElement("button");
		contentDiv.appendChild(button);
		button.setAttribute("class", "regButton");
		button.innerHTML = "Make New Registration";
		button.addEventListener("click", Register.display);
		Sailing.resize();
	}

	static deleteAcknowledge()
	{
		if (!document.getElementById("agreedelete").checked)
		{
			Sailing.bringToFront("what");
			return;
		}
		let conn = new HttpURLConnection();
		conn.setFailureFunction((conn) =>
		{
			Sailing.setError("delete", conn.object.errorMessage);
		});
		conn.setSuccessFunction((conn) => 
		{
			let parent = What.button.parentElement;
			if (parent)
			{
				parent.removeChild(What.button);
			}
			Sailing.bringToFront("what");
		});
		let task = {};
		task.regKey = What.button.reg.regKey; 
		conn.transmit("command=deletereg&jsonencodedtask=" + encodeURIComponent(JSON.stringify(task)));
		
	}
}