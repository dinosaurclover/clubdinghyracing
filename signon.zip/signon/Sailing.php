<?php

/*
 * Thinking out loud
 * Module could make log every transaction to a shared log file.
 * Writing to the file woult take place within a BEGIN COMMIT sequence.
 * If the file write fails a rollbck occurs and the sequence fails.
 * The file write would take place just before the COMMIT
 * When the file grows to a specified size it is archived and a new file is started.
 * File size of about 20 or 30 MByte might be good.
 * A traditonal backup system could back up these files in the normal way.
 * A 2 GByte would be backed up with about 60 files.
 * System will need a way of checking whether the files are good
 * Each file will have a small header that specifies the total size of all the previous files.
 * A quick check would list the files and sum the size of all the files except the latest one.
 * The header could contain a checksum of the previous file.
 * A more rigorous check would read all the files and look for checksum disagreements
 * Users of the module will be advised to pass arrays of sql statements.
 */

function registerObjectCompare($a, $b)
{
	return($b[0] - $a[0]);
}


class Sailing
{


	private $db;
	function __construct()
	{
		// Will never happen unless debugging
		$this->dateYYYY_MM_DD = Misc::getFormValue("date", false);

		if (empty($this->dateYYYY_MM_DD))
		{
			$this->dateYYYY_MM_DD = date("Y-m-d");
		}

		// Update class table if required (don't force).
		ClassMine::update(false);

		$command = Misc::getFormValue("command", false);

		if (!$command)
		{
			// Send the page html, a challenge and the start up flags
			readfile("html.html");

			$object = new stdClass();

			if (function_exists("random_bytes"))
			{
				$object->challenge = bin2hex(random_bytes(48));
			}
			else
			{
				$a = array();
				for ($i = 0; $i < 40; $i++)
				{
					array_push($a, chr(mt_rand(0, 255)));
				}
				$object->challenge = bin2hex(implode("", $a));
			}

			if (($pin = Misc::getFormValue("pin", false)))
			{
				$object->flags = $pin;
			}
			else
			{
				$object->flags = Misc::getFormValue("flags", false);
			}

			echo("\n<script>\nvar mStartUpConfig=`" . json_encode($object) . "`;\n</script>");
			exit();
		}

		// N.B. No break. Functions are guaranteed to exit.
		switch ($command)
		{
			case "id": $this->id();
		}
		// Open a connection to the database
		$this->db = new Database();

		$command = Misc::getFormValue("command", false);

		// N.B. No break. Functions are guaranteed to exit.
		switch ($command)
		{
			case "listsignons": $this->listSignOns();
		}

		// Needs a valid password digest before going any further
		$this->authenticate();

		if (file_exists("Custom.php"))
		{
			new Custom($this->db);
		}

		// N.B. No break. Functions are guaranteed to exit.
		switch ($command)
		{
			case "requestdata": $this->requestData();
			case "upload": $this->upload();
			case "noop": $this->noop();
			case "listsailors": $this->listSailors();
			case "listsailorsbyname": $this->listSailorsByName();
			case "listregs": $this->listRegs();
			case "listclasses": $this->listClasses();
			case "listclassnames": $this->listClassNames();
			case "register": $this->register();
			case "deletereg": $this->deleteReg();
			case "addsignon": $this->addSignOn();
			case "ice": $this->ice();
		}

		Misc::errorExit("Invalid command " . $command);
	}

	private function cmp($a, $b)
	{
		return($b[0] - $a[0]);
	}

	private function id()
	{
		echo("{}");
		exit();
	}

	// client is requesting emergency contact details
	private function ice()
	{
		$task = Misc::getTask();

		$object = new stdClass();
		if (!empty($s = $task->helmName))
		{
			$key = $this->db->getSailorKeyBySailorName($s);
			$fmt = "SELECT sailorIceName, SUBSTR(sailorIceTelephone, -3) AS sailorIceTelephone FROM sailor WHERE sailorKey=" . $key . "";
			$cells = $this->db->querySingle($fmt, true);
			if (!empty($cells))
			{
				$object->helmIceName = $cells["sailorIceName"];
				$object->helmIceTelephone = $cells["sailorIceTelephone"];
			}
		}

		if (!empty($s = $task->crewName))
		{
			$key = $this->db->getSailorKeyBySailorName($s);
			$fmt = "SELECT sailorIceName, SUBSTR(sailorIceTelephone, -3) AS sailorIceTelephone FROM sailor WHERE sailorKey=" . $key . "";
			$cells = $this->db->querySingle($fmt, true);
			if (!empty($cells))
			{
				$object->crewIceName = $cells["sailorIceName"];
				$object->crewIceTelephone = $cells["sailorIceTelephone"];
			}
		}

		if (!empty($s = $task->extraCrewName))
		{
			$key = $this->db->getSailorKeyBySailorName($s);
			$fmt = "SELECT sailorIceName, SUBSTR(sailorIceTelephone, -3) AS sailorIceTelephone FROM sailor WHERE sailorKey=" . $key . "";
			$cells = $this->db->querySingle($fmt, true);
			if (!empty($cells))
			{
				$object->extraCrewIceName = $cells["sailorIceName"];
				$object->extraCrewIceTelephone = $cells["sailorIceTelephone"];
			}
		}
		echo(json_encode($object));
		exit();
	}

	private function listSignOns()
	{
		$task = Misc::getTask();
		if (empty($task) || empty($task->startUnixEpochSeconds))
		{
			Misc::errorExit("Missing parameter startUnixEpochSeconds");
		}
		if (empty($task) || empty($task->endUnixEpochSeconds))
		{
			Misc::errorExit("Missing parameter endUnixEpochSeconds");
		}
		if (empty($task) || empty($task->type))
		{
			Misc::errorExit("Missing parameter type");
		}

		$object = new stdClass();
		$object->signons = Misc::fetchSignOns($this->db, $task->startUnixEpochSeconds, $task->endUnixEpochSeconds, $task->type);

		echo(json_encode($object));
		exit();
	}

	private function addSignOn()
	{
		$task = Misc::getTask();

		if (empty($task))
		{
			Misc::errorExit("Missing parameter task");
		}


		$helmKey = $this->db->getSailorKeyBySailorName($task->helmName);
		if (empty($helmKey))
		{
			Misc::errorExit("Missing or invalid parameter helmName");
		}

		$regKey = 0;
		if (!empty($task->className))
		{
			$classKey = false;
			$sailEssence = "";
			$crewKey = 0;
			$extraCrewKey = 0;

			if (!($classKey = $this->db->getClassKeyByClassName($task->className)))
			{
				Misc::errorExit("Missing or invalid parameter className");
			}

			$portsmouthNumber = $task->portsmouthNumber;

			if (!empty($task->crewName))
			{
				if (!($crewKey = $this->db->getSailorKeyBySailorName($task->crewName)))
				{
					Misc::errorExit("Invalid parameter crewName");
				}
			}
			if (!empty($task->extraCrewName))
			{
				if (!($extraCrewKey = $this->db->getSailorKeyBySailorName($task->extraCrewName)))
				{
					Misc::errorExit("Invalid parameter extraCrewName");
				}
			}
			if (!empty($task->sailNumber))
			{
				$sailEssence = Misc::essence($task->sailNumber);
			}
			else
			{
				Misc::errorExit("Missing or invalid parameter sailNumber");
			}

			// The boat should be registered
			$fmt = "SELECT regKey FROM reg"
				. " WHERE regClassKey=" . $this->db->quote($classKey)
				. " AND regHelmKey=" . $helmKey
				. " AND regSailEssence like " . $this->db->quote($sailEssence);

			$s = ($crewKey != 0) ? " AND regCrewKey=" . $crewKey : " AND regCrewKey IS NULL";
			$fmt .= $s;

			$s = ($extraCrewKey != 0) ? " AND regExtraCrewKey=" . $extraCrewKey : " AND regExtraCrewKey IS NULL";
			$fmt .= $s;

			if (empty($regKey = $this->db->querySingle($fmt)))
			{
				Misc::errorExit("Missing or invalid registration");
			}
		}

		if ($task->type != "duty")
		{
			if (empty($regKey))
			{
				Misc::errorExit("Missing or invalid registration");
			}
		}

		$fmt = "INSERT INTO signon VALUES(NULL"
			. "," . $helmKey
			. "," . $this->db->quote($regKey)
			. "," . $this->db->quote($task->type)
			. ",NULL"
			. "," . time() . ")";

		$this->db->exec($fmt);

		echo("{}");
		exit();
	}

	// Given the name of the sailor, this function returns a small list of likely names
	private function test($sailorName)
	{
		// Might need to look up 3 names so get a list in ram
		if (empty($this->sailors))
		{
			$this->sailors = array();
			$fmt = "SELECT SUBSTR(sailorEssence, 2),sailorName FROM sailor";
			$result = $this->db->query($fmt);
			while ($cells = $result->fetchArray(SQLITE3_NUM))
			{
				$this->sailors[$cells[0]] = $cells[1];
			}
		}
		$size = 7;
		$sizeMinus1 = $size - 1;
		$a = array();
		$needle = substr(Misc::essence($sailorName), 1);
		$keys = array_keys($this->sailors);
		foreach($keys as $key)
		{
			similar_text($key, $needle, $perc);
			if ($perc > 50)
			{
				if (count($a) < $size)
				{
					array_push($a, array($perc, $key));
					usort($a, "registerObjectCompare");
				}
				else if ($perc > $a[$sizeMinus1][0])
				{
					$a[$sizeMinus1] = array($perc, $key);
					usort($a, "registerObjectCompare");
				}
			}
		}
		$names = array();
		foreach($a as $o)
		{
			array_push($names, $this->db->getSailorNameBySailorEssence("_" . $o[1]));
		}
		return($names);
	}

	private function register()
	{
		$task = Misc::getTask();
		if (empty($task) || empty($task->helmName))
		{
			Misc::errorExit("Missing parameter helmName ");
		}

		if (empty($task) || empty($task->className))
		{
			Misc::errorExit("Missing parameter className ");
		}

		if (empty($task) || empty($task->sailNumber))
		{
			Misc::errorExit("Missing parameter sailNumber");
		}

		$classKey = $this->db->getClassKeyByClassName($task->className);
		if (empty($classKey))
		{
			Misc::errorExit("Unrecognised class name " . $task->className);
		}

		$sailorName = $task->helmName;
		if (empty($helmKey = $this->db->getSailorKeyBySailorName($sailorName)))
		{
			$fmt = "INSERT INTO sailor(sailorName, sailorEssence,sailorUnixEpochSeconds) VALUES("
				. $this->db->quote($sailorName) . ","
				. $this->db->quote(Misc::essence($sailorName)) . ","
				. time() . ")";
			if ($this->db->exec($fmt) === false)
			{
				$this->db->appExit();
			}
			$helmKey = $this->db->lastInsertRowID();
		}

		$crewKey = null;
		$sailorName = $task->crewName;
		if ((!empty($sailorName)) && (empty($crewKey = $this->db->getSailorKeyBySailorName($sailorName))))
		{
			$fmt = "INSERT INTO sailor(sailorName, sailorEssence,sailorUnixEpochSeconds) VALUES("
				. $this->db->quote($sailorName) . ","
				. $this->db->quote(Misc::essence($sailorName)) . ","
				. time() . ")";
			if ($this->db->exec($fmt) === false)
			{
				$this->db->appExit();
			}
			$crewKey = $this->db->lastInsertRowID();
		}

		$extraCrewKey = null;
		$sailorName = $task->extraCrewName;
		if ((!empty($sailorName)) && (empty($extraCrewKey = $this->db->getSailorKeyBySailorName($sailorName))))
		{
			$fmt = "INSERT INTO sailor(sailorName, sailorEssence,sailorUnixEpochSeconds) VALUES("
				. $this->db->quote($sailorName) . ","
				. $this->db->quote(Misc::essence($sailorName)) . ","
				. time() . ")";
			if ($this->db->exec($fmt) === false)
			{
				$this->db->appExit();
			}
			$extraCrewKey = $this->db->lastInsertRowID();
		}

		$fmt = "SELECT regKey FROM reg"
			. " WHERE regClassKey=" . $this->db->quote($classKey)
			. " AND regHelmKey=" . $helmKey
			. " AND regSailEssence like" . $this->db->quote(Misc::essence($task->sailNumber));

		$s = ($crewKey != 0) ? " AND regCrewKey=" . $crewKey : " AND regCrewKey IS NULL";
		$fmt .= $s;

		$s = ($extraCrewKey != 0) ? " AND regExtraCrewKey=" . $extraCrewKey : " AND regExtraCrewKey IS NULL";
		$fmt .= $s;

		$crewLine = empty($crewKey) ? "NULL" : $crewKey;
		$extraCrewLine = empty($extraCrewKey) ? "NULL" : $extraCrewKey;

		if (empty($regKey = $this->db->querySingle($fmt)))
		{
			$fmt = "INSERT INTO reg VALUES(NULL,"
				. $this->db->quote($classKey) . ","
				. $this->db->quote($task->sailNumber) . ","
				. $this->db->quote(Misc::essence($task->sailNumber)) . ","
				. $helmKey . ","
				. $crewLine . ","
				. $extraCrewLine . ","
				. "NULL,"
				. $this->db->quote(date("Y-m-d")) . ")";
			if ($this->db->exec($fmt) === false)
			{
				$this->db->appExit();
			}
			$regKey = $this->db->lastInsertRowID();
		}
		else
		{
			$fmt = "UPDATE reg SET regHidden=NULL, regYYYYMMDD='" . date("Y-m-d") . "' WHERE regKey=" . $regKey;
			if ($this->db->exec($fmt) === false)
			{
				$this->db->appExit();
			}
		}

		// It's likely that the user will want to sign on with this boat
		// Return useful stuff
		$fmt = "SELECT * FROM viewreg WHERE regKey=" . $this->db->lastInsertRowId();
		$cells = $this->db->querySingle($fmt, true);

		$object = new stdClass();
		$object->reg = $cells;

		if (!empty($helmKey))
		{
			$fmt = "UPDATE sailor SET sailorHidden=NULL WHERE sailorKey=" . $helmKey;
			$this->db->exec($fmt);
		}

		if (!empty($crewKey))
		{
			$fmt = "UPDATE sailor SET sailorHidden=NULL WHERE sailorKey=" . $crewKey;
			$this->db->exec($fmt);
		}

		if (!empty($extraCrewKey))
		{
			$fmt = "UPDATE sailor SET sailorHidden=NULL WHERE sailorKey=" . $extraCrewKey;
			$this->db->exec($fmt);
		}

		$object = new stdClass();
		echo(json_encode($object));
		exit();
	}

	private function deleteReg()
	{
		$task = Misc::getTask();
		if (empty($task) || empty($task->regKey))
		{
			Misc::errorExit("Missing parameter regKey ");
		}
		$fmt = "UPDATE reg SET regHidden=1 WHERE regKey=" . $task->regKey;
		$this->db->exec($fmt);

		echo("{}");
		exit();
	}

	private function listRegs()
	{
		$task = Misc::getTask();


		if (empty($task) || empty($task->helmName))
		{
			Misc::errorExit("Missing parameter helmName ");
		}

		$bits = explode("-", $this->dateYYYY_MM_DD);
		$t = mktime(12, 0, 0, intval($bits[1]), intval($bits[2]), intval($bits[0]));
		$t -= (5 * 366 * 24 * 60 * 60);
		$date = date("Y-m-d", $t);

		$object = new stdClass();
		$object->regs = array();

		$helmKey = $this->db->getSailorKeyBySailorName($task->helmName);

		if (!empty($helmKey))
		{
			$list = "className,regSailNumber,helmName,crewName,extraCrewName";
			$fmt = "SELECT * FROM viewreg WHERE regKey IN"
				. "(SELECT MAX(regKey)"
				. " FROM viewreg"
				. " WHERE regHelmKey=" . $helmKey
				. " AND regHidden IS NULL"
				. " GROUP BY " . $list . ")"
				. " ORDER BY regYYYYMMDD DESC";
//				. " ORDER BY className COLLATE NOCASE, (0 + regSailNumber)";
			$result = $this->db->query($fmt);
			while ($cells = $result->fetchArray(SQLITE3_ASSOC))
			{
				array_push($object->regs, $cells);
			}
		}
		$s = json_encode($object);
		echo($s);
		exit();
	}

	private function listClassNames()
	{
		// Load the boat class list
		$classNames = array();
		$fmt = "SELECT className FROM class ORDER BY className COLLATE NOCASE";
		$result = $this->db->query($fmt);
		while ($cells = $result->fetchArray(SQLITE3_ASSOC))
		{
			if (($s = $this->checkCells($cells)))
			{
				Misc::errorExit("classes", $s);
			}
			array_push($classNames, $cells["className"]);
		}

		$object = new stdClass();
		$object->classNames = $classNames;
		$s = json_encode($object);
		echo($s);
		exit();
	}

	private function listClasses()
	{
		$object = new stdClass();
		$object->classes = array();
		$object->classNames = array();


		$fmt = "SELECT * FROM class ORDER BY className COLLATE NOCASE";
		$result = $this->db->query($fmt);
		while ($entry = $result->fetchArray(SQLITE3_ASSOC))
		{
			if (($s = $this->checkCells($entry)))
			{
				Misc::errorExit("classes", $s);
			}
			$object->classes[$entry['classKey']] = $entry;
			array_push($object->classNames, $entry["className"]);
		}

		$s = json_encode($object);
		echo($s);
		exit();
	}

	private function listSailors()
	{
		$bits = explode("-", $this->dateYYYY_MM_DD);
		$t = mktime(12, 0, 0, intval($bits[1]), intval($bits[2]), intval($bits[0]));
		$t -= (500 * 24 * 60 * 60);
		$date = date("Y-m-d", $t);

		$object = new stdClass();
		$object->sailors = array();

		$fmt = "SELECT * FROM sailor WHERE sailorHidden IS NULL ORDER BY sailorEssence";
		$result = $this->db->query($fmt);
		while ($cells = $result->fetchArray(SQLITE3_ASSOC))
		{
			$sailorEssence = $cells["sailorEssence"];
			if (!empty($sailorEssence))
			{
				$c = strtoupper(substr($sailorEssence, 1, 1));
				if (empty($object->sailors[$c]))
				{
					$object->sailors[$c] = array();
				}
				$object->sailors[$c][$sailorEssence] = $cells["sailorName"];
			}
		}

		$s = json_encode($object);
		echo($s);
		exit();
	}

	private function listSailorsByName()
	{
		$bits = explode("-", $this->dateYYYY_MM_DD);
		$t = mktime(12, 0, 0, intval($bits[1]), intval($bits[2]), intval($bits[0]));
		$t -= (500 * 24 * 60 * 60);
		$date = date("Y-m-d", $t);

		$object = new stdClass();
		$object->sailors = array();

		$fmt = "SELECT * FROM sailor WHERE sailorHidden IS NULL ORDER BY sailorEssence";
		$result = $this->db->query($fmt);
		while ($cells = $result->fetchArray(SQLITE3_ASSOC))
		{
			$sailorEssence = $cells["sailorEssence"];
			if (!empty($sailorEssence))
			{
				$object->sailors[$sailorEssence] = $cells["sailorName"];
			}
		}

		$s = json_encode($object);
		echo($s);
		exit();
	}

	private function noop()
	{
		echo("{}");
		exit();
	}

	private function checkCells($cells)
	{
		foreach ($cells as $cell)
		{
			if (!empty($cell))
			{
				if (!mb_check_encoding("" . $cell, 'UTF-8'))
				{
					return($cell);
				}
			}
		}
		return(false);
	}

	private function loadClasses()
	{
		// Load the boat class list
		$classes = array();
		$fmt = "SELECT * FROM class ORDER BY className COLLATE NOCASE";
		$result = $this->db->query($fmt);
		while ($entry = $result->fetchArray(SQLITE3_ASSOC))
		{
			if (($s = $this->checkCells($entry)))
			{
				Misc::errorExit("classes", $s);
			}
			$classes[$entry['classKey']] = $entry;
		}
		return($classes);
	}

	private function loadIces()
	{
		$ices = array();
		$fmt = "SELECT sailorKey, iceName, SUBSTR(iceTelephone, -3) AS iceTelephone FROM ice";
		$result = $this->db->query($fmt);

		while ($cells = $result->fetchArray(SQLITE3_ASSOC))
		{
			$ices[$cells["sailorKey"]] = new stdClass();
			$ices[$cells["sailorKey"]]->iceName = $cells["iceName"];
			$ices[$cells["sailorKey"]]->iceTelephone = $cells["iceTelephone"];
		}
		return($ices);
	}

// Compile a list from the guests table
// Guests are valid for 8 days
	private function loadGuests()
	{
		//$bits = explode("-", $this->dateYYYY_MM_DD);
		//$t = mktime(12, 0, 0, intval($bits[1]), intval($bits[2]), intval($bits[0]));

		if (empty($this->signOns))
		{
			$this->signOns = $this->loadSignOns();
		}

		$guests = array();

		//$t -= (9 * 24 * 60 * 60);
		//$date = date("Y-m-d", $t);

		$fmt = "SELECT * FROM guests";
		$result = $this->db->query($fmt);

		while ($cells = $result->fetchArray(SQLITE3_ASSOC))
		{
			$guests[$cells["guestKey"]] = new stdClass();
			$guests[$cells["guestKey"]]->name = $cells["guestName"];
			$signon = $this->signOns[$cells["guestKey"]];
			if (!empty($signon))
			{
				$guests[$cells["guestKey"]]->classes = $signon->classes;
				$guests[$cells["guestKey"]]->crewKeys = $signon->crewKeys;
			}
		}

		return($guests);
	}

	private function loadMembers()
	{
		if (empty($this->signOns))
		{
			$this->signOns = $this->loadSignOns();
		}

		$members = array();

		$fmt = "SELECT * FROM members";
		$result = $this->db->query($fmt);

		while ($cells = $result->fetchArray(SQLITE3_ASSOC))
		{
			$members[$cells["memberKey"]] = new stdClass();
			$members[$cells["memberKey"]]->name = $cells["memberName"];
			$signon = $this->signOns[$cells["memberKey"]];
			if (!empty($signon))
			{
				$members[$cells["memberKey"]]->classes = $signon->classes;
				$members[$cells["memberKey"]]->crewKeys = $signon->crewKeys;
			}
		}

		return($members);
	}

// This is never transmitted.
// It's used to add history to the members array and the guests array
	private function loadSignOns()
	{
		$signOns = array();

		$fmt = "SELECT helmName,className,sailNumber,crewNames,dateYYYYMMDD"
			. " FROM signons"
			. " WHERE NOT type LIKE 'duty'"
			. " AND className IS NOT NULL"
			. "	AND dateYYYYMMDD<" . $this->db->quote($this->dateYYYY_MM_DD)
			. " ORDER BY dateYYYYMMDD DESC";
		$result = $this->db->query($fmt);

		while ($cells = $result->fetchArray(SQLITE3_ASSOC))
		{
			$sailorKey = Misc::essence($cells["helmName"]);
			$classKey = Misc::essence($cells["className"]);
			if (empty($signOns[$sailorKey]))
			{
				$signOns[$sailorKey] = new stdClass();
			}
			if (empty($signOns[$sailorKey]->classes))
			{
				$signOns[$sailorKey]->classes = array();
			}

			if ($sailorKey === "_gregorycox")
			{
				$this->name = "hello";
			}

			// The query is sorted by date
			// if it exists in the sailors array of boats it can be ignored 
			if (empty($signOns[$sailorKey]->classes[$classKey]))
			{
				$signOns[$sailorKey]->classes[$classKey] = new stdClass();
				$signOns[$sailorKey]->classes[$classKey]->classKey = $classKey;
				$signOns[$sailorKey]->classes[$classKey]->dateYYYYMMDD = $cells["dateYYYYMMDD"];
				$signOns[$sailorKey]->classes[$classKey]->sailNumber = $cells["sailNumber"];
				if (!empty($cells["crewNames"]))
				{
					$signOns[$sailorKey]->classes[$classKey]->crewKeys = array();
					$bits = explode(",", $cells["crewNames"]);
					foreach ($bits as $crewName)
					{
						$crewKey = Misc::essence($crewName);
						// In the past, it has been possible to specify the helm as the crew.
						if (!empty($crewKey) && ($crewKey != $sailorKey))
						{
							if (empty($signOns[$sailorKey]->crewKeys))
							{
								$signOns[$sailorKey]->crewKeys = array();
							}
							array_push($signOns[$sailorKey]->classes[$classKey]->crewKeys, $crewKey);
							$signOns[$sailorKey]->crewKeys[$crewKey] = true;
						}
					}
				}
			}
			else
			{
				$bits = explode(",", $cells["crewNames"]);
				foreach ($bits as $crewName)
				{
					$crewKey = Misc::essence($crewName);
					// In the past, it has been possible to specify the helm as the crew.
					if (!empty($crewKey) && ($crewKey != $sailorKey))
					{
						if (empty($signOns[$sailorKey]->crewKeys))
						{
							$signOns[$sailorKey]->crewKeys = array();
						}
						$signOns[$sailorKey]->crewKeys[$crewKey] = true;
					}
				}
			}
		}
		$keys = array_keys($signOns);
		foreach ($keys as $key)
		{
			$classes = array();
			foreach ($signOns[$key]->classes as $class)
			{
				array_push($classes, $class);
			}

			// Put classes in last sailed order - most recnt first
			usort($classes, $this->dateCompare);
			$signOns[$key]->classes = [];
			foreach ($classes as $class)
			{
				array_push($signOns[$key]->classes, $class);
			}
			$signOns[$key]->crewKeys = array_keys($signOns[$key]->crewKeys);
		}
		return($signOns);
	}

	private function loadCurrentSignOns()
	{
		$signOns = array();

		$fmt = "SELECT *"
			. " FROM signons"
			. " WHERE dateYYYYMMDD=" . $this->db->quote($this->dateYYYY_MM_DD)
			. " ORDER BY type, className, (0 + sailNumber), helmName";
		$result = $this->db->query($fmt);

		// This is a bit lengthy but
		// It formats the current signon identically to the historic signons
		while ($cells = $result->fetchArray(SQLITE3_ASSOC))
		{
			$o = new stdClass();
			$o->helmKey = Misc::essence($cells["helmName"]);
			if (!empty($cells["className"]))
			{
				$o->classKey = Misc::essence($cells["className"]);
			}
			$o->dateYYYYMMDD = $cells["dateYYYYMMDD"];
			if (!empty($cells["portsmouthNumber"]))
			{
				$o->portsmouthNumber = $cells["portsmouthNumber"];
			}
			if (!empty($cells["sailNumber"]))
			{
				$o->sailNumber = $cells["sailNumber"];
			}
			$o->crewKeys = array();
			if (!empty($cells["type"]))
			{
				$o->type = $cells["type"];
			}
			if (!empty($cells[crewNames]))
			{
				$crewNames = explode(",", $cells[crewNames]);
				foreach ($crewNames as $crewName)
				{
					array_push($o->crewKeys, Misc::essence($crewName));
				}
			}
			array_push($signOns, $o);
		}
		return($signOns);
	}

	private function dateCompare($a, $b)
	{
		return(strcmp($b->dateYYYYMMDD, $a->dateYYYYMMDD));
	}

	private function updateCache($name, $encodedValue)
	{
		$value = json_encode($encodedValue);
		$checkSum = hash("sha256", $value);
		if (empty($this->cache[$name]))
		{
			$fmt = "INSERT INTO signonCache VALUES("
				. $this->db->quote($name) . ","
				. $this->db->quote($value) . ","
				. $this->db->quote($this->dateYYYY_MM_DD) . ","
				. $this->db->quote($checkSum) . ")";
		}
		else
		{
			$fmt = "UPDATE signonCache SET value=" . $this->db->quote($value)
				. ",dateYYYYMMDD=" . $this->db->quote($this->dateYYYY_MM_DD)
				. ",checkSum=" . $this->db->quote($checkSum)
				. " WHERE name=" . $this->db->quote($name);
		}
		$this->db->exec($fmt);
		return($checkSum);
	}

	// Send everything needed to populate the page drop down menus
	// and auto complete as user changes inputs
	// Can easily be 100K or so.
	// A system of checksums is used to avoid resending the same data.
	private function createData()
	{
		$this->task = Misc::getTask();
		if (empty($this->task))
		{
			$this->task = new stdClass();
			$this->task->checkSums = new stdClass();
		}

		$this->object = new stdClass();
		$this->object->checkSums = new stdClass();

		// Items that we don't expect to change since yesterday are cached
		$this->cache = array();
		$fmt = "SELECT name, dateYYYYMMDD, checkSum FROM signonCache";
		$result = $this->db->query($fmt);
		while ($cells = $result->fetchArray(SQLITE3_ASSOC))
		{
			$this->cache[$cells["name"]] = $cells;
		}

		// List of classes --------------------------------------------------------
		$this->createClasses();

		// List of members --------------------------------------------------------
		$this->createMembers();

		// List of guests --------------------------------------------------------
		$this->createGuests();

		// List of ices --------------------------------------------------------
		// Regard this list as not requiring frequent update
		$this->createIces();

		$this->object->currentSignOns = $this->loadCurrentSignOns();
	}

	private function requestData()
	{
		$this->createData();
		$s = json_encode($this->object);
		echo($s);
		exit();
	}

	private function createClasses()
	{
		$name = "classes";
		if ((empty($this->cache[$name])) || ($this->cache[$name]["dateYYYYMMDD"] != $this->dateYYYY_MM_DD))
		{
			// Redo the class list from the database
			$checkSum = $this->updateCache($name, $this->loadClasses());
		}
		else
		{
			$checkSum = $this->cache[$name]["checkSum"];
		}

		if ((empty($this->task->checkSums->classes)) || ($this->task->checkSums->classes !== $checkSum))
		{
			$fmt = "SELECT value FROM signonCache WHERE name='" . $name . "'";
			$encoded = $this->db->querySingle($fmt);
			$this->object->classes = json_decode($encoded);
		}
		$this->object->checkSums->classes = $checkSum;
	}

	private function createMembers()
	{
		$name = "members";
		if ((empty($this->cache[$name])) || ($this->cache[$name]["dateYYYYMMDD"] != $this->dateYYYY_MM_DD))
		{
			// Redo the members list from the database
			$checkSum = $this->updateCache($name, $this->loadMembers());
		}
		else
		{
			$checkSum = $this->cache[$name]["checkSum"];
		}

		if ((empty($this->task->checkSums->members)) || ($this->task->checkSums->members !== $checkSum))
		{
			$fmt = "SELECT value FROM signonCache WHERE name='" . $name . "'";
			$encoded = $this->db->querySingle($fmt);
			$this->object->members = json_decode($encoded);
		}
		$this->object->checkSums->members = $checkSum;
	}

	private function createGuests()
	{
		$name = "guests";
		if ((empty($this->cache[$name])) || ($this->cache[$name]["dateYYYYMMDD"] != $this->dateYYYY_MM_DD))
		{
			// Redo the guest list from the database
			$checkSum = $this->updateCache($name, $this->loadGuests());
		}
		else
		{
			$checkSum = $this->cache[$name]["checkSum"];
		}

		if ((empty($this->task->checkSums->guests)) || ($this->task->checkSums->guests !== $checkSum))
		{
			$fmt = "SELECT value FROM signonCache WHERE name='" . $name . "'";
			$encoded = $this->db->querySingle($fmt);
			$this->object->guests = json_decode($encoded);
		}
		$this->object->checkSums->guests = $checkSum;
	}

	private function createIces()
	{
		$name = "ices";
		if ((empty($this->cache[$name])) || ($this->cache[$name]["dateYYYYMMDD"] != $this->dateYYYY_MM_DD))
		{
			// Redo the ice list from the database
			$checkSum = $this->updateCache($name, $this->loadIces());
		}
		else
		{
			$checkSum = $this->cache[$name]["checkSum"];
		}

		if ((empty($this->task->checkSums->ices)) || ($this->task->checkSums->ices !== $checkSum))
		{
			$fmt = "SELECT value FROM signonCache WHERE name='" . $name . "'";
			$encoded = $this->db->querySingle($fmt);
			$this->object->ices = json_decode($encoded);
		}
		$this->object->checkSums->ices = $checkSum;
	}


// Add helmName and other details to the list
// Note that boat gets the py number in effect on the day;
	private function upload()
	{
		$jsonencodedtask = Misc::getFormValue("jsonencodedtask", false);
		$task = json_decode($jsonencodedtask);

		$sailors = $task->sailors;
		if (empty($sailors))
		{
			Misc::errorExit("No member name specified");
		}

		// Office laptop is able to supply names typed by the operator
		// Check spelling of name
		// If necessary, add name to system guest list
		foreach($task->sailors as $sailor)
		{
			$sailorKey = Misc::essence($sailor->name);
			$fmt = "SELECT memberName FROM members WHERE memberKey=" . $this->db->quote($sailorKey);
			$sailorName = $this->db->querySingle($fmt);
			if (empty($sailorName))
			{
				//$bits = explode("-", $this->dateYYYY_MM_DD);
				//$t = mktime(12, 0, 0, intval($bits[1]), intval($bits[2]), intval($bits[0]));
				//$t -= (9 * 24 * 60 * 60);
				//$date = date("Y-m-d", $t);
				$fmt = "SELECT guestName FROM guests"
					. " WHERE guestKey=" . $this->db->quote($sailorKey);
				$sailorName = $this->db->querySingle($fmt);
				if (empty($sailorName))
				{
					// $statements = array();
					$fmt = "INSERT INTO guests VALUES(" . time() . "," . $this->db->quote($sailor->name) . "," . $this->db->quote($sailorKey) . ")";
					$this->db->exec($fmt);
				}
				else
				{
					$task->sailorKey = $sailorName; 
				}
			}
		}

		// Update the ice table if necessary
		foreach($task->sailors as $sailor)
		{
			if ((!empty($sailor->iceName)) || (!empty($sailor->iceTelephone)))
			{
				$sailorKey = Misc::essence($sailor->name);
				$where = "WHERE sailorKey=" . $this->db->quote($sailorKey);
				$result = $this->db->query("SELECT * FROM ice " . $where);
				if ($cells = $result->fetchArray(SQLITE3_ASSOC))
				{
					if ((!empty($sailor->iceName) && ($cells["iceName"] !== $sailor->iceName)))
					{
						$fmt = "UPDATE ice SET iceName=" . $this->db->quote($sailor->iceName) . $where;
						$this->db->exec($fmt);
					}
					if ((!empty($sailor->iceTelephone) && ($cells["iceTelephone"] !== $sailor->iceTelephone)))
					{
						$fmt = "UPDATE ice SET iceTelephone=" . $this->db->quote($sailor->iceTelephone) . $where;
						$this->db->exec($fmt);
					}
				}
				else
				{
					$fmt = "INSERT INTO ice VALUES("
						. $this->db->quote($sailorKey) . ","
						. $this->db->quote($sailor->sailorName) . ","
						. $this->db->quote($sailor->iceName) . ","
						. $this->db->quote($sailor->iceTelephone) . ")";
					$this->db->exec($fmt);
				}
			}
		}


		$helm = array_shift($task->sailors);
		$helmName = $helm->name;
		$a = array();
		foreach($task->sailors as $sailor)
		{
			array_push($a, $sailor->name);
		}
		$crewNames = implode(",", $a);

		$where = " WHERE helmName LIKE " . $this->db->quote($helmName)
				. " AND dateYYYYMMDD='" . $this->dateYYYY_MM_DD . "'";

		if ((empty($task->className)) && ($task->type !== "duty"))
		{
			$fmt = "DELETE FROM signons" .$where;
		}
		else
		{
			$fmt = "SELECT * FROM signons" . $where;
			if (!empty($this->db->querySingle($fmt)))
			{
				// Helm has already signed on today
				$fmt = "UPDATE signons SET"
						. " className=" . $this->db->quote($task->className)
						. ",sailNumber=" . $this->db->quote($task->sailNumber)
						. ",crewNames=" . $this->db->quote($crewNames)
						. ",type=" . $this->db->quote($task->type)
						. $where;
			}
			else
			{
				$fmt = "INSERT INTO signons VALUES"
						. "(" . $this->db->quote($helmName)
						. "," . $this->db->quote($this->dateYYYY_MM_DD)
						. "," . $this->db->quote($task->className)
						. "," . $this->db->quote($task->portsmouthNumber)
						. "," . $this->db->quote($task->sailNumber)
						. "," . $this->db->quote($crewNames)
						. "," . $this->db->quote($task->type)
						. ")";
				
			}
		}
		$this->db->exec($fmt);



		$object = $this->createData();

		echo(json_encode($object));
		exit();
	}

	private function getEnv($key)
	{
		$s = $_SERVER[$key];
		if (!empty($s)) return($s);
		return(getenv($key));
	}

// If we get serious about security we need something better than this.
	private function authenticate()
	{
		$hostName = $this->getEnv("SERVER_NAME");
		$ipAddress = $this->getEnv("HTTP_X_FORWARDED_FOR");
		if (empty($ipAddress))
		{
			$ipAddress = $this->getEnv("REMOTE_ADDR");
		}

		// Check to see if user has supplied the password
		$clientDigest = $this->getEnv("HTTP_DIGEST");
		if (!empty($clientDigest))
		{
			// User has supplied password. Browser has calculated digest
			$challenge = $this->getEnv("HTTP_CHALLENGE");

			$serverPass = $this->db->getValue("signonPassword");

			$serverDigest = hash("sha256", "signon" . $serverPass . $challenge . $serverPass . "signon");

			if ($serverDigest !== $clientDigest)
			{
				$serverPass = substr($serverPass, 0, 4);
				$serverDigest = hash("sha256", "signon" . $serverPass . $challenge . $serverPass . "signon");

				if ($serverDigest !== $clientDigest)
				{
					sleep(2);
					Misc::errorExit("Incorrect Password");
				}
			}
			// Issue a token for subsequent connections
			$header = new stdClass();
			$header->alg = "sha256";
			$header->type = "JWT";
			$header = base64_encode(json_encode($header));

			$payload = new stdClass();
			$payload->time = time();
			$payload->hostName = $hostName;
			$payload->ipAddress = $ipAddress;
			$payload = base64_encode(json_encode($payload));
			$signature = base64_encode(hash("sha256", $header . "." . $payload . ".decade"));

			header("token: " . $header . "." . $payload . "." . $signature);
			return;
		}

		// Check to see if client has supplied a valid token
		$token = $this->getEnv("HTTP_TOKEN");
		if (!empty($token))
		{
			// Client has supplied token
			$bits = explode(".", $token);
			if (count($bits) == 3)
			{
				for ($i = 0; $i < 3; $i++)
				{
					while (count($words = explode(" ", $bits[$i])) > 1)
					{
						$bits[$i] = implode("", $words);
					}
				}
				$sha256 = base64_encode(hash("sha256", $bits[0] . "." . $bits[1] . ".decade"));
				if ($sha256 == $bits[2])
				{
					$payload = json_decode(base64_decode($bits[1]));
					if (time() < $payload->time + (30 * 24 * 60 * 60))
					{
						if (($ipAddress == $payload->ipAddress) &&
							($hostName == $payload->hostName))
						{
							// Token is good.
							return;
						}
					}
				}
			}
		}
		sleep(2);
		Misc::errorExit("Server has requested you to log in again.");
	}
}
