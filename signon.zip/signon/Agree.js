
class Agree
{
	static fromScreen = "what";
	
	static previous()
	{
		Sailing.bringToFront(Agree.fromScreen);
	}
	
	static init(fromScreen)
	{
		Agree.fromScreen = fromScreen;
		
		let task = {};
		task.helmName = Who.helmName;
		task.crewName = What.crewName;
		task.extraCrewName = What.extraCrewName;

		let conn = new HttpURLConnection();
		conn.setFailureFunction((conn) =>
		{
			Sailing.setError("agree", conn.object.errorMessage);
		});
		conn.setSuccessFunction((conn) =>
		{
			Agree.display(conn.object);
		});
		conn.transmit("command=ice&jsonencodedtask=" + encodeURIComponent(JSON.stringify(task)));

	}

	static display(ice)
	{
		let paragraphs = document.getElementsByClassName("agreeIce");
		
		document.getElementById("agreeinsurance").checked = false;
		document.getElementById("agreerules").checked = false;
		document.getElementById("agreedoingduty").checked = false;
		
		if (Auth.type === "duty")
		{
			document.getElementById("agreedutystuff").style.display = "block";
			document.getElementById("agreesailingstuff").style.display = "none";
		}
		else
		{
			document.getElementById("agreedutystuff").style.display = "none";
			document.getElementById("agreesailingstuff").style.display = "block";
		}

		let div = document.getElementById("agreevessel");
		div.innerHTML = "";
		
		let h2 = document.createElement("h2");
		div.appendChild(h2);
		h2.innerHTML = Who.helmName;
		
		let paragraph = paragraphs[0];
		if (paragraph)
		{
			paragraph.style.display = "block";
			let spans = paragraph.getElementsByTagName("span");
			spans[0].innerHTML = Who.helmName;
			if (ice.helmIceName)
			{
				spans[1].innerHTML = "In emergency contact " + ice.helmIceName;
			}
			else
			{
					spans[1].innerHTML = "No ICE name for this sailor.";
			}
			if (ice.helmIceTelephone)
			{
				spans[2].innerHTML = "Telephone ********" + ice.helmIceTelephone;
			}
			else
			{
					spans[2].innerHTML = "No ICE telephone for this sailor.";
			}
		}
		
		if (!What.className)
		{
			Sailing.bringToFront("agree");
			return;
		}
		
		let table = document.createElement("table");
		div.appendChild(table);
		let row = table.insertRow(-1);
		let cell = row.insertCell();
		cell.innerHTML = "Class:";
		cell = row.insertCell();
		cell.innerHTML = What.className;
		
		row = table.insertRow(-1);
		cell = row.insertCell();
		cell.innerHTML = "Sail:";
		cell = row.insertCell();
		cell.innerHTML = What.sailNumber;
		 
		row = table.insertRow(-1);
		cell = row.insertCell();
		cell.innerHTML = "PY:";
		cell = row.insertCell();
		cell.innerHTML = What.portsmouthNumber;
		
		if (What.crewName)
		{
			row = table.insertRow(-1);
			cell = row.insertCell();
			cell.innerHTML = "Crew:"
			cell = row.insertCell();
			cell.innerHTML = What.crewName;
			let paragraph = paragraphs[1];
			if (paragraph)
			{
				paragraph.style.display = "block";
				let spans = paragraph.getElementsByTagName("span");
				spans[0].innerHTML = What.crewName;
				if (ice.crewIceName)
				{
					spans[1].innerHTML = "In emergency contact " + ice.crewIceName;
				}
				else
				{
					spans[1].innerHTML = "No ICE name for this sailor.";
				}
				if (ice.crewIceTelephone)
				{
					spans[2].innerHTML = "Telephone ********" + ice.crewIceTelephone;
				}
				else
				{
					spans[2].innerHTML = "No ICE telephone for this sailor.";
				}
			}
		}
		else
		{
			let paragraph = paragraphs[1];
			if (paragraph)
			{
				paragraph.style.display = "none";
			}
		}
		if (What.extraCrewName)
		{
			row = table.insertRow(-1);
			cell = row.insertCell();
			cell.innerHTML = "Crew:"
			cell = row.insertCell();
			cell.innerHTML = What.ExtraCrewName;
			let paragraph = paragraphs[2];
			if (paragraph)
			{
				paragraph.style.display = "block";
				let spans = paragraph.getElementsByTagName("span");
				spans[0].innerHTML = What.extraCrewName;
				if (ice.extraCrewIceName)
				{
					spans[1].innerHTML = "In emergency contact " + ice.extraCrewIceName;
				}
				else
				{
					spans[1].innerHTML = "No ICE name for this sailor.";
				}
				if (ice.extraCrewIceTelephone)
				{
					spans[2].innerHTML = "Telephone ********" + ice.extraCrewIceTelephone;
				}
				else
				{
					spans[2].innerHTML = "No ICE telephone for this sailor.";
				}
			}
		}
		else
		{
			let paragraph = paragraphs[2];
			if (paragraph)
			{
				paragraph.style.display = "none";
			}
		}

		
		Sailing.bringToFront("agree");
	}
	
	static confirm()
	{
		let task = {};
		
		if (Auth.type === "duty")
		{
			if (!document.getElementById("agreedoingduty").checked)
			{
				Sailing.setError("agree", "You must confirm that you are doing a duty today.")
				return;
			}
		}
		else
		{
			if (!document.getElementById("agreeinsurance").checked)
			{
				Sailing.setError("agree", "You must confirm that you have adequate insurance.")
				return;
			}
			if (!document.getElementById("agreerules").checked)
			{
				Sailing.setError("agree", "You must confirm that will comply with all rules.")
				return;
			}
		}
		
		task.type = Auth.type;
		task.className = What.className;
		task.sailNumber = What.sailNumber;
		task.portsmouthNumber = What.portsmouthNumber;
		task.helmName = Who.helmName;
		task.crewName = What.crewName;
		task.extraCrewName = What.extraCrewName;
		let conn = new HttpURLConnection();
		conn.setFailureFunction((conn) =>
		{
			Sailing.setError("agree", conn.object.errorMessage);
		});
		conn.setSuccessFunction((conn) =>
		{
			localStorage.setItem("signonHelmName", Who.helmName);
			window.location.reload();
		});
		conn.transmit("command=addsignon&jsonencodedtask=" + encodeURIComponent(JSON.stringify(task)));
		
	}
}