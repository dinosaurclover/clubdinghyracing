"use strict"



class Keyboard
{
	static labels =
	[
		["1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "Backspace"],
		["Q", "W", "E", "R", "T", "Y", "U", "I", "O", "P", "Del"],
		["A", "S", "D", "F", "G", "H", "J", "K", "L", "'", "OK"],
		["Z", "X", "C", "V", "B", "N", "M", "Cancel"],
		["Space", "&lt;&lt;", "&gt;&gt;", "Clear"]
	];


	static color = "beige";
	static input = false;
	static saveListId = "";

	constructor(target)
	{
		console.log("keyboard");
		if (target.list)
		{
			this.readOptionList(target);
		}
		
		this.target = target;
		this.rect = target.getBoundingClientRect();
		this.input = document.createElement("input");
		this.input.type = this.target.type;
		

		this.modal = document.createElement("div");
		this.modal.setAttribute("class", "modal");
		document.body.appendChild(this.modal);
		this.modal.innerHTML = "";
		this.modal.appendChild(this.input);
		this.input.style.position = "fixed";
		this.input.style.left = String(this.rect.left) + "px";
		this.input.style.top = String(this.rect.top) + "px";
		this.input.style.width = String(this.target.offsetWidth) + "px";
		this.input.value = target.value;
		this.modal.style.display = "block";
		
		this.input.selectionStart = this.input.value.length;
		this.input.selectionEnd = this.input.value.length;
		this.input.focus();
		
		this.keyboard = this.createKeyboard();
		
		if (this.options)
		{
			this.createSelect();
		}
		
		this.windowClickListener = (evt)=>
		{
			if (evt.target === this.input) 
			{
				return;
			}
			else if (evt.target.className === "keyboardbutton")
			{
				return;
			}
			else if (evt.target.className === "keyboardoption")
			{
				this.target.value = evt.target.innerText;
				this.close();
				return;
			}
			this.close();
		}
		
		setTimeout(()=>
		{
			// When the user clicks anywhere outside of the modal, close it
			window.addEventListener("click", this.windowClickListener);
		}, 1000);
		
	}
	
	close()
	{
		window.removeEventListener("click", this.windowClickListener);
		console.log("removed event listener", this.windowClickListener);
		console.log("about to remove", this.modal);
		document.body.removeChild(this.modal);
	}
	
	readOptionList(target)
	{
		this.options = [];
		let options = target.list.options;
		for (const option of options)
		{
			let o = {};
			o.value = option.value;
			o.key = option.value.toLowerCase();
			this.options.push(o);
		}
	}

	createKeyboard()
	{
		let div = document.createElement("div");
		div.style.position = "fixed";
		div.style.margin = 0;
		this.modal.appendChild(div);
		
		let x = this.rect.left + this.rect.right;
		if (x < window.innerWidth)
		{
			div.style.left = String(this.rect.left) + "px";
		}
		else
		{
			div.style.right = String(window.innerWidth - this.rect.right) + "px";
		}
		
		let y = this.rect.top + this.rect.bottom;
		if (y < window.innerHeight)
		{
			div.style.top = String(this.rect.bottom) + "px";
		}
		else
		{
			div.style.bottom = String(window.innerHeight - this.rect.top) + "px";
		}
	
		
		let buttonHeight = 2;
		for (const labelLine of Keyboard.labels)
		{
			let row = document.createElement("div");
			div.appendChild(row);
			for (const label of (labelLine))
			{
				let width = buttonHeight;
				let margin = 0;
				let button = document.createElement("button");
				button.setAttribute("class", "keyboardbutton");
				row.appendChild(button);
				button.innerHTML = label;
				button.signal = label;
				switch (label)
				{
					case "Q":
						margin = buttonHeight * 0.75;
						break;
					case "A":
						margin = buttonHeight;
						break;
					case "Z":
						margin = buttonHeight * 1.75;
						;
						break;
					case "Space":
						margin = 3 * buttonHeight;
						width *= 5;
						break;
					case "Del":
						width = buttonHeight * 1.5;
						break;
					case "OK":
						width = buttonHeight * 2;
						break;
					case "Backspace":
						width = buttonHeight * 2.8;
						break;
					case "Cancel":
						width = buttonHeight * 2.6;
						break;
					case "Clear":
						width = buttonHeight * 2;
						break;
					default:
						width = buttonHeight;
						break;
				}
				button.style.margin = 0;
				button.style.marginLeft = "" + margin + "em";
				button.style.width = "" + width + "em";
				button.style.boxSizing = "border-box";
				button.style.height = "" + buttonHeight + "em";

				button.addEventListener("pointerdown", (evt) =>
				{
					evt.preventDefault();
					let button = evt.target;
					let s = this.input.selectionStart;
					let e = this.input.selectionEnd;
					if (e < s)
					{
						let i = e;
						e = s;
						s = i;
					}

					let value = this.input.value;
					let newvalue = button.innerHTML;

					switch (newvalue)
					{
						case "Backspace":
						{
							if (s == 0)
							
								return;
							s--;
							this.input.value = value.substr(0, s) + value.substr(e);
							break;
						}
						case "Del":
						{
							if (e >= value.length)
							
								return;
							e++;
							this.input.value = value.substr(0, s) + value.substr(e);
							break;
						}
						case "Cancel":
						{
							this.close();
							return;
						}
						case "Clear":
						{
							this.input.value = "";
							s = 0;
							break;
						}

						case "OK":
						{
							this.target.value = this.input.value;
							this.close();
							return;
						}
						case "&lt;&lt;":
						case "&#8592;":
						{
							if (s == 0)
							
								return;
							s--;
							break;
						}
						case "&gt;&gt;":
						case "&#8594;":
						{
							if (e >= value.length)
							
								return;
							e++;
							s = e;
							break;
						}
						case "Space":
							newvalue = " "; // fallthrough
						default:
						{
							if (!value)
							{
								this.input.value = button.innerText;
								this.input.selectionStart = 1;
								this.input.selectionEnd = 1;
								s = 1;
							}
							else
							{
								this.input.value = value.substr(0, s) + newvalue + value.substr(e);
								this.input.value = this.input.value.toLowerCase().replace(/\b\w/g, (c) => c.toUpperCase());

								this.input.selectionStart = s++;
								this.input.selectionEnd = s;
							}
						}
					}
					this.input.selectionStart = s;
					this.input.selectionEnd = s;
					this.input.focus();
					
					if (this.options)
					{
						this.offer();
					}
					
				}, true);
			}
		}
		return(div);
	}
	
	createSelect()
	{
		this.select = document.createElement("div");
		this.select.style.position = "fixed";
		this.modal.appendChild(this.select);
		this.select.style.backgroundColor = "white";
		this.select.style.overflowX = "scroll";
		this.select.style.display = "none";
		this.select.style.paddingLeft = "0.3em";
		this.select.style.paddingRight = "0.3em";
		
		/*
		let x = this.rect.left + this.rect.right;
		if (x < window.innerWidth)
		{
			select.style.left = String(this.rect.left) + "px";
		}
		else
		{
			select.style.right = String(window.innerWidth - this.rect.right) + "px";
		}
		*/
		
		let y = this.rect.top + this.rect.bottom;
		if (y < window.innerHeight)
		{
			this.select.style.top = String(this.rect.top) + "px";
			this.select.style.height = String(window.innerHeight - this.rect.top) + "px";
		}
		else
		{
			this.select.style.bottom = String(window.innerHeight - this.rect.bottom) + "px";
			this.select.style.height = String(this.rect.bottom) + "px";
		}
		
		// Don't use change
		// No response when user clicks first option
		//this.select.addEventListener("change", () =>
		//{
		//	this.target.value = this.select.value;
		//	this.close();
		//});
	}
		
	offer()
	{
		let needle = this.input.value.toLowerCase();
		if (this.input.value.length < 2)
		{
			this.select.style.display = "none";
			return;
		}
		
		this.select.innerHTML = "";
		let option = false;
		let size = 0;
		for (const o of this.options)
		{
			if (o.key.indexOf(needle) >= 0)
			{
				option = document.createElement("p");
				option.setAttribute("class", "keyboardoption");
				this.select.appendChild(option);
				option.innerHTML = o.value;
				size ++;
			}
		}
		option = document.createElement("p");
		this.select.appendChild(option);
		
		if (size === 0)
		{
			this.select.style.display = "none";
			return;
		}
		
		this.select.style.display = "block";
		this.select.size = String(size);
		let x = this.rect.left + this.rect.right;
		
		let rect = this.keyboard.getBoundingClientRect();
		
		if (x < window.innerWidth)
		{
			this.select.style.left = String(rect.right) + "px";
		}
		else
		{
			this.select.style.right = String(window.innerWidth - rect.left) + "px";
		}
		
	}
	
}