class Sailing
{
	static challenge = "";
	static flags = 0;
	constructor()
	{
		if (typeof mStartUpConfig !== 'undefined')
		{
			// the variable is defined
			// Server has passed on the flags from thee original get
			let object = JSON.parse(mStartUpConfig);
			Sailing.challenge = object.challenge;
			if (object.flags)
			{
				Sailing.flags = parseInt(object.flags);
			}
		}
		window.addEventListener("resize", Sailing.resize);
		
		this.displaySignOns()
		
		
		Sailing.resize();
	}
	
	displaySignOns()
	{
		let s  = new Date().toISOString().slice(0, 10) + "T00:00:00";
		let d = new Date(s);
		let task = {}
		task.startUnixEpochSeconds = Math.round(d.getTime() / 1000);
		task.endUnixEpochSeconds = Math.round(Date.now() / 1000);

		task.type = 'racing';
		let conn = new HttpURLConnection();
		conn.setFailureFunction((conn) =>
		{
			Sailing.setError("status", conn.object.errorMessage);
			console.log("Error");
		});
		conn.setSuccessFunction((conn) =>
		{
			this.displayRacingSignons(conn.object.signons);
			
		});
		conn.transmit("command=listsignons&jsonencodedtask=" + encodeURIComponent(JSON.stringify(task)));

	}

	displayRacingSignons(signons)
	{
		let contentDiv = document.getElementById("racingstatus");
		
		contentDiv.innerHTML = "";
		
		let d = new Date();
		let today = d.toString().substr(0, 15);
		
		let h2 = document.createElement("h2");
		contentDiv.appendChild(h2);
		h2.innerHTML = "Racing. " + today;

		let p = false;
		
		if (signons.length === 0)
		{
			p = document.createElement("p");
			contentDiv.appendChild(p);
			p.innerHTML = "No boats signed on to race today.";
		}
		else
		{
			signons.sort((a, b) =>
			{
				let i = a.className.localeCompare(b.className);
				if (i !== 0)
				{
					return(i);
				}
				return(parseInt(a.regSailNumber) - parseInt(b.regSailNumber));
			});
			let count = 0;
			for (const signon of signons)
			{
				count ++;
				let details = document.createElement("details");
				contentDiv.appendChild(details);
				let summary = document.createElement("summary");
				details.appendChild(summary);
				summary.innerHTML = String(count) + ". " + signon.className + " " + signon.regSailNumber;
				let div = document.createElement("div");
				div.style.marginLeft = "2em";
				details.appendChild(div);
				div.innerHTML = "PN:" + signon.classPortsmouthNumber + "<br>";
				div.innerHTML += signon.helmName;
				if (signon.crewName)
				{
					div.innerHTML += ", " + signon.crewName;
				}
				if (signon.extraCrewName)
				{
					div.innerHTML += ", " + signon.extraCrewName;
				}
			}
		}
		
		let s  = new Date().toISOString().slice(0, 10) + "T00:00:00";
		d = new Date(s);
		let task = {};
		task.startUnixEpochSeconds = Math.round(d.getTime() / 1000);
		task.endUnixEpochSeconds = Math.round(Date.now() / 1000);

		task.type = 'sailaway';
		let conn = new HttpURLConnection();
		conn.setFailureFunction((conn) =>
		{
			Sailing.setError("status", conn.object.errorMessage);
			console.log("Error");
		});
		conn.setSuccessFunction((conn) =>
		{
			this.displaySailAwaySignons(conn.object.signons);
		});
		conn.transmit("command=listsignons&jsonencodedtask=" + encodeURIComponent(JSON.stringify(task)));

	}

	displaySailAwaySignons(signons)
	{
		let contentDiv = document.getElementById("sailawaystatus");
		
		contentDiv.innerHTML = "";
		
		let d = new Date();
		let today = d.toString().substr(0, 15);
		
		let h2 = document.createElement("h2");
		contentDiv.appendChild(h2);
		h2.innerHTML = "SailAway. " + today;

		let p = false;
		
		if (signons.length === 0)
		{
			p = document.createElement("p");
			contentDiv.appendChild(p);
			p.innerHTML = "No boats signed on to sail away today.";
		}
		else
		{
			signons.sort((a, b) =>
			{
				let i = a.className.localeCompare(b.className);
				if (i !== 0)
				{
					return(i);
				}
				return(parseInt(a.regSailNumber) - parseInt(b.regSailNumber));
			});
			let count = 0;
			for (const signon of signons)
			{
				count ++;
				let details = document.createElement("details");
				contentDiv.appendChild(details);
				let summary = document.createElement("summary");
				details.appendChild(summary);
				summary.innerHTML = String(count) + ". " + signon.className + " " + signon.regSailNumber;
				let div = document.createElement("div");
				div.style.marginLeft = "2em";
				details.appendChild(div);
				div.innerHTML = "PN:" + signon.classPortsmouthNumber + "<br>";
				div.innerHTML += signon.helmName;
				if (signon.crewName)
				{
					div.innerHTML += ", " + signon.crewName;
				}
				if (signon.extraCrewName)
				{
					div.innerHTML += ", " + signon.extraCrewName;
				}
			}
		}
		
		let s  = new Date().toISOString().slice(0, 10) + "T00:00:00";
		d = new Date(s);
		let task = {};
		task.startUnixEpochSeconds = Math.round(d.getTime() / 1000);
		task.endUnixEpochSeconds = Math.round(Date.now() / 1000);

		task.type = 'socialsailing';
		let conn = new HttpURLConnection();
		conn.setFailureFunction((conn) =>
		{
			Sailing.setError("status", conn.object.errorMessage);
			console.log("Error");
		});
		conn.setSuccessFunction((conn) =>
		{
			this.displaySocialSailingSignons(conn.object.signons);
		});
		conn.transmit("command=listsignons&jsonencodedtask=" + encodeURIComponent(JSON.stringify(task)));

	}

	displaySocialSailingSignons(signons)
	{
		let contentDiv = document.getElementById("socialsailingstatus");
		
		contentDiv.innerHTML = "";
		
		let d = new Date();
		let today = d.toString().substr(0, 15);
		
		let h2 = document.createElement("h2");
		contentDiv.appendChild(h2);
		h2.innerHTML = "Social Sailing. " + today;

		let p = false;
		
		if (signons.length === 0)
		{
			p = document.createElement("p");
			contentDiv.appendChild(p);
			p.innerHTML = "No boats signed on for social sailing today.";
		}
		else
		{
			signons.sort((a, b) =>
			{
				let i = a.className.localeCompare(b.className);
				if (i !== 0)
				{
					return(i);
				}
				return(parseInt(a.regSailNumber) - parseInt(b.regSailNumber));
			});
			let count = 0;
			for (const signon of signons)
			{
				count ++;
				let details = document.createElement("details");
				contentDiv.appendChild(details);
				let summary = document.createElement("summary");
				details.appendChild(summary);
				summary.innerHTML = String(count) + ". " + signon.className + " " + signon.regSailNumber;
				let div = document.createElement("div");
				div.style.marginLeft = "2em";
				details.appendChild(div);
				div.innerHTML = "PN:" + signon.classPortsmouthNumber + "<br>";
				div.innerHTML += signon.helmName;
				if (signon.crewName)
				{
					div.innerHTML += ", " + signon.crewName;
				}
				if (signon.extraCrewName)
				{
					div.innerHTML += ", " + signon.extraCrewName;
				}
			}
		}
		
		let s  = new Date().toISOString().slice(0, 10) + "T00:00:00";
		d = new Date(s);
		let task = {};
		task.startUnixEpochSeconds = Math.round(d.getTime() / 1000);
		task.endUnixEpochSeconds = Math.round(Date.now() / 1000);

		task.type = 'duty';
		let conn = new HttpURLConnection();
		conn.setFailureFunction((conn) =>
		{
			Sailing.setError("status", conn.object.errorMessage);
			console.log("Error");
		});
		conn.setSuccessFunction((conn) =>
		{
			this.displayDutySignons(conn.object.signons);
		});
		conn.transmit("command=listsignons&jsonencodedtask=" + encodeURIComponent(JSON.stringify(task)));

	}

	displayDutySignons(signons)
	{
		let contentDiv = document.getElementById("dutystatus");
		contentDiv.innerHTML = "";
		
		let d = new Date();
		let today = d.toString().substr(0, 15);
		
		let h2 = document.createElement("h2");
		contentDiv.appendChild(h2);
		h2.innerHTML = "Duties. " + today;

		let p = false;
		
		if (signons.length === 0)
		{
			p = document.createElement("p");
			contentDiv.appendChild(p);
			p.innerHTML = "No one doing a duty signed on today.";
		}
		else
		{
			signons.sort((a, b) =>
			{
				let i = a.helmName.localeCompare(b.helmName);
				return(i);
			});
			let count = 0;
			for (const signon of signons)
			{
				count ++;
				let details = document.createElement("details");
				contentDiv.appendChild(details);
				let summary = document.createElement("summary");
				details.appendChild(summary);
				summary.innerHTML = String(count) + ". " + signon.helmName;
			}
		}
		
	}

	// Hide all the divs not required
	// Ensure the required div is not hidden
	static bringToFront(id)
	{
		for (const div of document.getElementsByClassName("topLevel"))
		{
			div.style.display = "none";
		}
		let div = document.getElementById(id);
		div.style.display = "block";
		setTimeout(Sailing.resize, 0);
		
	}
	
	static setError(id, message)
	{
		Sailing.errorId = id;
		Sailing.bringToFront("error");
		let div = document.getElementById("errorMessage");
		div.innerHTML = message;
	}
	
	static errorAcknowledge()
	{
		Sailing.bringToFront(Sailing.errorId)
	}

	static loginDisplay()
	{
		if (Sailing.flags)
		{
			// Extremely weak mechanism to bypass login for lobby screen
			document.getElementById("passWord").value = Sailing.flags;
		}
		Sailing.bringToFront("login");
		let input = document.getElementById("racingLogin");
	}
	
	
	static resize()
	{
		let divs = document.getElementsByClassName("topLevel");
		for(const div of divs)
		{
			let areas = div.children;
			if (areas.length === 2)
			{
				areas[1].style.height = String(window.innerHeight - areas[0].offsetHeight) + "px";
			}
		}
	}
	
	static quit()
	{
		window.location.reload();
	}

}