/*
 * Copyright 2021 Ian Rye. All Rights Reserved.
 * ianrye@espforwindows.com
 * Interface for communicating with an active http server
 * This class sends query strings, for example
 * command=test&param=1
 * If the query is successful the server resonds with a json encoded object.
 * Site is password protected. A valid token is required.
 */

"use strict"

class HttpURLConnection extends XMLHttpRequest
{
	static databaseName = null;
	static token = false;
	static steps = 0;
	constructor(mode, url)
	{
		super();

		this.addEventListener("error", errorListener)
		function errorListener(evt)
		{
			console.log(evt);
			if (this.guard) document.body.removeChild(this.guard);
			if (this.failureCallback)
			{
				this.object = {};
				this.object.errorMessage = "Internet connection failure";
				this.failureCallback(this);
				return;
			}
		}

		this.addEventListener("timeout", timeoutListener)
		function timeoutListener()
		{
			if (this.guard) document.body.removeChild(this.guard);
			if (this.failureCallback)
			{
				this.object = {};
				this.object.errorMessage = "Connection to server lost or timed out.";
				this.failureCallback(this);
				return;
			}
			let message = "Connection to server lost or timed out." +
					"<br>Timeout is currently set to " + Math.round(this.timeout / 1000) + " seconds." +
					"<br>Use Tools/GlobalSettings to Change Timeout Value."
			SignOn.setError(message);
		}

		this.addEventListener("readystatechange", readystatechangeListener)
		function readystatechangeListener()
		{
			HttpURLConnection.steps ++;
		}

		this.addEventListener("load", loadListener)
		function loadListener()
		{
			if (this.guard) document.body.removeChild(this.guard);
			if (this.status != 200)
			{
				this.object = {};
				this.object.errorMessage = "Server returned HTTP status code " + this.status;
				if (this.failureCallback) this.failureCallback(this);
			}
			else
			{
				let token = this.getResponseHeader("token");
				if (token)
				{
					HttpURLConnection.token = token;
				}

				// THE RESPONSE SHOULD BE VALID JSON TEXT WHICH CAN BE
				// DECODED TO AN OBJECT
				let object = false;
				try
				{
					this.object = JSON.parse(this.responseText);
				}
				catch (error)
				{
					if (this.responseFunction)
					{
						// Caller is expecting non-json resonse
						this.responseFunction(this)
						return;
					}
					this.object = {};
					this.object.errorMessage = "Unexpected (non-json) response from server.<br>If this persists please contact development team."
				}
				if (!this.object)
				{
					this.object = {};
					this.object.errorMessage = "Unexpected (non-json) response from server.<br>If this persists please contact development team."
				}

				if (this.object.errorMessage)
				{
					if (this.failureCallback) this.failureCallback(this);
					else SignOn.setError(this.object.errorMessage);
					return;
				}
				else if (this.object.warningMessage)
				{
					if (this.warningCallback) this.warningCallback(this);
					else SignOn.setError("Unhandled warning messge.<br>" + this.object.warningMessage);
					return;
				}
				else
				{
					if (this.callback) this.callback(this);
				}
			}
		}

		if (url) this.open("POST", url, true);
		else this.open("POST", "index.php", true);
		this.setRequestHeader("Content-type","application/x-www-form-urlencoded");
		this.timeout = 5000;
		if (HttpURLConnection.token) this.setRequestHeader("token", HttpURLConnection.token);
		if (HttpURLConnection.databaseName) this.setRequestHeader("databasename", HttpURLConnection.databaseName);
		if (mode == "write") this.setRequestHeader("databasemode","write");
	}


	/* public */
	setSuccessFunction(fn)
	{
		this.callback = fn;
	}

	/* public */
	setFailureFunction(fn)
	{
		this.failureCallback = fn;
	}

	/* public */
	setWarningFunction(fn)
	{
		this.warningCallback = fn;
	}

	/* public */
	setResponseFunction(fn)
	{
		this.responseFunction = fn;
	}

	/* public */
	transmit(data)
	{
		// CREATE A GUARD DIV TO DISABLE POINTER
		let guard = document.createElement('div');
		document.body.appendChild(guard);
		guard.style.position = "absolute";
		guard.style.left = 0;
		guard.style.top = 0;
		guard.style.width = "" + window.innerWidth + "px";
		guard.style.height = "" + window.innerHeight + "px";
//		guard.style.background = "rgba(0, 0, 0, 0.2)";
		
		guard.addEventListener("pointerdown", prevent, true);
		guard.addEventListener("click", prevent, true);
		
		function prevent(evt)
		{
			evt.preventDefault();
		}

		this.guard = guard;
		
		this.send(data);
	}
	
	static setDatabaseName(name)
	{
		HttpURLConnection.databaseName = name;
	}

}

