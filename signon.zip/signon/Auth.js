class Auth
{
	type = false;

	static test()
	{
		// Communication with the server occurs here.
		// Server will have sent a challenge when page was loaded.
		// Password is hashed with the challenge so server can authenticate
		// If password is OK server will respond with latest data.
		// Data is verbose. It includes
		// All current signons
		// All members names
		// recent boats sailed by all members
		// recent crews in boats sailed by all members.
		
		// This can take a second or two
		let saveDiv = false;
		for (const div of document.getElementsByClassName("topLevel"))
		{
			if (div.style.display !== "none")
			{
				saveDiv = div;
				div.style.display = "none";
			}
		}

		Auth.type = "";
		let div = document.getElementById("login");
		let inputs = div.getElementsByTagName("input");
		for (const input of inputs)
		{
			if ((input.type === "radio") && (input.checked))
			{
				Auth.type = input.id.slice(0, -5).toLowerCase();
			}
		}
		
		if (!Auth.type)
		{
			Sailing.setError("login", "You must check sailing, sailaway, social or duty.");
			return;
		}
		
		let pass = document.getElementById("passWord").value;
		
		let sha256 = new jsSHA('SHA-256', 'TEXT');
		sha256.update("signon" + pass + Sailing.challenge + pass + "signon");
		Sailing.digest = sha256.getHash("HEX");
		let conn = new HttpURLConnection();
		conn.setRequestHeader("challenge", Sailing.challenge);
		conn.setRequestHeader("digest", Sailing.digest);
		conn.setFailureFunction((conn) =>
		{
			Sailing.setError("login", conn.object.errorMessage);
		});
		conn.setSuccessFunction((conn) => 
		{
			if (Auth.type === "register")
			{
				Register.display();
			}
			else
			{
				Who.pickSailor();
			}
		});
		
		conn.transmit("command=noop");
	}
	
	static onKeyDown(evt)
	{
		if (evt.key === "Enter")
		{
			evt.preventDefault();
			evt.stopPropagation();
			Auth.test();
		}
	}
}


