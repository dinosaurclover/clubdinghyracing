<?php

require_once '../clubcommon/Database.php';
require_once '../clubcommon/Misc.php';

class Auth
{
	function __construct($db)
	{
		$this->db = $db;

		if (!$this->checkToken())
		{
			issueChallenge();
		}
	}

	private function getEnv($key)
	{
		$s = $_SERVER[$key];
		if (!empty($s)) return($s);
		return(getenv($key));
	}

	// Client provides account name when it first checks a token retrieved from local storage.
	// Subsequently we just check that the token is OK and determine the account name from the md5 within it.
	// Return an object that can be passed back to the client
	private function checkToken()
	{
		$token = $this->getEnv("HTTP_TOKEN");
		if (empty($token))
		{
			return(false);
		}

		$a = getConfigValue($db, "portal")[0];
		$portalPassword = $a->portalPassword;
		$portalLifeDayCount = $a->portalLifeDayCount;

		if (empty($portalPassword))
		{
			return(false);
		}

		// APACHE PROVIDES THIS
		$hostName = $this->getEnv("SERVER_NAME");
		$ipAddress = $this->getEnv("HTTP_X_FORWARDED_FOR");
		if (empty($ipAddress)) $ipAddress = $this->getEnv("REMOTE_ADDR");

		$bits = explode(".", $token);
		if (count($bits) != 3)
		{
			return(false);
		}

		for ($i = 0; $i < 3; $i++)
		{
			while (count($words = explode(" ", $bits[$i])) > 1)
			{
				$bits[$i] = implode("", $words);
			}
		}

		$sha256 = base64_encode(hash("sha256", $bits[0] . "." . $bits[1] . $portalPassword));
		if ($sha256 != $bits[2])
		{
			// Something has messed with the token
			return(false);
		}

		$payload = json_decode(base64_decode($bits[1]));
		if (time() > ($payload->time + $portalLifeDayCount))
		{
			return(false);
		}

		if (($ipAddress != $payload->ipAddress) || ($hostName != $payload->hostName))
		{
			return(false);
		}

		$fmt = "SELECT sailorKey FROM sailor WHERE sailorMailAddress LIKE " . $this->db->quote($payload->mailAddress);
		$key = $this->db->querySingle($fmt);

		if (empty($key))
		{
			return(false);
		}

		$a = getConfigValueAssoc($db, "administrator");
		if ($a[$payload->mailAddress])
		{
			$this->administrator = true;
		}
		return(true);
	}

	static function authIssueToken($context)
	{
		$email = strtolower(trim(commonGetFormValue("email", "")));
		if (empty($email)) authErrorExit("No email Address");

		$challenge = $this->getEnv("HTTP_CHALLENGE");
		if (empty($challenge)) authErrorExit("No challenge");

		$key = strtolower(trim(commonGetFormValue("key", "")));
		if (empty($key)) authErrorExit("No key");

		// APACHE PROVIDES THIS
		$hostName = $this->getEnv("SERVER_NAME");
		$ipAddress = $this->getEnv("HTTP_X_FORWARDED_FOR");
		if (empty($ipAddress)) $ipAddress = $this->getEnv("REMOTE_ADDR");

		$scriptFileName = "Universal admin login procedure";

		if ($challenge != base64_encode(hash("sha256", $hostName . "." . $ipAddress . $email . $key . $scriptFileName . ".decade")))
		{
			authErrorExit("Invalid Key");
		}

		$header->alg = "sha256";
		$header->type = "JWT";
		$header = base64_encode(json_encode($header));

		$payload = new stdClass();
		$payload->time = time();
		$payload->hostName = $hostName;
		$payload->ipAddress = $ipAddress;
		$payload->idMD5 = md5($email);
		$payload->scriptFileName = $scriptFileName;
		$payload = base64_encode(json_encode($payload));
		$signature = base64_encode(hash("sha256", $header . "." . $payload . ".decade"));

		$object = new stdClass();
		$object->token = $header . "." . $payload . "." . $signature;
		echo(json_encode($object));
		exit();
	}

	// Key is derived from today's date, ipaddress, hostname 
	// Challenge is derived from key, ipaddress, hostname, script file name.
	private function authIssueChallenge()
	{
		if (function_exists("random_bytes"))
		{
			$challenge = bin2hex(random_bytes(48));
		}
		else
		{
			$a = array();
			for ($i = 0; $i < 40; $i++)
			{
				array_push($a, chr(mt_rand(0, 255)));
				$challenge = bin2hex(implode("", $a));
			}
		}

		// APACHE PROVIDES THIS
		$hostName = $this->getEnv("SERVER_NAME");
		$ipAddress = $this->getEnv("HTTP_X_FORWARDED_FOR");
		if (empty($ipAddress)) $ipAddress = $this->getEnv("REMOTE_ADDR");

		$fmt = "INSERT INTO challenge VALUES(" . $this->db->quote($challenge)
				. "," . $this->db->quote($hostName)
				. "," . $this->db->quote($ipAddress)
				. "," . time() . ")";




		$s = hash("sha256", $hostName . "." . $ipAddress . date("Y-m-d") . $email . $scriptFileName . ".decade");
		$key = 100000 + hexdec(substr($s, 0, 10)) % 899999;
		file_put_contents(".key", $key);

		$address = $context->clubConfig->administrators[$i];
		$subject = "NSC administration - " . "your login key";
		if (function_exists("mail"))
		{
			$code = mail($email, $subject, $key);
			file_put_contents(".mailCode", $code);
		}

		$object = new stdClass();
		$object->challenge = base64_encode(hash("sha256", $hostName . "." . $ipAddress . $email . $key . $scriptFileName . ".decade"));
		echo(json_encode($object));

		exit();
	}

}
