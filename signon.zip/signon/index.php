<?php

require_once 'Sailing.php';
require_once 'Custom.php';
require_once '../clubcommon/Database.php';
require_once '../clubcommon/Misc.php';
require_once '../clubcommon/ClassMine.php';

new Sailing();