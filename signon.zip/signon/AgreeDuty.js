class AgreeDuty
{
	static display()
	{
		Sailing.bringToFront("agreeduty");
	}

	static confirm()
	{
		let task = {};
		
		
		if (!document.getElementById("agreedoingduty").checked)
		{
			Sailing.setError("agree", "You must confirm that you are doing a duty today.")
			return;
		}

		task.type = Auth.type;
		task.className = What.className;
		task.sailNumber = What.sailNumber;
		task.portsmouthNumber = What.portsmouthNumber;
		task.helmName = Who.helmName;
		task.crewName = What.crewName;
		task.extraCrewName = What.extraCrewName;
		let conn = new HttpURLConnection();
		conn.setFailureFunction((conn) =>
		{
			Sailing.setError("agreeduty", conn.object.errorMessage);
		});
		conn.setSuccessFunction((conn) =>
		{
			window.location.reload();
		});
		
		conn.transmit("command=addsignon&jsonencodedtask=" + encodeURIComponent(JSON.stringify(task)));
	}
}